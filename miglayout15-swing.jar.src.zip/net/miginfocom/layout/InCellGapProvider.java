package net.miginfocom.layout;

public abstract interface InCellGapProvider
{
  public abstract BoundSize getDefaultGap(ComponentWrapper paramComponentWrapper1, ComponentWrapper paramComponentWrapper2, int paramInt, String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\miglayout15-swing.jar!\net\miginfocom\layout\InCellGapProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */