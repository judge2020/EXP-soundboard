package net.miginfocom.layout;

public abstract class UnitConverter
{
  public static final int UNABLE = -87654312;
  
  public abstract int convertToPixels(float paramFloat1, String paramString, boolean paramBoolean, float paramFloat2, ContainerWrapper paramContainerWrapper, ComponentWrapper paramComponentWrapper);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\miglayout15-swing.jar!\net\miginfocom\layout\UnitConverter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */