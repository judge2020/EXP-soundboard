package net.miginfocom.layout;

public abstract interface ContainerWrapper
  extends ComponentWrapper
{
  public abstract ComponentWrapper[] getComponents();
  
  public abstract int getComponentCount();
  
  public abstract Object getLayout();
  
  public abstract boolean isLeftToRight();
  
  public abstract void paintDebugCell(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\miglayout15-swing.jar!\net\miginfocom\layout\ContainerWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */