/*     */ package org.tritonus.share;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.security.AccessControlException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TDebug
/*     */ {
/*  39 */   public static boolean SHOW_ACCESS_CONTROL_EXCEPTIONS = false;
/*     */   
/*     */   private static final String PROPERTY_PREFIX = "tritonus.";
/*  42 */   public static PrintStream m_printStream = System.out;
/*     */   
/*  44 */   private static String indent = "";
/*     */   
/*     */ 
/*  47 */   public static boolean TraceAllExceptions = getBooleanProperty("TraceAllExceptions");
/*  48 */   public static boolean TraceAllWarnings = getBooleanProperty("TraceAllWarnings");
/*     */   
/*     */ 
/*  51 */   public static boolean TraceInit = getBooleanProperty("TraceInit");
/*  52 */   public static boolean TraceCircularBuffer = getBooleanProperty("TraceCircularBuffer");
/*  53 */   public static boolean TraceService = getBooleanProperty("TraceService");
/*     */   
/*     */ 
/*  56 */   public static boolean TraceAudioSystem = getBooleanProperty("TraceAudioSystem");
/*  57 */   public static boolean TraceAudioConfig = getBooleanProperty("TraceAudioConfig");
/*  58 */   public static boolean TraceAudioInputStream = getBooleanProperty("TraceAudioInputStream");
/*  59 */   public static boolean TraceMixerProvider = getBooleanProperty("TraceMixerProvider");
/*  60 */   public static boolean TraceControl = getBooleanProperty("TraceControl");
/*  61 */   public static boolean TraceLine = getBooleanProperty("TraceLine");
/*  62 */   public static boolean TraceDataLine = getBooleanProperty("TraceDataLine");
/*  63 */   public static boolean TraceMixer = getBooleanProperty("TraceMixer");
/*  64 */   public static boolean TraceSourceDataLine = getBooleanProperty("TraceSourceDataLine");
/*  65 */   public static boolean TraceTargetDataLine = getBooleanProperty("TraceTargetDataLine");
/*  66 */   public static boolean TraceClip = getBooleanProperty("TraceClip");
/*  67 */   public static boolean TraceAudioFileReader = getBooleanProperty("TraceAudioFileReader");
/*  68 */   public static boolean TraceAudioFileWriter = getBooleanProperty("TraceAudioFileWriter");
/*  69 */   public static boolean TraceAudioConverter = getBooleanProperty("TraceAudioConverter");
/*  70 */   public static boolean TraceAudioOutputStream = getBooleanProperty("TraceAudioOutputStream");
/*     */   
/*     */ 
/*  73 */   public static boolean TraceEsdNative = getBooleanProperty("TraceEsdNative");
/*  74 */   public static boolean TraceEsdStreamNative = getBooleanProperty("TraceEsdStreamNative");
/*  75 */   public static boolean TraceEsdRecordingStreamNative = getBooleanProperty("TraceEsdRecordingStreamNative");
/*  76 */   public static boolean TraceAlsaNative = getBooleanProperty("TraceAlsaNative");
/*  77 */   public static boolean TraceAlsaMixerNative = getBooleanProperty("TraceAlsaMixerNative");
/*  78 */   public static boolean TraceAlsaPcmNative = getBooleanProperty("TraceAlsaPcmNative");
/*  79 */   public static boolean TraceMixingAudioInputStream = getBooleanProperty("TraceMixingAudioInputStream");
/*  80 */   public static boolean TraceOggNative = getBooleanProperty("TraceOggNative");
/*  81 */   public static boolean TraceVorbisNative = getBooleanProperty("TraceVorbisNative");
/*     */   
/*     */ 
/*  84 */   public static boolean TraceMidiSystem = getBooleanProperty("TraceMidiSystem");
/*  85 */   public static boolean TraceMidiConfig = getBooleanProperty("TraceMidiConfig");
/*  86 */   public static boolean TraceMidiDeviceProvider = getBooleanProperty("TraceMidiDeviceProvider");
/*  87 */   public static boolean TraceSequencer = getBooleanProperty("TraceSequencer");
/*  88 */   public static boolean TraceMidiDevice = getBooleanProperty("TraceMidiDevice");
/*     */   
/*     */ 
/*  91 */   public static boolean TraceAlsaSeq = getBooleanProperty("TraceAlsaSeq");
/*  92 */   public static boolean TraceAlsaSeqDetails = getBooleanProperty("TraceAlsaSeqDetails");
/*  93 */   public static boolean TraceAlsaSeqNative = getBooleanProperty("TraceAlsaSeqNative");
/*  94 */   public static boolean TracePortScan = getBooleanProperty("TracePortScan");
/*  95 */   public static boolean TraceAlsaMidiIn = getBooleanProperty("TraceAlsaMidiIn");
/*  96 */   public static boolean TraceAlsaMidiOut = getBooleanProperty("TraceAlsaMidiOut");
/*  97 */   public static boolean TraceAlsaMidiChannel = getBooleanProperty("TraceAlsaMidiChannel");
/*     */   
/*     */ 
/* 100 */   public static boolean TraceAlsaCtlNative = getBooleanProperty("TraceAlsaCtlNative");
/* 101 */   public static boolean TraceCdda = getBooleanProperty("TraceCdda");
/* 102 */   public static boolean TraceCddaNative = getBooleanProperty("TraceCddaNative");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void out(String strMessage)
/*     */   {
/* 109 */     if ((strMessage.length() > 0) && (strMessage.charAt(0) == '<')) {
/* 110 */       if (indent.length() > 2) {
/* 111 */         indent = indent.substring(2);
/*     */       } else {
/* 113 */         indent = "";
/*     */       }
/*     */     }
/* 116 */     String newMsg = null;
/* 117 */     if ((indent != "") && (strMessage.indexOf("\n") >= 0)) {
/* 118 */       newMsg = "";
/* 119 */       StringTokenizer tokenizer = new StringTokenizer(strMessage, "\n");
/* 120 */       while (tokenizer.hasMoreTokens()) {
/* 121 */         newMsg = newMsg + indent + tokenizer.nextToken() + "\n";
/*     */       }
/*     */     } else {
/* 124 */       newMsg = indent + strMessage;
/*     */     }
/* 126 */     m_printStream.println(newMsg);
/* 127 */     if ((strMessage.length() > 0) && (strMessage.charAt(0) == '>')) {
/* 128 */       indent += "  ";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void out(Throwable throwable)
/*     */   {
/* 136 */     throwable.printStackTrace(m_printStream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void assertion(boolean bAssertion)
/*     */   {
/* 143 */     if (!bAssertion)
/*     */     {
/* 145 */       throw new AssertException();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class AssertException
/*     */     extends RuntimeException
/*     */   {
/*     */     public AssertException() {}
/*     */     
/*     */ 
/*     */ 
/*     */     public AssertException(String sMessage)
/*     */     {
/* 161 */       super();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean getBooleanProperty(String strName)
/*     */   {
/* 169 */     String strPropertyName = "tritonus." + strName;
/* 170 */     String strValue = "false";
/*     */     try
/*     */     {
/* 173 */       strValue = System.getProperty(strPropertyName, "false");
/*     */     }
/*     */     catch (AccessControlException e)
/*     */     {
/* 177 */       if (SHOW_ACCESS_CONTROL_EXCEPTIONS)
/*     */       {
/* 179 */         out(e);
/*     */       }
/*     */     }
/*     */     
/* 183 */     boolean bValue = strValue.toLowerCase().equals("true");
/*     */     
/* 185 */     return bValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\TDebug.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */