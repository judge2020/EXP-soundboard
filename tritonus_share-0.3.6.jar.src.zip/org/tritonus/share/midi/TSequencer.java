/*     */ package org.tritonus.share.midi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.sound.midi.ControllerEventListener;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.midi.MetaEventListener;
/*     */ import javax.sound.midi.MetaMessage;
/*     */ import javax.sound.midi.MidiDevice.Info;
/*     */ import javax.sound.midi.MidiMessage;
/*     */ import javax.sound.midi.MidiSystem;
/*     */ import javax.sound.midi.Sequence;
/*     */ import javax.sound.midi.Sequencer;
/*     */ import javax.sound.midi.Sequencer.SyncMode;
/*     */ import javax.sound.midi.ShortMessage;
/*     */ import org.tritonus.share.ArraySet;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TSequencer
/*     */   extends TMidiDevice
/*     */   implements Sequencer
/*     */ {
/*     */   private static final float MPQ_BPM_FACTOR = 6.0E7F;
/*  62 */   private static final Sequencer.SyncMode[] EMPTY_SYNCMODE_ARRAY = new Sequencer.SyncMode[0];
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean m_bRunning;
/*     */   
/*     */ 
/*     */ 
/*     */   private Sequence m_sequence;
/*     */   
/*     */ 
/*     */ 
/*     */   private Set<MetaEventListener> m_metaListeners;
/*     */   
/*     */ 
/*     */   private Set<ControllerEventListener>[] m_aControllerListeners;
/*     */   
/*     */ 
/*     */   private float m_fNominalTempoInMPQ;
/*     */   
/*     */ 
/*     */   private float m_fTempoFactor;
/*     */   
/*     */ 
/*     */   private Collection<Sequencer.SyncMode> m_masterSyncModes;
/*     */   
/*     */ 
/*     */   private Collection<Sequencer.SyncMode> m_slaveSyncModes;
/*     */   
/*     */ 
/*     */   private Sequencer.SyncMode m_masterSyncMode;
/*     */   
/*     */ 
/*     */   private Sequencer.SyncMode m_slaveSyncMode;
/*     */   
/*     */ 
/*     */   private BitSet m_muteBitSet;
/*     */   
/*     */ 
/*     */   private BitSet m_soloBitSet;
/*     */   
/*     */ 
/*     */   private BitSet m_enabledBitSet;
/*     */   
/*     */ 
/*     */   private long m_lLoopStartPoint;
/*     */   
/*     */ 
/*     */   private long m_lLoopEndPoint;
/*     */   
/*     */ 
/*     */   private int m_nLoopCount;
/*     */   
/*     */ 
/*     */ 
/*     */   protected TSequencer(MidiDevice.Info info, Collection<Sequencer.SyncMode> masterSyncModes, Collection<Sequencer.SyncMode> slaveSyncModes)
/*     */   {
/* 119 */     super(info);
/* 120 */     this.m_bRunning = false;
/* 121 */     this.m_sequence = null;
/* 122 */     this.m_metaListeners = new ArraySet();
/* 123 */     this.m_aControllerListeners = ((Set[])new Set['']);
/* 124 */     setTempoFactor(1.0F);
/* 125 */     setTempoInMPQ(500000.0F);
/*     */     
/* 127 */     this.m_masterSyncModes = masterSyncModes;
/* 128 */     this.m_slaveSyncModes = slaveSyncModes;
/* 129 */     if (getMasterSyncModes().length > 0)
/*     */     {
/* 131 */       this.m_masterSyncMode = getMasterSyncModes()[0];
/*     */     }
/* 133 */     if (getSlaveSyncModes().length > 0)
/*     */     {
/* 135 */       this.m_slaveSyncMode = getSlaveSyncModes()[0];
/*     */     }
/* 137 */     this.m_muteBitSet = new BitSet();
/* 138 */     this.m_soloBitSet = new BitSet();
/* 139 */     this.m_enabledBitSet = new BitSet();
/* 140 */     updateEnabled();
/* 141 */     setLoopStartPoint(0L);
/* 142 */     setLoopEndPoint(-1L);
/* 143 */     setLoopCount(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSequence(Sequence sequence)
/*     */     throws InvalidMidiDataException
/*     */   {
/* 152 */     if (getSequence() != sequence)
/*     */     {
/* 154 */       this.m_sequence = sequence;
/* 155 */       setSequenceImpl();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */       setTempoFactor(1.0F);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSequenceImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSequence(InputStream inputStream)
/*     */     throws InvalidMidiDataException, IOException
/*     */   {
/* 181 */     Sequence sequence = MidiSystem.getSequence(inputStream);
/* 182 */     setSequence(sequence);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Sequence getSequence()
/*     */   {
/* 189 */     return this.m_sequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLoopStartPoint(long lTick)
/*     */   {
/* 196 */     this.m_lLoopStartPoint = lTick;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getLoopStartPoint()
/*     */   {
/* 202 */     return this.m_lLoopStartPoint;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLoopEndPoint(long lTick)
/*     */   {
/* 208 */     this.m_lLoopEndPoint = lTick;
/*     */   }
/*     */   
/*     */ 
/*     */   public long getLoopEndPoint()
/*     */   {
/* 214 */     return this.m_lLoopEndPoint;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLoopCount(int nLoopCount)
/*     */   {
/* 220 */     this.m_nLoopCount = nLoopCount;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getLoopCount()
/*     */   {
/* 226 */     return this.m_nLoopCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public synchronized void start()
/*     */   {
/* 233 */     checkOpen();
/* 234 */     if (!isRunning())
/*     */     {
/* 236 */       this.m_bRunning = true;
/*     */       
/* 238 */       startImpl();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void stop()
/*     */   {
/* 255 */     checkOpen();
/* 256 */     if (isRunning())
/*     */     {
/* 258 */       stopImpl();
/* 259 */       this.m_bRunning = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isRunning()
/*     */   {
/* 277 */     return this.m_bRunning;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkOpen()
/*     */   {
/* 293 */     if (!isOpen())
/*     */     {
/* 295 */       throw new IllegalStateException("Sequencer is not open");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getResolution()
/*     */   {
/* 306 */     Sequence sequence = getSequence();
/*     */     int nResolution;
/* 308 */     int nResolution; if (sequence != null)
/*     */     {
/* 310 */       nResolution = sequence.getResolution();
/*     */     }
/*     */     else
/*     */     {
/* 314 */       nResolution = 1;
/*     */     }
/* 316 */     return nResolution;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setRealTempo()
/*     */   {
/* 323 */     float fTempoFactor = getTempoFactor();
/* 324 */     if (fTempoFactor == 0.0F)
/*     */     {
/* 326 */       fTempoFactor = 0.01F;
/*     */     }
/* 328 */     float fRealTempo = getTempoInMPQ() / fTempoFactor;
/* 329 */     if (TDebug.TraceSequencer) TDebug.out("TSequencer.setRealTempo(): real tempo: " + fRealTempo);
/* 330 */     setTempoImpl(fRealTempo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public float getTempoInBPM()
/*     */   {
/* 337 */     float fBPM = 6.0E7F / getTempoInMPQ();
/* 338 */     return fBPM;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTempoInBPM(float fBPM)
/*     */   {
/* 345 */     float fMPQ = 6.0E7F / fBPM;
/* 346 */     setTempoInMPQ(fMPQ);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public float getTempoInMPQ()
/*     */   {
/* 353 */     return this.m_fNominalTempoInMPQ;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTempoInMPQ(float fMPQ)
/*     */   {
/* 363 */     this.m_fNominalTempoInMPQ = fMPQ;
/* 364 */     setRealTempo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTempoFactor(float fFactor)
/*     */   {
/* 371 */     this.m_fTempoFactor = fFactor;
/* 372 */     setRealTempo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public float getTempoFactor()
/*     */   {
/* 379 */     return this.m_fTempoFactor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void setTempoImpl(float paramFloat);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getTickLength()
/*     */   {
/* 397 */     long lLength = 0L;
/* 398 */     if (getSequence() != null)
/*     */     {
/* 400 */       lLength = getSequence().getTickLength();
/*     */     }
/* 402 */     return lLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondLength()
/*     */   {
/* 410 */     long lLength = 0L;
/* 411 */     if (getSequence() != null)
/*     */     {
/* 413 */       lLength = getSequence().getMicrosecondLength();
/*     */     }
/* 415 */     return lLength;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean addMetaEventListener(MetaEventListener listener)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 6	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 64 2 0
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: ireturn
/*     */     //   20: astore_3
/*     */     //   21: aload_2
/*     */     //   22: monitorexit
/*     */     //   23: aload_3
/*     */     //   24: athrow
/*     */     // Line number table:
/*     */     //   Java source line #423	-> byte code offset #0
/*     */     //   Java source line #425	-> byte code offset #7
/*     */     //   Java source line #426	-> byte code offset #20
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	25	0	this	TSequencer
/*     */     //   0	25	1	listener	MetaEventListener
/*     */     //   5	17	2	Ljava/lang/Object;	Object
/*     */     //   20	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	19	20	finally
/*     */     //   20	23	20	finally
/*     */   }
/*     */   
/*     */   public void removeMetaEventListener(MetaEventListener listener)
/*     */   {
/* 433 */     synchronized (this.m_metaListeners)
/*     */     {
/* 435 */       this.m_metaListeners.remove(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected Iterator<MetaEventListener> getMetaEventListeners()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 6	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
/*     */     //   11: invokeinterface 66 1 0
/*     */     //   16: aload_1
/*     */     //   17: monitorexit
/*     */     //   18: areturn
/*     */     //   19: astore_2
/*     */     //   20: aload_1
/*     */     //   21: monitorexit
/*     */     //   22: aload_2
/*     */     //   23: athrow
/*     */     // Line number table:
/*     */     //   Java source line #442	-> byte code offset #0
/*     */     //   Java source line #444	-> byte code offset #7
/*     */     //   Java source line #445	-> byte code offset #19
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	24	0	this	TSequencer
/*     */     //   5	16	1	Ljava/lang/Object;	Object
/*     */     //   19	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	18	19	finally
/*     */     //   19	22	19	finally
/*     */   }
/*     */   
/*     */   protected void sendMetaMessage(MetaMessage message)
/*     */   {
/* 452 */     Iterator<MetaEventListener> iterator = getMetaEventListeners();
/* 453 */     while (iterator.hasNext())
/*     */     {
/* 455 */       MetaEventListener metaEventListener = (MetaEventListener)iterator.next();
/* 456 */       MetaMessage copiedMessage = (MetaMessage)message.clone();
/* 457 */       metaEventListener.meta(copiedMessage);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] addControllerEventListener(ControllerEventListener listener, int[] anControllers)
/*     */   {
/* 465 */     synchronized (this.m_aControllerListeners)
/*     */     {
/* 467 */       if (anControllers == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 474 */         for (int i = 0; i < 128; i++)
/*     */         {
/* 476 */           addControllerListener(i, listener);
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 481 */         for (int i = 0; i < anControllers.length; i++)
/*     */         {
/* 483 */           addControllerListener(anControllers[i], listener);
/*     */         }
/*     */       }
/*     */     }
/* 487 */     return getListenedControllers(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addControllerListener(int i, ControllerEventListener listener)
/*     */   {
/* 495 */     if (this.m_aControllerListeners[i] == null)
/*     */     {
/* 497 */       this.m_aControllerListeners[i] = new ArraySet();
/*     */     }
/* 499 */     this.m_aControllerListeners[i].add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] removeControllerEventListener(ControllerEventListener listener, int[] anControllers)
/*     */   {
/* 506 */     synchronized (this.m_aControllerListeners)
/*     */     {
/* 508 */       if (anControllers == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 514 */         for (int i = 0; i < 128; i++)
/*     */         {
/* 516 */           removeControllerListener(i, listener);
/*     */         }
/*     */         
/*     */       }
/*     */       else {
/* 521 */         for (int i = 0; i < anControllers.length; i++)
/*     */         {
/* 523 */           removeControllerListener(anControllers[i], listener);
/*     */         }
/*     */       }
/*     */     }
/* 527 */     return getListenedControllers(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void removeControllerListener(int i, ControllerEventListener listener)
/*     */   {
/* 535 */     if (this.m_aControllerListeners[i] != null)
/*     */     {
/* 537 */       this.m_aControllerListeners[i].add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] getListenedControllers(ControllerEventListener listener)
/*     */   {
/* 545 */     int[] anControllers = new int[''];
/* 546 */     int nIndex = 0;
/* 547 */     for (int nController = 0; nController < 128; nController++)
/*     */     {
/* 549 */       if ((this.m_aControllerListeners[nController] != null) && (this.m_aControllerListeners[nController].contains(listener)))
/*     */       {
/*     */ 
/* 552 */         anControllers[nIndex] = nController;
/* 553 */         nIndex++;
/*     */       }
/*     */     }
/* 556 */     int[] anResultControllers = new int[nIndex];
/* 557 */     System.arraycopy(anControllers, 0, anResultControllers, 0, nIndex);
/* 558 */     return anResultControllers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void sendControllerEvent(ShortMessage message)
/*     */   {
/* 565 */     int nController = message.getData1();
/* 566 */     if (this.m_aControllerListeners[nController] != null)
/*     */     {
/* 568 */       Iterator<ControllerEventListener> iterator = this.m_aControllerListeners[nController].iterator();
/* 569 */       while (iterator.hasNext())
/*     */       {
/* 571 */         ControllerEventListener controllerEventListener = (ControllerEventListener)iterator.next();
/* 572 */         ShortMessage copiedMessage = (ShortMessage)message.clone();
/* 573 */         controllerEventListener.controlChange(copiedMessage);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void notifyListeners(MidiMessage message)
/*     */   {
/* 582 */     if ((message instanceof MetaMessage))
/*     */     {
/*     */ 
/* 585 */       sendMetaMessage((MetaMessage)message);
/*     */     }
/* 587 */     else if (((message instanceof ShortMessage)) && (((ShortMessage)message).getCommand() == 176))
/*     */     {
/* 589 */       sendControllerEvent((ShortMessage)message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Sequencer.SyncMode getMasterSyncMode()
/*     */   {
/* 597 */     return this.m_masterSyncMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMasterSyncMode(Sequencer.SyncMode syncMode)
/*     */   {
/* 604 */     if (this.m_masterSyncModes.contains(syncMode))
/*     */     {
/* 606 */       if (!getMasterSyncMode().equals(syncMode))
/*     */       {
/* 608 */         this.m_masterSyncMode = syncMode;
/* 609 */         setMasterSyncModeImpl(syncMode);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 614 */       throw new IllegalArgumentException("sync mode not allowed: " + syncMode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setMasterSyncModeImpl(Sequencer.SyncMode syncMode) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sequencer.SyncMode[] getMasterSyncModes()
/*     */   {
/* 631 */     Sequencer.SyncMode[] syncModes = (Sequencer.SyncMode[])this.m_masterSyncModes.toArray(EMPTY_SYNCMODE_ARRAY);
/* 632 */     return syncModes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Sequencer.SyncMode getSlaveSyncMode()
/*     */   {
/* 639 */     return this.m_slaveSyncMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setSlaveSyncMode(Sequencer.SyncMode syncMode)
/*     */   {
/* 646 */     if (this.m_slaveSyncModes.contains(syncMode))
/*     */     {
/* 648 */       if (!getSlaveSyncMode().equals(syncMode))
/*     */       {
/* 650 */         this.m_slaveSyncMode = syncMode;
/* 651 */         setSlaveSyncModeImpl(syncMode);
/*     */       }
/*     */       
/*     */     }
/*     */     else {
/* 656 */       throw new IllegalArgumentException("sync mode not allowed: " + syncMode);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSlaveSyncModeImpl(Sequencer.SyncMode syncMode) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Sequencer.SyncMode[] getSlaveSyncModes()
/*     */   {
/* 674 */     Sequencer.SyncMode[] syncModes = (Sequencer.SyncMode[])this.m_slaveSyncModes.toArray(EMPTY_SYNCMODE_ARRAY);
/* 675 */     return syncModes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getTrackSolo(int nTrack)
/*     */   {
/* 682 */     boolean bSoloed = false;
/* 683 */     if (getSequence() != null)
/*     */     {
/* 685 */       if (nTrack < getSequence().getTracks().length)
/*     */       {
/* 687 */         bSoloed = this.m_soloBitSet.get(nTrack);
/*     */       }
/*     */     }
/* 690 */     return bSoloed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTrackSolo(int nTrack, boolean bSolo)
/*     */   {
/* 697 */     if (getSequence() != null)
/*     */     {
/* 699 */       if (nTrack < getSequence().getTracks().length)
/*     */       {
/* 701 */         boolean bOldState = this.m_soloBitSet.get(nTrack);
/* 702 */         if (bSolo != bOldState)
/*     */         {
/* 704 */           if (bSolo)
/*     */           {
/* 706 */             this.m_soloBitSet.set(nTrack);
/*     */           }
/*     */           else
/*     */           {
/* 710 */             this.m_soloBitSet.clear(nTrack);
/*     */           }
/* 712 */           updateEnabled();
/* 713 */           setTrackSoloImpl(nTrack, bSolo);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setTrackSoloImpl(int nTrack, boolean bSolo) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getTrackMute(int nTrack)
/*     */   {
/* 729 */     boolean bMuted = false;
/* 730 */     if (getSequence() != null)
/*     */     {
/* 732 */       if (nTrack < getSequence().getTracks().length)
/*     */       {
/* 734 */         bMuted = this.m_muteBitSet.get(nTrack);
/*     */       }
/*     */     }
/* 737 */     return bMuted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTrackMute(int nTrack, boolean bMute)
/*     */   {
/* 744 */     if (getSequence() != null)
/*     */     {
/* 746 */       if (nTrack < getSequence().getTracks().length)
/*     */       {
/* 748 */         boolean bOldState = this.m_muteBitSet.get(nTrack);
/* 749 */         if (bMute != bOldState)
/*     */         {
/* 751 */           if (bMute)
/*     */           {
/* 753 */             this.m_muteBitSet.set(nTrack);
/*     */           }
/*     */           else
/*     */           {
/* 757 */             this.m_muteBitSet.clear(nTrack);
/*     */           }
/* 759 */           updateEnabled();
/* 760 */           setTrackMuteImpl(nTrack, bMute);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setTrackMuteImpl(int nTrack, boolean bMute) {}
/*     */   
/*     */ 
/*     */ 
/*     */   private void updateEnabled()
/*     */   {
/* 775 */     BitSet oldEnabledBitSet = (BitSet)this.m_enabledBitSet.clone();
/* 776 */     boolean bSoloExists = this.m_soloBitSet.length() > 0;
/* 777 */     if (bSoloExists)
/*     */     {
/* 779 */       this.m_enabledBitSet = ((BitSet)this.m_soloBitSet.clone());
/*     */     }
/*     */     else
/*     */     {
/* 783 */       for (int i = 0; i < this.m_muteBitSet.size(); i++)
/*     */       {
/* 785 */         if (this.m_muteBitSet.get(i))
/*     */         {
/* 787 */           this.m_enabledBitSet.clear(i);
/*     */         }
/*     */         else
/*     */         {
/* 791 */           this.m_enabledBitSet.set(i);
/*     */         }
/*     */       }
/*     */     }
/* 795 */     oldEnabledBitSet.xor(this.m_enabledBitSet);
/*     */     
/*     */ 
/*     */ 
/* 799 */     for (int i = 0; i < oldEnabledBitSet.size(); i++)
/*     */     {
/* 801 */       if (oldEnabledBitSet.get(i))
/*     */       {
/* 803 */         setTrackEnabledImpl(i, this.m_enabledBitSet.get(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setTrackEnabledImpl(int nTrack, boolean bEnabled) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isTrackEnabled(int nTrack)
/*     */   {
/* 828 */     return this.m_enabledBitSet.get(nTrack);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLatency(int nMilliseconds) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLatency()
/*     */   {
/* 851 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\TSequencer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */