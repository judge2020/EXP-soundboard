/*     */ package org.tritonus.share.midi;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MidiUtils
/*     */ {
/*     */   public static int getUnsignedInteger(byte b)
/*     */   {
/*  47 */     return b < 0 ? b + 256 : b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int get14bitValue(int nLSB, int nMSB)
/*     */   {
/*  54 */     return nLSB & 0x7F | (nMSB & 0x7F) << 7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int get14bitMSB(int nValue)
/*     */   {
/*  61 */     return nValue >> 7 & 0x7F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int get14bitLSB(int nValue)
/*     */   {
/*  68 */     return nValue & 0x7F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static byte[] getVariableLengthQuantity(long lValue)
/*     */   {
/*  75 */     ByteArrayOutputStream data = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/*  78 */       writeVariableLengthQuantity(lValue, data);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  82 */       if (TDebug.TraceAllExceptions) TDebug.out(e);
/*     */     }
/*  84 */     return data.toByteArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int writeVariableLengthQuantity(long lValue, OutputStream outputStream)
/*     */     throws IOException
/*     */   {
/*  92 */     int nLength = 0;
/*     */     
/*  94 */     boolean bWritingStarted = false;
/*  95 */     int nByte = (int)(lValue >> 21 & 0x7F);
/*  96 */     if (nByte != 0)
/*     */     {
/*  98 */       if (outputStream != null)
/*     */       {
/* 100 */         outputStream.write(nByte | 0x80);
/*     */       }
/* 102 */       nLength++;
/* 103 */       bWritingStarted = true;
/*     */     }
/* 105 */     nByte = (int)(lValue >> 14 & 0x7F);
/* 106 */     if ((nByte != 0) || (bWritingStarted))
/*     */     {
/* 108 */       if (outputStream != null)
/*     */       {
/* 110 */         outputStream.write(nByte | 0x80);
/*     */       }
/* 112 */       nLength++;
/* 113 */       bWritingStarted = true;
/*     */     }
/* 115 */     nByte = (int)(lValue >> 7 & 0x7F);
/* 116 */     if ((nByte != 0) || (bWritingStarted))
/*     */     {
/* 118 */       if (outputStream != null)
/*     */       {
/* 120 */         outputStream.write(nByte | 0x80);
/*     */       }
/* 122 */       nLength++;
/*     */     }
/* 124 */     nByte = (int)(lValue & 0x7F);
/* 125 */     if (outputStream != null)
/*     */     {
/* 127 */       outputStream.write(nByte);
/*     */     }
/* 129 */     nLength++;
/* 130 */     return nLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\MidiUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */