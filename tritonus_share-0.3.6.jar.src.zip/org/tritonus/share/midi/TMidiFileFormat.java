/*    */ package org.tritonus.share.midi;
/*    */ 
/*    */ import javax.sound.midi.MidiFileFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TMidiFileFormat
/*    */   extends MidiFileFormat
/*    */ {
/*    */   private int m_nTrackCount;
/*    */   
/*    */   public TMidiFileFormat(int nType, float fDivisionType, int nResolution, int nByteLength, long lMicrosecondLength, int nTrackCount)
/*    */   {
/* 56 */     super(nType, fDivisionType, nResolution, nByteLength, lMicrosecondLength);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 61 */     this.m_nTrackCount = nTrackCount;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getTrackCount()
/*    */   {
/* 68 */     return this.m_nTrackCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\TMidiFileFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */