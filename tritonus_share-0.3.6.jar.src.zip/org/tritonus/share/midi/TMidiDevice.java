/*     */ package org.tritonus.share.midi;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.sound.midi.InvalidMidiDataException;
/*     */ import javax.sound.midi.MetaMessage;
/*     */ import javax.sound.midi.MidiDevice;
/*     */ import javax.sound.midi.MidiDevice.Info;
/*     */ import javax.sound.midi.MidiMessage;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.Receiver;
/*     */ import javax.sound.midi.Transmitter;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TMidiDevice
/*     */   implements MidiDevice
/*     */ {
/*     */   private MidiDevice.Info m_info;
/*     */   private boolean m_bOpen;
/*     */   private boolean m_bUseIn;
/*     */   private boolean m_bUseOut;
/*     */   private List<Receiver> m_receivers;
/*     */   private List<Transmitter> m_transmitters;
/*     */   
/*     */   public TMidiDevice(MidiDevice.Info info)
/*     */   {
/* 102 */     this(info, true, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TMidiDevice(MidiDevice.Info info, boolean bUseIn, boolean bUseOut)
/*     */   {
/* 118 */     this.m_info = info;
/* 119 */     this.m_bUseIn = bUseIn;
/* 120 */     this.m_bUseOut = bUseOut;
/* 121 */     this.m_bOpen = false;
/* 122 */     this.m_receivers = new ArrayList();
/* 123 */     this.m_transmitters = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MidiDevice.Info getDeviceInfo()
/*     */   {
/* 137 */     return this.m_info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws MidiUnavailableException
/*     */   {
/* 145 */     if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.open(): begin");
/* 146 */     if (!isOpen())
/*     */     {
/* 148 */       this.m_bOpen = true;
/* 149 */       openImpl();
/*     */     }
/* 151 */     if (TDebug.TraceMidiDevice) { TDebug.out("TMidiDevice.open(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void openImpl()
/*     */     throws MidiUnavailableException
/*     */   {
/* 163 */     if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.openImpl(): begin");
/* 164 */     if (TDebug.TraceMidiDevice) { TDebug.out("TMidiDevice.openImpl(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */   {
/* 171 */     if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.close(): begin");
/* 172 */     if (isOpen())
/*     */     {
/* 174 */       closeImpl();
/*     */       
/* 176 */       this.m_bOpen = false;
/*     */     }
/* 178 */     if (TDebug.TraceMidiDevice) { TDebug.out("TMidiDevice.close(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void closeImpl()
/*     */   {
/* 189 */     if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.closeImpl(): begin");
/* 190 */     if (TDebug.TraceMidiDevice) { TDebug.out("TMidiDevice.closeImpl(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/* 197 */     return this.m_bOpen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean getUseIn()
/*     */   {
/* 210 */     return this.m_bUseIn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean getUseOut()
/*     */   {
/* 223 */     return this.m_bUseOut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondPosition()
/*     */   {
/* 235 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxReceivers()
/*     */   {
/* 242 */     int nMaxReceivers = 0;
/* 243 */     if (getUseOut())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 248 */       nMaxReceivers = -1;
/*     */     }
/* 250 */     return nMaxReceivers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMaxTransmitters()
/*     */   {
/* 257 */     int nMaxTransmitters = 0;
/* 258 */     if (getUseIn())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 263 */       nMaxTransmitters = -1;
/*     */     }
/* 265 */     return nMaxTransmitters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Receiver getReceiver()
/*     */     throws MidiUnavailableException
/*     */   {
/* 277 */     if (!getUseOut())
/*     */     {
/* 279 */       throw new MidiUnavailableException("Receivers are not supported by this device");
/*     */     }
/* 281 */     return new TReceiver();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transmitter getTransmitter()
/*     */     throws MidiUnavailableException
/*     */   {
/* 293 */     if (!getUseIn())
/*     */     {
/* 295 */       throw new MidiUnavailableException("Transmitters are not supported by this device");
/*     */     }
/* 297 */     return new TTransmitter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Receiver> getReceivers()
/*     */   {
/* 304 */     return Collections.unmodifiableList(this.m_receivers);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Transmitter> getTransmitters()
/*     */   {
/* 310 */     return Collections.unmodifiableList(this.m_transmitters);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void receive(MidiMessage message, long lTimeStamp)
/*     */   {
/* 321 */     if (TDebug.TraceMidiDevice) { TDebug.out("### [should be overridden] TMidiDevice.receive(): message " + message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addReceiver(Receiver receiver)
/*     */   {
/* 328 */     synchronized (this.m_receivers)
/*     */     {
/* 330 */       this.m_receivers.add(receiver);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void removeReceiver(Receiver receiver)
/*     */   {
/* 338 */     synchronized (this.m_receivers)
/*     */     {
/* 340 */       this.m_receivers.remove(receiver);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addTransmitter(Transmitter transmitter)
/*     */   {
/* 349 */     synchronized (this.m_transmitters)
/*     */     {
/* 351 */       this.m_transmitters.add(transmitter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void removeTransmitter(Transmitter transmitter)
/*     */   {
/* 358 */     synchronized (this.m_transmitters)
/*     */     {
/* 360 */       this.m_transmitters.remove(transmitter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void sendImpl(MidiMessage message, long lTimeStamp)
/*     */   {
/* 372 */     if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.sendImpl(): begin");
/* 373 */     Iterator transmitters = this.m_transmitters.iterator();
/* 374 */     while (transmitters.hasNext())
/*     */     {
/* 376 */       TTransmitter transmitter = (TTransmitter)transmitters.next();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 382 */       MidiMessage copiedMessage = null;
/* 383 */       if ((message instanceof MetaMessage))
/*     */       {
/* 385 */         MetaMessage origMessage = (MetaMessage)message;
/* 386 */         MetaMessage metaMessage = new MetaMessage();
/*     */         try
/*     */         {
/* 389 */           metaMessage.setMessage(origMessage.getType(), origMessage.getData(), origMessage.getData().length);
/*     */         }
/*     */         catch (InvalidMidiDataException e)
/*     */         {
/* 393 */           if (TDebug.TraceAllExceptions) TDebug.out(e);
/*     */         }
/* 395 */         copiedMessage = metaMessage;
/*     */       }
/*     */       else
/*     */       {
/* 399 */         copiedMessage = (MidiMessage)message.clone();
/*     */       }
/*     */       
/* 402 */       if ((message instanceof MetaMessage))
/*     */       {
/* 404 */         if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.sendImpl(): MetaMessage.getData().length (original): " + ((MetaMessage)message).getData().length);
/* 405 */         if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.sendImpl(): MetaMessage.getData().length (cloned): " + ((MetaMessage)copiedMessage).getData().length);
/*     */       }
/* 407 */       transmitter.send(copiedMessage, lTimeStamp);
/*     */     }
/* 409 */     if (TDebug.TraceMidiDevice) { TDebug.out("TMidiDevice.sendImpl(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public class TReceiver
/*     */     implements Receiver
/*     */   {
/*     */     private boolean m_bOpen;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public TReceiver()
/*     */     {
/* 431 */       TMidiDevice.this.addReceiver(this);
/* 432 */       this.m_bOpen = true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected boolean isOpen()
/*     */     {
/* 439 */       return this.m_bOpen;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void send(MidiMessage message, long lTimeStamp)
/*     */     {
/* 449 */       if (TDebug.TraceMidiDevice) TDebug.out("TMidiDevice.TReceiver.send(): message " + message);
/* 450 */       if (this.m_bOpen)
/*     */       {
/* 452 */         TMidiDevice.this.receive(message, lTimeStamp);
/*     */       }
/*     */       else
/*     */       {
/* 456 */         throw new IllegalStateException("receiver is not open");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void close()
/*     */     {
/* 468 */       TMidiDevice.this.removeReceiver(this);
/* 469 */       this.m_bOpen = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public class TTransmitter
/*     */     implements Transmitter
/*     */   {
/*     */     private boolean m_bOpen;
/*     */     
/*     */ 
/*     */     private Receiver m_receiver;
/*     */     
/*     */ 
/*     */     public TTransmitter()
/*     */     {
/* 486 */       this.m_bOpen = true;
/* 487 */       TMidiDevice.this.addTransmitter(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setReceiver(Receiver receiver)
/*     */     {
/* 494 */       synchronized (this)
/*     */       {
/* 496 */         this.m_receiver = receiver;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Receiver getReceiver()
/*     */     {
/* 504 */       return this.m_receiver;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void send(MidiMessage message, long lTimeStamp)
/*     */     {
/* 511 */       if ((getReceiver() != null) && (this.m_bOpen))
/*     */       {
/* 513 */         getReceiver().send(message, lTimeStamp);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void close()
/*     */     {
/* 526 */       TMidiDevice.this.removeTransmitter(this);
/* 527 */       this.m_bOpen = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class Info
/*     */     extends MidiDevice.Info
/*     */   {
/*     */     public Info(String a, String b, String c, String d)
/*     */     {
/* 548 */       super(b, c, d);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\TMidiDevice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */