/*     */ package org.tritonus.share.midi;
/*     */ 
/*     */ import javax.sound.midi.MidiChannel;
/*     */ import javax.sound.midi.MidiDevice.Info;
/*     */ import javax.sound.midi.MidiMessage;
/*     */ import javax.sound.midi.MidiUnavailableException;
/*     */ import javax.sound.midi.ShortMessage;
/*     */ import javax.sound.midi.Synthesizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TDirectSynthesizer
/*     */   extends TMidiDevice
/*     */   implements Synthesizer
/*     */ {
/*     */   private int[] m_anBanks;
/*     */   
/*     */   public TDirectSynthesizer(MidiDevice.Info info)
/*     */   {
/*  74 */     super(info, false, true);
/*  75 */     this.m_anBanks = new int[16];
/*  76 */     for (int i = 0; i < this.m_anBanks.length; i++)
/*     */     {
/*  78 */       this.m_anBanks[i] = -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void openImpl()
/*     */     throws MidiUnavailableException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void closeImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void receive(MidiMessage message, long lTimeStamp)
/*     */   {
/* 111 */     if ((message instanceof ShortMessage))
/*     */     {
/* 113 */       ShortMessage shortMsg = (ShortMessage)message;
/* 114 */       int nChannel = shortMsg.getChannel();
/* 115 */       int nCommand = shortMsg.getCommand();
/* 116 */       int nData1 = shortMsg.getData1();
/* 117 */       int nData2 = shortMsg.getData2();
/* 118 */       switch (nCommand)
/*     */       {
/*     */       case 128: 
/* 121 */         getChannel(nChannel).noteOff(nData1, nData2);
/* 122 */         break;
/*     */       
/*     */       case 144: 
/* 125 */         getChannel(nChannel).noteOn(nData1, nData2);
/* 126 */         break;
/*     */       
/*     */       case 160: 
/* 129 */         getChannel(nChannel).setPolyPressure(nData1, nData2);
/* 130 */         break;
/*     */       
/*     */       case 176: 
/* 133 */         switch (nData1)
/*     */         {
/*     */         case 0: 
/* 136 */           this.m_anBanks[nChannel] = (nData2 << 7);
/* 137 */           break;
/*     */         
/*     */         case 32: 
/* 140 */           this.m_anBanks[nChannel] |= nData2;
/* 141 */           break;
/*     */         
/*     */         case 120: 
/* 144 */           getChannel(nChannel).allSoundOff();
/* 145 */           break;
/*     */         
/*     */         case 121: 
/* 148 */           getChannel(nChannel).resetAllControllers();
/* 149 */           break;
/*     */         
/*     */         case 122: 
/* 152 */           getChannel(nChannel).localControl(nData2 == 127);
/* 153 */           break;
/*     */         
/*     */         case 123: 
/* 156 */           getChannel(nChannel).allNotesOff();
/* 157 */           break;
/*     */         
/*     */         case 124: 
/* 160 */           getChannel(nChannel).setOmni(false);
/* 161 */           break;
/*     */         
/*     */         case 125: 
/* 164 */           getChannel(nChannel).setOmni(true);
/* 165 */           break;
/*     */         
/*     */         case 126: 
/* 168 */           getChannel(nChannel).setMono(true);
/* 169 */           break;
/*     */         
/*     */         case 127: 
/* 172 */           getChannel(nChannel).setMono(false);
/* 173 */           break;
/*     */         
/*     */         default: 
/* 176 */           getChannel(nChannel).controlChange(nData1, nData2); }
/* 177 */         break;
/*     */       
/*     */ 
/*     */ 
/*     */       case 192: 
/* 182 */         if (this.m_anBanks[nChannel] != -1)
/*     */         {
/* 184 */           getChannel(nChannel).programChange(this.m_anBanks[nChannel], nData1);
/*     */           
/* 186 */           this.m_anBanks[nChannel] = -1;
/*     */         }
/*     */         else
/*     */         {
/* 190 */           getChannel(nChannel).programChange(nData1);
/*     */         }
/* 192 */         break;
/*     */       
/*     */       case 208: 
/* 195 */         getChannel(nChannel).setChannelPressure(nData1);
/* 196 */         break;
/*     */       
/*     */       case 224: 
/* 199 */         getChannel(nChannel).setPitchBend(nData1 | nData2 << 7);
/* 200 */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private MidiChannel getChannel(int nChannel)
/*     */   {
/* 209 */     return getChannels()[nChannel];
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\TDirectSynthesizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */