/*     */ package org.tritonus.share.midi;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.sound.midi.MidiDevice.Info;
/*     */ import javax.sound.midi.MidiMessage;
/*     */ import javax.sound.midi.Sequencer.SyncMode;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TPreloadingSequencer
/*     */   extends TSequencer
/*     */ {
/*     */   private static final int DEFAULT_LATENCY = 100;
/*     */   private int m_nLatency;
/*     */   private Thread m_loaderThread;
/*     */   
/*     */   protected TPreloadingSequencer(MidiDevice.Info info, Collection<Sequencer.SyncMode> masterSyncModes, Collection<Sequencer.SyncMode> slaveSyncModes)
/*     */   {
/*  82 */     super(info, masterSyncModes, slaveSyncModes);
/*     */     
/*  84 */     if (TDebug.TraceSequencer) TDebug.out("TPreloadingSequencer.<init>(): begin");
/*  85 */     this.m_nLatency = 100;
/*  86 */     if (TDebug.TraceSequencer) { TDebug.out("TPreloadingSequencer.<init>(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLatency(int nLatency)
/*     */   {
/* 102 */     this.m_nLatency = nLatency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLatency()
/*     */   {
/* 114 */     return this.m_nLatency;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void openImpl()
/*     */   {
/* 121 */     if (TDebug.TraceSequencer) TDebug.out("AlsaSequencer.openImpl(): begin");
/*     */   }
/*     */   
/*     */   public abstract void sendMessageTick(MidiMessage paramMidiMessage, long paramLong);
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\midi\TPreloadingSequencer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */