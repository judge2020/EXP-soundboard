/*    */ package org.tritonus.share;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArraySet<E>
/*    */   extends ArrayList<E>
/*    */   implements Set<E>
/*    */ {
/*    */   public ArraySet() {}
/*    */   
/*    */   public ArraySet(Collection<E> c)
/*    */   {
/* 52 */     this();
/* 53 */     addAll(c);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean add(E element)
/*    */   {
/* 60 */     if (!contains(element))
/*    */     {
/* 62 */       super.add(element);
/* 63 */       return true;
/*    */     }
/*    */     
/*    */ 
/* 67 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void add(int index, E element)
/*    */   {
/* 75 */     throw new UnsupportedOperationException("ArraySet.add(int index, Object element) unsupported");
/*    */   }
/*    */   
/*    */   public E set(int index, E element)
/*    */   {
/* 80 */     throw new UnsupportedOperationException("ArraySet.set(int index, Object element) unsupported");
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\ArraySet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */