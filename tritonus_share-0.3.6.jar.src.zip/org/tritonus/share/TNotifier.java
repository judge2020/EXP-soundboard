/*     */ package org.tritonus.share;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.EventObject;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TNotifier
/*     */   extends Thread
/*     */ {
/*     */   public static class NotifyEntry
/*     */   {
/*     */     private EventObject m_event;
/*     */     private List<LineListener> m_listeners;
/*     */     
/*     */     public NotifyEntry(EventObject event, Collection<LineListener> listeners)
/*     */     {
/*  56 */       this.m_event = event;
/*  57 */       this.m_listeners = new ArrayList(listeners);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void deliver()
/*     */     {
/*  64 */       Iterator<LineListener> iterator = this.m_listeners.iterator();
/*  65 */       while (iterator.hasNext())
/*     */       {
/*  67 */         LineListener listener = (LineListener)iterator.next();
/*  68 */         listener.update((LineEvent)this.m_event);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  74 */   public static TNotifier notifier = null;
/*     */   private List<NotifyEntry> m_entries;
/*     */   
/*     */   static {
/*  78 */     notifier = new TNotifier();
/*  79 */     notifier.setDaemon(true);
/*  80 */     notifier.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TNotifier()
/*     */   {
/*  93 */     super("Tritonus Notifier");
/*  94 */     this.m_entries = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addEntry(EventObject event, Collection<LineListener> listeners)
/*     */   {
/* 102 */     synchronized (this.m_entries)
/*     */     {
/* 104 */       this.m_entries.add(new NotifyEntry(event, listeners));
/* 105 */       this.m_entries.notifyAll();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     for (;;)
/*     */     {
/* 115 */       NotifyEntry entry = null;
/* 116 */       synchronized (this.m_entries)
/*     */       {
/* 118 */         while (this.m_entries.size() == 0)
/*     */         {
/*     */           try
/*     */           {
/* 122 */             this.m_entries.wait();
/*     */           }
/*     */           catch (InterruptedException e)
/*     */           {
/* 126 */             if (TDebug.TraceAllExceptions)
/*     */             {
/* 128 */               TDebug.out(e);
/*     */             }
/*     */           }
/*     */         }
/* 132 */         entry = (NotifyEntry)this.m_entries.remove(0);
/*     */       }
/* 134 */       entry.deliver();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\TNotifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */