/*     */ package org.tritonus.share;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringHashedSet<E>
/*     */   extends ArraySet<E>
/*     */ {
/*     */   public StringHashedSet() {}
/*     */   
/*     */   public StringHashedSet(Collection<E> c)
/*     */   {
/*  70 */     super(c);
/*     */   }
/*     */   
/*     */   public boolean add(E elem)
/*     */   {
/*  75 */     if (elem == null) {
/*  76 */       return false;
/*     */     }
/*  78 */     return super.add(elem);
/*     */   }
/*     */   
/*     */   public boolean contains(Object elem)
/*     */   {
/*  83 */     if (elem == null) {
/*  84 */       return false;
/*     */     }
/*  86 */     String comp = elem.toString();
/*  87 */     Iterator<E> it = iterator();
/*  88 */     while (it.hasNext()) {
/*  89 */       if (comp.equals(it.next().toString())) {
/*  90 */         return true;
/*     */       }
/*     */     }
/*  93 */     return false;
/*     */   }
/*     */   
/*     */   public E get(E elem) {
/*  97 */     if (elem == null) {
/*  98 */       return null;
/*     */     }
/* 100 */     String comp = elem.toString();
/* 101 */     Iterator<E> it = iterator();
/* 102 */     while (it.hasNext()) {
/* 103 */       E thisElem = it.next();
/* 104 */       if (comp.equals(thisElem.toString())) {
/* 105 */         return thisElem;
/*     */       }
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\StringHashedSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */