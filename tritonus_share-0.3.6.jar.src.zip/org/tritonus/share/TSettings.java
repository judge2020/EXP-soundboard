/*    */ package org.tritonus.share;
/*    */ 
/*    */ import java.security.AccessControlException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TSettings
/*    */ {
/* 42 */   public static boolean SHOW_ACCESS_CONTROL_EXCEPTIONS = false;
/*    */   
/*    */   private static final String PROPERTY_PREFIX = "tritonus.";
/*    */   
/* 46 */   public static boolean AlsaUsePlughw = getBooleanProperty("AlsaUsePlughw");
/*    */   
/*    */ 
/*    */ 
/*    */   private static boolean getBooleanProperty(String strName)
/*    */   {
/* 52 */     String strPropertyName = "tritonus." + strName;
/* 53 */     String strValue = "false";
/*    */     try
/*    */     {
/* 56 */       strValue = System.getProperty(strPropertyName, "false");
/*    */     }
/*    */     catch (AccessControlException e)
/*    */     {
/* 60 */       if (SHOW_ACCESS_CONTROL_EXCEPTIONS)
/*    */       {
/* 62 */         TDebug.out(e);
/*    */       }
/*    */     }
/*    */     
/* 66 */     boolean bValue = strValue.toLowerCase().equals("true");
/*    */     
/* 68 */     return bValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\TSettings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */