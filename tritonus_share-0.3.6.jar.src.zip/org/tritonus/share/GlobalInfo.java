/*    */ package org.tritonus.share;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalInfo
/*    */ {
/*    */   private static final String VENDOR = "Tritonus is free software. See http://www.tritonus.org/";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String VERSION = "0.3.1";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getVendor()
/*    */   {
/* 46 */     return "Tritonus is free software. See http://www.tritonus.org/";
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static String getVersion()
/*    */   {
/* 53 */     return "0.3.1";
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\GlobalInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */