/*     */ package org.tritonus.share.sampled.file;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import javax.sound.sampled.AudioFileFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.UnsupportedAudioFileException;
/*     */ import javax.sound.sampled.spi.AudioFileReader;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TAudioFileReader
/*     */   extends AudioFileReader
/*     */ {
/*  66 */   private int m_nMarkLimit = -1;
/*     */   
/*     */   private boolean m_bRereading;
/*     */   
/*     */   protected TAudioFileReader(int nMarkLimit)
/*     */   {
/*  72 */     this(nMarkLimit, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected TAudioFileReader(int nMarkLimit, boolean bRereading)
/*     */   {
/*  79 */     this.m_nMarkLimit = nMarkLimit;
/*  80 */     this.m_bRereading = bRereading;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getMarkLimit()
/*     */   {
/*  87 */     return this.m_nMarkLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isRereading()
/*     */   {
/*  94 */     return this.m_bRereading;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFileFormat getAudioFileFormat(File file)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 112 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(File): begin");
/* 113 */     long lFileLengthInBytes = file.length();
/* 114 */     InputStream inputStream = new FileInputStream(file);
/* 115 */     AudioFileFormat audioFileFormat = null;
/*     */     try
/*     */     {
/* 118 */       audioFileFormat = getAudioFileFormat(inputStream, lFileLengthInBytes);
/*     */     }
/*     */     finally
/*     */     {
/* 122 */       inputStream.close();
/*     */     }
/* 124 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(File): end");
/* 125 */     return audioFileFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFileFormat getAudioFileFormat(URL url)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 144 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(URL): begin");
/* 145 */     long lFileLengthInBytes = getDataLength(url);
/* 146 */     InputStream inputStream = url.openStream();
/* 147 */     AudioFileFormat audioFileFormat = null;
/*     */     try
/*     */     {
/* 150 */       audioFileFormat = getAudioFileFormat(inputStream, lFileLengthInBytes);
/*     */     }
/*     */     finally
/*     */     {
/* 154 */       inputStream.close();
/*     */     }
/* 156 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(URL): end");
/* 157 */     return audioFileFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFileFormat getAudioFileFormat(InputStream inputStream)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 176 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(InputStream): begin");
/* 177 */     long lFileLengthInBytes = -1L;
/* 178 */     inputStream.mark(getMarkLimit());
/* 179 */     AudioFileFormat audioFileFormat = null;
/*     */     try
/*     */     {
/* 182 */       audioFileFormat = getAudioFileFormat(inputStream, lFileLengthInBytes);
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/* 190 */       inputStream.reset();
/*     */     }
/* 192 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioFileFormat(InputStream): end");
/* 193 */     return audioFileFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract AudioFileFormat getAudioFileFormat(InputStream paramInputStream, long paramLong)
/*     */     throws UnsupportedAudioFileException, IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioInputStream getAudioInputStream(File file)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 239 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(File): begin");
/* 240 */     long lFileLengthInBytes = file.length();
/* 241 */     InputStream inputStream = new FileInputStream(file);
/* 242 */     AudioInputStream audioInputStream = null;
/*     */     try
/*     */     {
/* 245 */       audioInputStream = getAudioInputStream(inputStream, lFileLengthInBytes);
/*     */     }
/*     */     catch (UnsupportedAudioFileException e)
/*     */     {
/* 249 */       inputStream.close();
/* 250 */       throw e;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 254 */       inputStream.close();
/* 255 */       throw e;
/*     */     }
/* 257 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(File): end");
/* 258 */     return audioInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioInputStream getAudioInputStream(URL url)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 277 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(URL): begin");
/* 278 */     long lFileLengthInBytes = getDataLength(url);
/* 279 */     InputStream inputStream = url.openStream();
/* 280 */     AudioInputStream audioInputStream = null;
/*     */     try
/*     */     {
/* 283 */       audioInputStream = getAudioInputStream(inputStream, lFileLengthInBytes);
/*     */     }
/*     */     catch (UnsupportedAudioFileException e)
/*     */     {
/* 287 */       inputStream.close();
/* 288 */       throw e;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 292 */       inputStream.close();
/* 293 */       throw e;
/*     */     }
/* 295 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(URL): end");
/* 296 */     return audioInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioInputStream getAudioInputStream(InputStream inputStream)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 315 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(InputStream): begin");
/* 316 */     long lFileLengthInBytes = -1L;
/* 317 */     AudioInputStream audioInputStream = null;
/* 318 */     inputStream.mark(getMarkLimit());
/*     */     try
/*     */     {
/* 321 */       audioInputStream = getAudioInputStream(inputStream, lFileLengthInBytes);
/*     */     }
/*     */     catch (UnsupportedAudioFileException e)
/*     */     {
/* 325 */       inputStream.reset();
/* 326 */       throw e;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 330 */       inputStream.reset();
/* 331 */       throw e;
/*     */     }
/* 333 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(InputStream): end");
/* 334 */     return audioInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AudioInputStream getAudioInputStream(InputStream inputStream, long lFileLengthInBytes)
/*     */     throws UnsupportedAudioFileException, IOException
/*     */   {
/* 360 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(InputStream, long): begin");
/* 361 */     if (isRereading())
/*     */     {
/* 363 */       inputStream = new BufferedInputStream(inputStream, getMarkLimit());
/* 364 */       inputStream.mark(getMarkLimit());
/*     */     }
/* 366 */     AudioFileFormat audioFileFormat = getAudioFileFormat(inputStream, lFileLengthInBytes);
/* 367 */     if (isRereading())
/*     */     {
/* 369 */       inputStream.reset();
/*     */     }
/* 371 */     AudioInputStream audioInputStream = new AudioInputStream(inputStream, audioFileFormat.getFormat(), audioFileFormat.getFrameLength());
/*     */     
/*     */ 
/*     */ 
/* 375 */     if (TDebug.TraceAudioFileReader) TDebug.out("TAudioFileReader.getAudioInputStream(InputStream, long): end");
/* 376 */     return audioInputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static int calculateFrameSize(int nSampleSize, int nNumChannels)
/*     */   {
/* 383 */     return (nSampleSize + 7) / 8 * nNumChannels;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static long getDataLength(URL url)
/*     */     throws IOException
/*     */   {
/* 391 */     long lFileLengthInBytes = -1L;
/* 392 */     URLConnection connection = url.openConnection();
/* 393 */     connection.connect();
/* 394 */     int nLength = connection.getContentLength();
/* 395 */     if (nLength > 0)
/*     */     {
/* 397 */       lFileLengthInBytes = nLength;
/*     */     }
/* 399 */     return lFileLengthInBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static int readLittleEndianInt(InputStream is)
/*     */     throws IOException
/*     */   {
/* 407 */     int b0 = is.read();
/* 408 */     int b1 = is.read();
/* 409 */     int b2 = is.read();
/* 410 */     int b3 = is.read();
/* 411 */     if ((b0 | b1 | b2 | b3) < 0)
/*     */     {
/* 413 */       throw new EOFException();
/*     */     }
/* 415 */     return (b3 << 24) + (b2 << 16) + (b1 << 8) + (b0 << 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static short readLittleEndianShort(InputStream is)
/*     */     throws IOException
/*     */   {
/* 423 */     int b0 = is.read();
/* 424 */     int b1 = is.read();
/* 425 */     if ((b0 | b1) < 0)
/*     */     {
/* 427 */       throw new EOFException();
/*     */     }
/* 429 */     return (short)((b1 << 8) + (b0 << 0));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static double readIeeeExtended(DataInputStream dis)
/*     */     throws IOException
/*     */   {
/* 472 */     double f = 0.0D;
/* 473 */     int expon = 0;
/* 474 */     long hiMant = 0L;
/* 475 */     long loMant = 0L;
/* 476 */     double HUGE = 3.4028234663852886E38D;
/* 477 */     expon = dis.readUnsignedShort();
/* 478 */     long t1 = dis.readUnsignedShort();
/* 479 */     long t2 = dis.readUnsignedShort();
/* 480 */     hiMant = t1 << 16 | t2;
/* 481 */     t1 = dis.readUnsignedShort();
/* 482 */     t2 = dis.readUnsignedShort();
/* 483 */     loMant = t1 << 16 | t2;
/* 484 */     if ((expon == 0) && (hiMant == 0L) && (loMant == 0L))
/*     */     {
/* 486 */       f = 0.0D;
/*     */ 
/*     */ 
/*     */     }
/* 490 */     else if (expon == 32767)
/*     */     {
/* 492 */       f = HUGE;
/*     */     }
/*     */     else
/*     */     {
/* 496 */       expon -= 16383;
/* 497 */       expon -= 31;
/* 498 */       f = hiMant * Math.pow(2.0D, expon);
/* 499 */       expon -= 32;
/* 500 */       f += loMant * Math.pow(2.0D, expon);
/*     */     }
/*     */     
/* 503 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TAudioFileReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */