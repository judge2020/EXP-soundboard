/*     */ package org.tritonus.share.sampled.file;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sound.sampled.AudioFileFormat;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TAudioFileFormat
/*     */   extends AudioFileFormat
/*     */ {
/*     */   private Map<String, Object> m_properties;
/*     */   private Map<String, Object> m_unmodifiableProperties;
/*     */   
/*     */   public TAudioFileFormat(AudioFileFormat.Type type, AudioFormat audioFormat, int nLengthInFrames, int nLengthInBytes)
/*     */   {
/*  66 */     super(type, nLengthInBytes, audioFormat, nLengthInFrames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TAudioFileFormat(AudioFileFormat.Type type, AudioFormat audioFormat, int nLengthInFrames, int nLengthInBytes, Map<String, Object> properties)
/*     */   {
/*  79 */     super(type, nLengthInBytes, audioFormat, nLengthInFrames);
/*     */     
/*     */ 
/*     */ 
/*  83 */     initMaps(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initMaps(Map<String, Object> properties)
/*     */   {
/*  92 */     this.m_properties = new HashMap();
/*  93 */     this.m_properties.putAll(properties);
/*  94 */     this.m_unmodifiableProperties = Collections.unmodifiableMap(this.m_properties);
/*     */   }
/*     */   
/*     */ 
/*     */   public Map<String, Object> properties()
/*     */   {
/* 100 */     return this.m_unmodifiableProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setProperty(String key, Object value)
/*     */   {
/* 107 */     this.m_properties.put(key, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TAudioFileFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */