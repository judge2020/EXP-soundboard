package org.tritonus.share.sampled.file;

import java.io.DataOutput;
import java.io.IOException;

public abstract interface TDataOutputStream
  extends DataOutput
{
  public abstract boolean supportsSeek();
  
  public abstract void seek(long paramLong)
    throws IOException;
  
  public abstract long getFilePointer()
    throws IOException;
  
  public abstract long length()
    throws IOException;
  
  public abstract void writeLittleEndian32(int paramInt)
    throws IOException;
  
  public abstract void writeLittleEndian16(short paramShort)
    throws IOException;
  
  public abstract void close()
    throws IOException;
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TDataOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */