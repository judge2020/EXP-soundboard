/*     */ package org.tritonus.share.sampled.file;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TAudioOutputStream
/*     */   implements AudioOutputStream
/*     */ {
/*     */   private AudioFormat m_audioFormat;
/*     */   private long m_lLength;
/*     */   private long m_lCalculatedLength;
/*     */   private TDataOutputStream m_dataOutputStream;
/*     */   private boolean m_bDoBackPatching;
/*     */   private boolean m_bHeaderWritten;
/*     */   
/*     */   protected TAudioOutputStream(AudioFormat audioFormat, long lLength, TDataOutputStream dataOutputStream, boolean bDoBackPatching)
/*     */   {
/*  64 */     this.m_audioFormat = audioFormat;
/*  65 */     this.m_lLength = lLength;
/*  66 */     this.m_lCalculatedLength = 0L;
/*  67 */     this.m_dataOutputStream = dataOutputStream;
/*  68 */     this.m_bDoBackPatching = bDoBackPatching;
/*  69 */     this.m_bHeaderWritten = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AudioFormat getFormat()
/*     */   {
/*  76 */     return this.m_audioFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLength()
/*     */   {
/*  87 */     return this.m_lLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getCalculatedLength()
/*     */   {
/*  97 */     return this.m_lCalculatedLength;
/*     */   }
/*     */   
/*     */   protected TDataOutputStream getDataOutputStream()
/*     */   {
/* 102 */     return this.m_dataOutputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(byte[] abData, int nOffset, int nLength)
/*     */     throws IOException
/*     */   {
/* 112 */     if (TDebug.TraceAudioOutputStream)
/*     */     {
/* 114 */       TDebug.out("TAudioOutputStream.write(): wanted length: " + nLength);
/*     */     }
/* 116 */     if (!this.m_bHeaderWritten)
/*     */     {
/* 118 */       writeHeader();
/* 119 */       this.m_bHeaderWritten = true;
/*     */     }
/*     */     
/*     */ 
/* 123 */     long lTotalLength = getLength();
/* 124 */     if ((lTotalLength != -1L) && (this.m_lCalculatedLength + nLength > lTotalLength)) {
/* 125 */       if (TDebug.TraceAudioOutputStream) {
/* 126 */         TDebug.out("TAudioOutputStream.write(): requested more bytes to write than possible.");
/*     */       }
/* 128 */       nLength = (int)(lTotalLength - this.m_lCalculatedLength);
/*     */       
/* 130 */       if (nLength < 0) {
/* 131 */         nLength = 0;
/*     */       }
/*     */     }
/*     */     
/* 135 */     if (nLength > 0) {
/* 136 */       this.m_dataOutputStream.write(abData, nOffset, nLength);
/* 137 */       this.m_lCalculatedLength += nLength;
/*     */     }
/* 139 */     if (TDebug.TraceAudioOutputStream)
/*     */     {
/* 141 */       TDebug.out("TAudioOutputStream.write(): calculated (total) length: " + this.m_lCalculatedLength + " bytes = " + this.m_lCalculatedLength / getFormat().getFrameSize() + " frames");
/*     */     }
/* 143 */     return nLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void writeHeader()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 162 */     if (TDebug.TraceAudioOutputStream)
/*     */     {
/* 164 */       TDebug.out("TAudioOutputStream.close(): called");
/*     */     }
/*     */     
/* 167 */     if (this.m_bDoBackPatching)
/*     */     {
/* 169 */       if (TDebug.TraceAudioOutputStream)
/*     */       {
/* 171 */         TDebug.out("TAudioOutputStream.close(): patching header");
/*     */       }
/* 173 */       patchHeader();
/*     */     }
/* 175 */     this.m_dataOutputStream.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void patchHeader()
/*     */     throws IOException
/*     */   {
/* 183 */     TDebug.out("TAudioOutputStream.patchHeader(): called");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setLengthFromCalculatedLength()
/*     */   {
/* 191 */     this.m_lLength = this.m_lCalculatedLength;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TAudioOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */