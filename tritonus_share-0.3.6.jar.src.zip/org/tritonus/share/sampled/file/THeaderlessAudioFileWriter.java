/*    */ package org.tritonus.share.sampled.file;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Collection;
/*    */ import javax.sound.sampled.AudioFileFormat.Type;
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ import org.tritonus.share.TDebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class THeaderlessAudioFileWriter
/*    */   extends TAudioFileWriter
/*    */ {
/*    */   protected THeaderlessAudioFileWriter(Collection<AudioFileFormat.Type> fileTypes, Collection<AudioFormat> audioFormats)
/*    */   {
/* 57 */     super(fileTypes, audioFormats);
/* 58 */     if (TDebug.TraceAudioFileWriter) TDebug.out("THeaderlessAudioFileWriter.<init>(): begin");
/* 59 */     if (TDebug.TraceAudioFileWriter) { TDebug.out("THeaderlessAudioFileWriter.<init>(): end");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AudioOutputStream getAudioOutputStream(AudioFormat audioFormat, long lLengthInBytes, AudioFileFormat.Type fileType, TDataOutputStream dataOutputStream)
/*    */     throws IOException
/*    */   {
/* 71 */     if (TDebug.TraceAudioFileWriter) TDebug.out("THeaderlessAudioFileWriter.getAudioOutputStream(): begin");
/* 72 */     AudioOutputStream aos = new HeaderlessAudioOutputStream(audioFormat, lLengthInBytes, dataOutputStream);
/*    */     
/*    */ 
/*    */ 
/* 76 */     if (TDebug.TraceAudioFileWriter) TDebug.out("THeaderlessAudioFileWriter.getAudioOutputStream(): end");
/* 77 */     return aos;
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\THeaderlessAudioFileWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */