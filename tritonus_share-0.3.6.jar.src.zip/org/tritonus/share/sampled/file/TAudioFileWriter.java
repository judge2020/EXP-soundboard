/*     */ package org.tritonus.share.sampled.file;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.spi.AudioFileWriter;
/*     */ import org.tritonus.share.ArraySet;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.sampled.AudioFormats;
/*     */ import org.tritonus.share.sampled.AudioUtils;
/*     */ import org.tritonus.share.sampled.TConversionTool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TAudioFileWriter
/*     */   extends AudioFileWriter
/*     */ {
/*     */   protected static final int ALL = -1;
/*  70 */   public static AudioFormat.Encoding PCM_SIGNED = new AudioFormat.Encoding("PCM_SIGNED");
/*  71 */   public static AudioFormat.Encoding PCM_UNSIGNED = new AudioFormat.Encoding("PCM_UNSIGNED");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int BUFFER_LENGTH = 16384;
/*     */   
/*     */ 
/*     */ 
/*  80 */   protected static final AudioFileFormat.Type[] NULL_TYPE_ARRAY = new AudioFileFormat.Type[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Collection<AudioFileFormat.Type> m_audioFileTypes;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Collection<AudioFormat> m_audioFormats;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TAudioFileWriter(Collection<AudioFileFormat.Type> fileTypes, Collection<AudioFormat> audioFormats)
/*     */   {
/* 104 */     if (TDebug.TraceAudioFileWriter) TDebug.out("TAudioFileWriter.<init>(): begin");
/* 105 */     this.m_audioFileTypes = fileTypes;
/* 106 */     this.m_audioFormats = audioFormats;
/* 107 */     if (TDebug.TraceAudioFileWriter) { TDebug.out("TAudioFileWriter.<init>(): end");
/*     */     }
/*     */   }
/*     */   
/*     */   public AudioFileFormat.Type[] getAudioFileTypes()
/*     */   {
/* 113 */     return (AudioFileFormat.Type[])this.m_audioFileTypes.toArray(NULL_TYPE_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isFileTypeSupported(AudioFileFormat.Type fileType)
/*     */   {
/* 120 */     return this.m_audioFileTypes.contains(fileType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFileFormat.Type[] getAudioFileTypes(AudioInputStream audioInputStream)
/*     */   {
/* 131 */     AudioFormat format = audioInputStream.getFormat();
/* 132 */     ArraySet<AudioFileFormat.Type> res = new ArraySet();
/* 133 */     Iterator<AudioFileFormat.Type> it = this.m_audioFileTypes.iterator();
/* 134 */     while (it.hasNext()) {
/* 135 */       AudioFileFormat.Type thisType = (AudioFileFormat.Type)it.next();
/* 136 */       if (isAudioFormatSupportedImpl(format, thisType)) {
/* 137 */         res.add(thisType);
/*     */       }
/*     */     }
/* 140 */     return (AudioFileFormat.Type[])res.toArray(NULL_TYPE_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFileTypeSupported(AudioFileFormat.Type fileType, AudioInputStream audioInputStream)
/*     */   {
/* 149 */     return (isFileTypeSupported(fileType)) && ((isAudioFormatSupportedImpl(audioInputStream.getFormat(), fileType)) || (findConvertableFormat(audioInputStream.getFormat(), fileType) != null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(AudioInputStream audioInputStream, AudioFileFormat.Type fileType, File file)
/*     */     throws IOException
/*     */   {
/* 166 */     if (TDebug.TraceAudioFileWriter)
/*     */     {
/* 168 */       TDebug.out(">TAudioFileWriter.write(.., File): called");
/* 169 */       TDebug.out("class: " + getClass().getName());
/*     */     }
/*     */     
/* 172 */     if (!isFileTypeSupported(fileType)) {
/* 173 */       if (TDebug.TraceAudioFileWriter)
/*     */       {
/* 175 */         TDebug.out("< file type is not supported");
/*     */       }
/* 177 */       throw new IllegalArgumentException("file type is not supported.");
/*     */     }
/*     */     
/* 180 */     AudioFormat inputFormat = audioInputStream.getFormat();
/* 181 */     if (TDebug.TraceAudioFileWriter) TDebug.out("input format: " + inputFormat);
/* 182 */     AudioFormat outputFormat = null;
/* 183 */     boolean bNeedsConversion = false;
/* 184 */     if (isAudioFormatSupportedImpl(inputFormat, fileType))
/*     */     {
/* 186 */       if (TDebug.TraceAudioFileWriter) TDebug.out("input format is supported directely");
/* 187 */       outputFormat = inputFormat;
/* 188 */       bNeedsConversion = false;
/*     */     }
/*     */     else
/*     */     {
/* 192 */       if (TDebug.TraceAudioFileWriter) TDebug.out("input format is not supported directely; trying to find a convertable format");
/* 193 */       outputFormat = findConvertableFormat(inputFormat, fileType);
/* 194 */       if (outputFormat != null)
/*     */       {
/* 196 */         bNeedsConversion = true;
/*     */         
/*     */ 
/* 199 */         if ((outputFormat.getSampleSizeInBits() == 8) && (outputFormat.getEncoding().equals(inputFormat.getEncoding())))
/*     */         {
/* 201 */           bNeedsConversion = false;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 206 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< input format is not supported and not convertable.");
/* 207 */         throw new IllegalArgumentException("format not supported and not convertable");
/*     */       }
/*     */     }
/* 210 */     long lLengthInBytes = AudioUtils.getLengthInBytes(audioInputStream);
/* 211 */     TDataOutputStream dataOutputStream = new TSeekableDataOutputStream(file);
/* 212 */     AudioOutputStream audioOutputStream = getAudioOutputStream(outputFormat, lLengthInBytes, fileType, dataOutputStream);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */     int written = writeImpl(audioInputStream, audioOutputStream, bNeedsConversion);
/*     */     
/*     */ 
/* 221 */     if (TDebug.TraceAudioFileWriter)
/*     */     {
/* 223 */       TDebug.out("< wrote " + written + " bytes.");
/*     */     }
/* 225 */     return written;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int write(AudioInputStream audioInputStream, AudioFileFormat.Type fileType, OutputStream outputStream)
/*     */     throws IOException
/*     */   {
/* 237 */     if (!isFileTypeSupported(fileType)) {
/* 238 */       throw new IllegalArgumentException("file type is not supported.");
/*     */     }
/* 240 */     if (TDebug.TraceAudioFileWriter)
/*     */     {
/* 242 */       TDebug.out(">TAudioFileWriter.write(.., OutputStream): called");
/* 243 */       TDebug.out("class: " + getClass().getName());
/*     */     }
/* 245 */     AudioFormat inputFormat = audioInputStream.getFormat();
/* 246 */     if (TDebug.TraceAudioFileWriter) TDebug.out("input format: " + inputFormat);
/* 247 */     AudioFormat outputFormat = null;
/* 248 */     boolean bNeedsConversion = false;
/* 249 */     if (isAudioFormatSupportedImpl(inputFormat, fileType))
/*     */     {
/* 251 */       if (TDebug.TraceAudioFileWriter) TDebug.out("input format is supported directely");
/* 252 */       outputFormat = inputFormat;
/* 253 */       bNeedsConversion = false;
/*     */     }
/*     */     else
/*     */     {
/* 257 */       if (TDebug.TraceAudioFileWriter) TDebug.out("input format is not supported directely; trying to find a convertable format");
/* 258 */       outputFormat = findConvertableFormat(inputFormat, fileType);
/* 259 */       if (outputFormat != null)
/*     */       {
/* 261 */         bNeedsConversion = true;
/*     */         
/*     */ 
/* 264 */         if ((outputFormat.getSampleSizeInBits() == 8) && (outputFormat.getEncoding().equals(inputFormat.getEncoding())))
/*     */         {
/* 266 */           bNeedsConversion = false;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 271 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< format is not supported");
/* 272 */         throw new IllegalArgumentException("format not supported and not convertable");
/*     */       }
/*     */     }
/* 275 */     long lLengthInBytes = AudioUtils.getLengthInBytes(audioInputStream);
/* 276 */     TDataOutputStream dataOutputStream = new TNonSeekableDataOutputStream(outputStream);
/* 277 */     AudioOutputStream audioOutputStream = getAudioOutputStream(outputFormat, lLengthInBytes, fileType, dataOutputStream);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */     int written = writeImpl(audioInputStream, audioOutputStream, bNeedsConversion);
/*     */     
/*     */ 
/* 286 */     if (TDebug.TraceAudioFileWriter) TDebug.out("< wrote " + written + " bytes.");
/* 287 */     return written;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int writeImpl(AudioInputStream audioInputStream, AudioOutputStream audioOutputStream, boolean bNeedsConversion)
/*     */     throws IOException
/*     */   {
/* 298 */     if (TDebug.TraceAudioFileWriter)
/*     */     {
/* 300 */       TDebug.out(">TAudioFileWriter.writeImpl(): called");
/* 301 */       TDebug.out("class: " + getClass().getName());
/*     */     }
/* 303 */     int nTotalWritten = 0;
/* 304 */     AudioFormat inputFormat = audioInputStream.getFormat();
/* 305 */     AudioFormat outputFormat = audioOutputStream.getFormat();
/*     */     
/*     */ 
/* 308 */     int nBytesPerSample = outputFormat.getFrameSize() / outputFormat.getChannels();
/*     */     
/*     */ 
/* 311 */     int nBufferSize = 16384 / outputFormat.getFrameSize() * outputFormat.getFrameSize();
/* 312 */     byte[] abBuffer = new byte[nBufferSize];
/*     */     for (;;)
/*     */     {
/* 315 */       if (TDebug.TraceAudioFileWriter) TDebug.out("trying to read (bytes): " + abBuffer.length);
/* 316 */       int nBytesRead = audioInputStream.read(abBuffer);
/* 317 */       if (TDebug.TraceAudioFileWriter) TDebug.out("read (bytes): " + nBytesRead);
/* 318 */       if (nBytesRead == -1) {
/*     */         break;
/*     */       }
/*     */       
/* 322 */       if (bNeedsConversion)
/*     */       {
/* 324 */         TConversionTool.changeOrderOrSign(abBuffer, 0, nBytesRead, nBytesPerSample);
/*     */       }
/*     */       
/* 327 */       int nWritten = audioOutputStream.write(abBuffer, 0, nBytesRead);
/* 328 */       nTotalWritten += nWritten;
/*     */     }
/* 330 */     if (TDebug.TraceAudioFileWriter) TDebug.out("<TAudioFileWriter.writeImpl(): after main loop. Wrote " + nTotalWritten + " bytes");
/* 331 */     audioOutputStream.close();
/*     */     
/* 333 */     return nTotalWritten;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Iterator<AudioFormat> getSupportedAudioFormats(AudioFileFormat.Type fileType)
/*     */   {
/* 345 */     return this.m_audioFormats.iterator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAudioFormatSupportedImpl(AudioFormat audioFormat, AudioFileFormat.Type fileType)
/*     */   {
/* 370 */     if (TDebug.TraceAudioFileWriter)
/*     */     {
/* 372 */       TDebug.out("> TAudioFileWriter.isAudioFormatSupportedImpl(): format to test: " + audioFormat);
/* 373 */       TDebug.out("class: " + getClass().getName());
/*     */     }
/* 375 */     Iterator audioFormats = getSupportedAudioFormats(fileType);
/* 376 */     while (audioFormats.hasNext())
/*     */     {
/* 378 */       AudioFormat handledFormat = (AudioFormat)audioFormats.next();
/* 379 */       if (TDebug.TraceAudioFileWriter) TDebug.out("matching against format : " + handledFormat);
/* 380 */       if (AudioFormats.matches(handledFormat, audioFormat))
/*     */       {
/* 382 */         if (TDebug.TraceAudioFileWriter) TDebug.out("<...succeeded.");
/* 383 */         return true;
/*     */       }
/*     */     }
/* 386 */     if (TDebug.TraceAudioFileWriter) TDebug.out("< ... failed");
/* 387 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract AudioOutputStream getAudioOutputStream(AudioFormat paramAudioFormat, long paramLong, AudioFileFormat.Type paramType, TDataOutputStream paramTDataOutputStream)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AudioFormat findConvertableFormat(AudioFormat inputFormat, AudioFileFormat.Type fileType)
/*     */   {
/* 403 */     if (TDebug.TraceAudioFileWriter) TDebug.out("TAudioFileWriter.findConvertableFormat(): input format: " + inputFormat);
/* 404 */     if (!isFileTypeSupported(fileType)) {
/* 405 */       if (TDebug.TraceAudioFileWriter) TDebug.out("< input file type is not supported.");
/* 406 */       return null;
/*     */     }
/* 408 */     AudioFormat.Encoding inputEncoding = inputFormat.getEncoding();
/* 409 */     if (((inputEncoding.equals(PCM_SIGNED)) || (inputEncoding.equals(PCM_UNSIGNED))) && (inputFormat.getSampleSizeInBits() == 8))
/*     */     {
/*     */ 
/* 412 */       AudioFormat outputFormat = convertFormat(inputFormat, true, false);
/* 413 */       if (TDebug.TraceAudioFileWriter) TDebug.out("trying output format: " + outputFormat);
/* 414 */       if (isAudioFormatSupportedImpl(outputFormat, fileType))
/*     */       {
/* 416 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< ... succeeded");
/* 417 */         return outputFormat;
/*     */       }
/*     */       
/* 420 */       outputFormat = convertFormat(inputFormat, false, true);
/* 421 */       if (TDebug.TraceAudioFileWriter) TDebug.out("trying output format: " + outputFormat);
/* 422 */       if (isAudioFormatSupportedImpl(outputFormat, fileType))
/*     */       {
/* 424 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< ... succeeded");
/* 425 */         return outputFormat;
/*     */       }
/* 427 */       outputFormat = convertFormat(inputFormat, true, true);
/* 428 */       if (TDebug.TraceAudioFileWriter) TDebug.out("trying output format: " + outputFormat);
/* 429 */       if (isAudioFormatSupportedImpl(outputFormat, fileType))
/*     */       {
/* 431 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< ... succeeded");
/* 432 */         return outputFormat;
/*     */       }
/* 434 */       if (TDebug.TraceAudioFileWriter) TDebug.out("< ... failed");
/* 435 */       return null;
/*     */     }
/* 437 */     if ((inputEncoding.equals(PCM_SIGNED)) && ((inputFormat.getSampleSizeInBits() == 16) || (inputFormat.getSampleSizeInBits() == 24) || (inputFormat.getSampleSizeInBits() == 32)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 444 */       AudioFormat outputFormat = convertFormat(inputFormat, false, true);
/* 445 */       if (TDebug.TraceAudioFileWriter) TDebug.out("trying output format: " + outputFormat);
/* 446 */       if (isAudioFormatSupportedImpl(outputFormat, fileType))
/*     */       {
/* 448 */         if (TDebug.TraceAudioFileWriter) TDebug.out("< ... succeeded");
/* 449 */         return outputFormat;
/*     */       }
/*     */       
/*     */ 
/* 453 */       if (TDebug.TraceAudioFileWriter) TDebug.out("< ... failed");
/* 454 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 459 */     if (TDebug.TraceAudioFileWriter) TDebug.out("< ... failed");
/* 460 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private AudioFormat convertFormat(AudioFormat format, boolean changeSign, boolean changeEndian)
/*     */   {
/* 466 */     AudioFormat.Encoding enc = PCM_SIGNED;
/* 467 */     if (format.getEncoding().equals(PCM_UNSIGNED) != changeSign) {
/* 468 */       enc = PCM_UNSIGNED;
/*     */     }
/* 470 */     return new AudioFormat(enc, format.getSampleRate(), format.getSampleSizeInBits(), format.getChannels(), format.getFrameSize(), format.getFrameRate(), format.isBigEndian() ^ changeEndian);
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TAudioFileWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */