/*    */ package org.tritonus.share.sampled.file;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeaderlessAudioOutputStream
/*    */   extends TAudioOutputStream
/*    */ {
/*    */   public HeaderlessAudioOutputStream(AudioFormat audioFormat, long lLength, TDataOutputStream dataOutputStream)
/*    */   {
/* 50 */     super(audioFormat, lLength, dataOutputStream, false);
/*    */   }
/*    */   
/*    */   protected void writeHeader()
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\HeaderlessAudioOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */