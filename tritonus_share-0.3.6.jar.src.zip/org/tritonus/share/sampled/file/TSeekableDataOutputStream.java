/*    */ package org.tritonus.share.sampled.file;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TSeekableDataOutputStream
/*    */   extends RandomAccessFile
/*    */   implements TDataOutputStream
/*    */ {
/*    */   public TSeekableDataOutputStream(File file)
/*    */     throws IOException
/*    */   {
/* 53 */     super(file, "rw");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean supportsSeek()
/*    */   {
/* 60 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void writeLittleEndian32(int value)
/*    */     throws IOException
/*    */   {
/* 68 */     writeByte(value & 0xFF);
/* 69 */     writeByte(value >> 8 & 0xFF);
/* 70 */     writeByte(value >> 16 & 0xFF);
/* 71 */     writeByte(value >> 24 & 0xFF);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void writeLittleEndian16(short value)
/*    */     throws IOException
/*    */   {
/* 79 */     writeByte(value & 0xFF);
/* 80 */     writeByte(value >> 8 & 0xFF);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\file\TSeekableDataOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */