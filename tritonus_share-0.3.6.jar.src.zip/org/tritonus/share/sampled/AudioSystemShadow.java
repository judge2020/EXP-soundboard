/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.tritonus.sampled.file.AiffAudioOutputStream;
/*     */ import org.tritonus.sampled.file.AuAudioOutputStream;
/*     */ import org.tritonus.sampled.file.WaveAudioOutputStream;
/*     */ import org.tritonus.share.sampled.file.AudioOutputStream;
/*     */ import org.tritonus.share.sampled.file.TDataOutputStream;
/*     */ import org.tritonus.share.sampled.file.TNonSeekableDataOutputStream;
/*     */ import org.tritonus.share.sampled.file.TSeekableDataOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioSystemShadow
/*     */ {
/*     */   public static TDataOutputStream getDataOutputStream(File file)
/*     */     throws IOException
/*     */   {
/*  59 */     return new TSeekableDataOutputStream(file);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static TDataOutputStream getDataOutputStream(OutputStream stream)
/*     */     throws IOException
/*     */   {
/*  67 */     return new TNonSeekableDataOutputStream(stream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AudioOutputStream getAudioOutputStream(AudioFileFormat.Type type, AudioFormat audioFormat, long lLengthInBytes, TDataOutputStream dataOutputStream)
/*     */   {
/*  75 */     AudioOutputStream audioOutputStream = null;
/*     */     
/*  77 */     if ((type.equals(AudioFileFormat.Type.AIFF)) || (type.equals(AudioFileFormat.Type.AIFF)))
/*     */     {
/*     */ 
/*  80 */       audioOutputStream = new AiffAudioOutputStream(audioFormat, type, lLengthInBytes, dataOutputStream);
/*     */     }
/*  82 */     else if (type.equals(AudioFileFormat.Type.AU))
/*     */     {
/*  84 */       audioOutputStream = new AuAudioOutputStream(audioFormat, lLengthInBytes, dataOutputStream);
/*     */     }
/*  86 */     else if (type.equals(AudioFileFormat.Type.WAVE))
/*     */     {
/*  88 */       audioOutputStream = new WaveAudioOutputStream(audioFormat, lLengthInBytes, dataOutputStream);
/*     */     }
/*  90 */     return audioOutputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AudioOutputStream getAudioOutputStream(AudioFileFormat.Type type, AudioFormat audioFormat, long lLengthInBytes, File file)
/*     */     throws IOException
/*     */   {
/*  98 */     TDataOutputStream dataOutputStream = getDataOutputStream(file);
/*  99 */     AudioOutputStream audioOutputStream = getAudioOutputStream(type, audioFormat, lLengthInBytes, dataOutputStream);
/* 100 */     return audioOutputStream;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static AudioOutputStream getAudioOutputStream(AudioFileFormat.Type type, AudioFormat audioFormat, long lLengthInBytes, OutputStream outputStream)
/*     */     throws IOException
/*     */   {
/* 108 */     TDataOutputStream dataOutputStream = getDataOutputStream(outputStream);
/* 109 */     AudioOutputStream audioOutputStream = getAudioOutputStream(type, audioFormat, lLengthInBytes, dataOutputStream);
/* 110 */     return audioOutputStream;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\AudioSystemShadow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */