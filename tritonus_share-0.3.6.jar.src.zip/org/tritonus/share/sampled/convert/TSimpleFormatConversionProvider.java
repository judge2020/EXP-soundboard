/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import org.tritonus.share.ArraySet;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.sampled.AudioFormats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TSimpleFormatConversionProvider
/*     */   extends TFormatConversionProvider
/*     */ {
/*     */   private Collection<AudioFormat.Encoding> m_sourceEncodings;
/*     */   private Collection<AudioFormat.Encoding> m_targetEncodings;
/*     */   private Collection<AudioFormat> m_sourceFormats;
/*     */   private Collection<AudioFormat> m_targetFormats;
/*     */   
/*     */   protected TSimpleFormatConversionProvider(Collection<AudioFormat> sourceFormats, Collection<AudioFormat> targetFormats)
/*     */   {
/*  75 */     this.m_sourceEncodings = new ArraySet();
/*  76 */     this.m_targetEncodings = new ArraySet();
/*  77 */     this.m_sourceFormats = sourceFormats;
/*  78 */     this.m_targetFormats = targetFormats;
/*  79 */     collectEncodings(this.m_sourceFormats, this.m_sourceEncodings);
/*  80 */     collectEncodings(this.m_targetFormats, this.m_targetEncodings);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void disable()
/*     */   {
/*  91 */     if (TDebug.TraceAudioConverter) TDebug.out("TSimpleFormatConversionProvider.disable(): disabling " + getClass().getName());
/*  92 */     this.m_sourceEncodings = new ArraySet();
/*  93 */     this.m_targetEncodings = new ArraySet();
/*  94 */     this.m_sourceFormats = new ArraySet();
/*  95 */     this.m_targetFormats = new ArraySet();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void collectEncodings(Collection<AudioFormat> formats, Collection<AudioFormat.Encoding> encodings)
/*     */   {
/* 103 */     Iterator<AudioFormat> iterator = formats.iterator();
/* 104 */     while (iterator.hasNext())
/*     */     {
/* 106 */       AudioFormat format = (AudioFormat)iterator.next();
/* 107 */       encodings.add(format.getEncoding());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AudioFormat.Encoding[] getSourceEncodings()
/*     */   {
/* 115 */     return (AudioFormat.Encoding[])this.m_sourceEncodings.toArray(EMPTY_ENCODING_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AudioFormat.Encoding[] getTargetEncodings()
/*     */   {
/* 122 */     return (AudioFormat.Encoding[])this.m_targetEncodings.toArray(EMPTY_ENCODING_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSourceEncodingSupported(AudioFormat.Encoding sourceEncoding)
/*     */   {
/* 130 */     return this.m_sourceEncodings.contains(sourceEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTargetEncodingSupported(AudioFormat.Encoding targetEncoding)
/*     */   {
/* 138 */     return this.m_targetEncodings.contains(targetEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat.Encoding[] getTargetEncodings(AudioFormat sourceFormat)
/*     */   {
/* 151 */     if (isAllowedSourceFormat(sourceFormat))
/*     */     {
/* 153 */       return getTargetEncodings();
/*     */     }
/*     */     
/*     */ 
/* 157 */     return EMPTY_ENCODING_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat[] getTargetFormats(AudioFormat.Encoding targetEncoding, AudioFormat sourceFormat)
/*     */   {
/* 171 */     if (isConversionSupported(targetEncoding, sourceFormat))
/*     */     {
/* 173 */       return (AudioFormat[])this.m_targetFormats.toArray(EMPTY_FORMAT_ARRAY);
/*     */     }
/*     */     
/*     */ 
/* 177 */     return EMPTY_FORMAT_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isAllowedSourceEncoding(AudioFormat.Encoding sourceEncoding)
/*     */   {
/* 185 */     return this.m_sourceEncodings.contains(sourceEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isAllowedTargetEncoding(AudioFormat.Encoding targetEncoding)
/*     */   {
/* 192 */     return this.m_targetEncodings.contains(targetEncoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isAllowedSourceFormat(AudioFormat sourceFormat)
/*     */   {
/* 199 */     Iterator<AudioFormat> iterator = this.m_sourceFormats.iterator();
/* 200 */     while (iterator.hasNext())
/*     */     {
/* 202 */       AudioFormat format = (AudioFormat)iterator.next();
/* 203 */       if (AudioFormats.matches(format, sourceFormat))
/*     */       {
/* 205 */         return true;
/*     */       }
/*     */     }
/* 208 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isAllowedTargetFormat(AudioFormat targetFormat)
/*     */   {
/* 215 */     Iterator<AudioFormat> iterator = this.m_targetFormats.iterator();
/* 216 */     while (iterator.hasNext())
/*     */     {
/* 218 */       AudioFormat format = (AudioFormat)iterator.next();
/* 219 */       if (AudioFormats.matches(format, targetFormat))
/*     */       {
/* 221 */         return true;
/*     */       }
/*     */     }
/* 224 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Collection<AudioFormat.Encoding> getCollectionSourceEncodings()
/*     */   {
/* 230 */     return this.m_sourceEncodings;
/*     */   }
/*     */   
/*     */   protected Collection<AudioFormat.Encoding> getCollectionTargetEncodings()
/*     */   {
/* 235 */     return this.m_targetEncodings;
/*     */   }
/*     */   
/*     */   protected Collection<AudioFormat> getCollectionSourceFormats() {
/* 239 */     return this.m_sourceFormats;
/*     */   }
/*     */   
/*     */   protected Collection<AudioFormat> getCollectionTargetFormats() {
/* 243 */     return this.m_targetFormats;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static boolean doMatch(int i1, int i2)
/*     */   {
/* 254 */     return (i1 == -1) || (i2 == -1) || (i1 == i2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static boolean doMatch(float f1, float f2)
/*     */   {
/* 264 */     return (f1 == -1.0F) || (f2 == -1.0F) || (Math.abs(f1 - f2) < 1.0E-9D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AudioFormat replaceNotSpecified(AudioFormat sourceFormat, AudioFormat targetFormat)
/*     */   {
/* 286 */     boolean bSetSampleSize = false;
/* 287 */     boolean bSetChannels = false;
/* 288 */     boolean bSetSampleRate = false;
/* 289 */     boolean bSetFrameRate = false;
/* 290 */     if ((targetFormat.getSampleSizeInBits() == -1) && (sourceFormat.getSampleSizeInBits() != -1))
/*     */     {
/* 292 */       bSetSampleSize = true;
/*     */     }
/* 294 */     if ((targetFormat.getChannels() == -1) && (sourceFormat.getChannels() != -1))
/*     */     {
/* 296 */       bSetChannels = true;
/*     */     }
/* 298 */     if ((targetFormat.getSampleRate() == -1.0F) && (sourceFormat.getSampleRate() != -1.0F))
/*     */     {
/* 300 */       bSetSampleRate = true;
/*     */     }
/* 302 */     if ((targetFormat.getFrameRate() == -1.0F) && (sourceFormat.getFrameRate() != -1.0F))
/*     */     {
/* 304 */       bSetFrameRate = true;
/*     */     }
/* 306 */     if ((bSetSampleSize) || (bSetChannels) || (bSetSampleRate) || (bSetFrameRate) || ((targetFormat.getFrameSize() == -1) && (sourceFormat.getFrameSize() != -1)))
/*     */     {
/*     */ 
/*     */ 
/* 310 */       float sampleRate = bSetSampleRate ? sourceFormat.getSampleRate() : targetFormat.getSampleRate();
/*     */       
/* 312 */       float frameRate = bSetFrameRate ? sourceFormat.getFrameRate() : targetFormat.getFrameRate();
/*     */       
/* 314 */       int sampleSize = bSetSampleSize ? sourceFormat.getSampleSizeInBits() : targetFormat.getSampleSizeInBits();
/*     */       
/* 316 */       int channels = bSetChannels ? sourceFormat.getChannels() : targetFormat.getChannels();
/*     */       
/* 318 */       int frameSize = getFrameSize(targetFormat.getEncoding(), sampleRate, sampleSize, channels, frameRate, targetFormat.isBigEndian(), targetFormat.getFrameSize());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 326 */       targetFormat = new AudioFormat(targetFormat.getEncoding(), sampleRate, sampleSize, channels, frameSize, frameRate, targetFormat.isBigEndian());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */     return targetFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getFrameSize(AudioFormat.Encoding encoding, float sampleRate, int sampleSize, int channels, float frameRate, boolean bigEndian, int oldFrameSize)
/*     */   {
/* 357 */     if ((sampleSize == -1) || (channels == -1)) {
/* 358 */       return -1;
/*     */     }
/* 360 */     return sampleSize * channels / 8;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TSimpleFormatConversionProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */