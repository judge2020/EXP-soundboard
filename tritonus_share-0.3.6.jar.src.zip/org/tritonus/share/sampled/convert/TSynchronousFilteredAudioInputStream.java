/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.sampled.AudioUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TSynchronousFilteredAudioInputStream
/*     */   extends TAudioInputStream
/*     */ {
/*     */   private AudioInputStream originalStream;
/*     */   private AudioFormat originalFormat;
/*     */   private int originalFrameSize;
/*     */   private int newFrameSize;
/*  69 */   protected byte[] buffer = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private boolean m_bConvertInPlace = false;
/*     */   
/*     */   public TSynchronousFilteredAudioInputStream(AudioInputStream audioInputStream, AudioFormat newFormat)
/*     */   {
/*  79 */     super(audioInputStream, newFormat, audioInputStream.getFrameLength());
/*  80 */     this.originalStream = audioInputStream;
/*  81 */     this.originalFormat = audioInputStream.getFormat();
/*  82 */     this.originalFrameSize = (this.originalFormat.getFrameSize() <= 0 ? 1 : this.originalFormat.getFrameSize());
/*     */     
/*  84 */     this.newFrameSize = (getFormat().getFrameSize() <= 0 ? 1 : getFormat().getFrameSize());
/*     */     
/*  86 */     if (TDebug.TraceAudioConverter) {
/*  87 */       TDebug.out("TSynchronousFilteredAudioInputStream: original format =" + AudioUtils.format2ShortStr(this.originalFormat));
/*     */       
/*  89 */       TDebug.out("TSynchronousFilteredAudioInputStream: converted format=" + AudioUtils.format2ShortStr(getFormat()));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     this.m_bConvertInPlace = false;
/*     */   }
/*     */   
/*     */   protected boolean enableConvertInPlace() {
/* 100 */     if (this.newFrameSize >= this.originalFrameSize) {
/* 101 */       this.m_bConvertInPlace = true;
/*     */     }
/* 103 */     return this.m_bConvertInPlace;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract int convert(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void convertInPlace(byte[] buffer, int byteOffset, int frameCount)
/*     */   {
/* 127 */     throw new RuntimeException("Illegal call to convertInPlace");
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 132 */     if (this.newFrameSize != 1) {
/* 133 */       throw new IOException("frame size must be 1 to read a single byte");
/*     */     }
/*     */     
/*     */ 
/* 137 */     byte[] temp = new byte[1];
/* 138 */     int result = read(temp);
/* 139 */     if (result == -1) {
/* 140 */       return -1;
/*     */     }
/* 142 */     if (result == 0)
/*     */     {
/* 144 */       return -1;
/*     */     }
/* 146 */     return temp[0] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */   private void clearBuffer()
/*     */   {
/* 152 */     this.buffer = null;
/*     */   }
/*     */   
/*     */   public AudioInputStream getOriginalStream() {
/* 156 */     return this.originalStream;
/*     */   }
/*     */   
/*     */   public AudioFormat getOriginalFormat() {
/* 160 */     return this.originalFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] abData, int nOffset, int nLength)
/*     */     throws IOException
/*     */   {
/* 172 */     int nFrameLength = nLength / this.newFrameSize;
/*     */     
/*     */ 
/* 175 */     int originalBytes = nFrameLength * this.originalFrameSize;
/*     */     
/* 177 */     if (TDebug.TraceAudioConverter) {
/* 178 */       TDebug.out("> TSynchronousFilteredAIS.read(buffer[" + abData.length + "], " + nOffset + " ," + nLength + " bytes ^=" + nFrameLength + " frames)");
/*     */     }
/*     */     
/* 181 */     int nFramesConverted = 0;
/*     */     
/*     */     int readOffset;
/*     */     byte[] readBuffer;
/*     */     int readOffset;
/* 186 */     if (this.m_bConvertInPlace) {
/* 187 */       byte[] readBuffer = abData;
/* 188 */       readOffset = nOffset;
/*     */     }
/*     */     else {
/* 191 */       if ((this.buffer == null) || (this.buffer.length < originalBytes)) {
/* 192 */         this.buffer = new byte[originalBytes];
/*     */       }
/* 194 */       readBuffer = this.buffer;
/* 195 */       readOffset = 0;
/*     */     }
/* 197 */     int nBytesRead = this.originalStream.read(readBuffer, readOffset, originalBytes);
/* 198 */     if (nBytesRead == -1)
/*     */     {
/* 200 */       clearBuffer();
/* 201 */       return -1;
/*     */     }
/* 203 */     int nFramesRead = nBytesRead / this.originalFrameSize;
/* 204 */     if (TDebug.TraceAudioConverter) {
/* 205 */       TDebug.out("original.read returned " + nBytesRead + " bytes ^=" + nFramesRead + " frames");
/*     */     }
/*     */     
/* 208 */     if (this.m_bConvertInPlace) {
/* 209 */       convertInPlace(abData, nOffset, nFramesRead);
/* 210 */       nFramesConverted = nFramesRead;
/*     */     } else {
/* 212 */       nFramesConverted = convert(this.buffer, abData, nOffset, nFramesRead);
/*     */     }
/* 214 */     if (TDebug.TraceAudioConverter) {
/* 215 */       TDebug.out("< converted " + nFramesConverted + " frames");
/*     */     }
/* 217 */     return nFramesConverted * this.newFrameSize;
/*     */   }
/*     */   
/*     */ 
/*     */   public long skip(long nSkip)
/*     */     throws IOException
/*     */   {
/* 224 */     long skipFrames = nSkip / this.newFrameSize;
/* 225 */     long originalSkippedBytes = this.originalStream.skip(skipFrames * this.originalFrameSize);
/* 226 */     long skippedFrames = originalSkippedBytes / this.originalFrameSize;
/* 227 */     return skippedFrames * this.newFrameSize;
/*     */   }
/*     */   
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 233 */     int origAvailFrames = this.originalStream.available() / this.originalFrameSize;
/* 234 */     return origAvailFrames * this.newFrameSize;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 240 */     this.originalStream.close();
/* 241 */     clearBuffer();
/*     */   }
/*     */   
/*     */ 
/*     */   public void mark(int readlimit)
/*     */   {
/* 247 */     int readLimitFrames = readlimit / this.newFrameSize;
/* 248 */     this.originalStream.mark(readLimitFrames * this.originalFrameSize);
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 255 */     this.originalStream.reset();
/*     */   }
/*     */   
/*     */   public boolean markSupported()
/*     */   {
/* 260 */     return this.originalStream.markSupported();
/*     */   }
/*     */   
/*     */   private int getFrameSize()
/*     */   {
/* 265 */     return getFormat().getFrameSize();
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TSynchronousFilteredAudioInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */