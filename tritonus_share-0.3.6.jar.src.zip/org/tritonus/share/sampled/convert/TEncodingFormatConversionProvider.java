/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import org.tritonus.share.ArraySet;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TEncodingFormatConversionProvider
/*     */   extends TSimpleFormatConversionProvider
/*     */ {
/*     */   protected TEncodingFormatConversionProvider(Collection<AudioFormat> sourceFormats, Collection<AudioFormat> targetFormats)
/*     */   {
/*  74 */     super(sourceFormats, targetFormats);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat[] getTargetFormats(AudioFormat.Encoding targetEncoding, AudioFormat sourceFormat)
/*     */   {
/* 100 */     if (TDebug.TraceAudioConverter) {
/* 101 */       TDebug.out(">TEncodingFormatConversionProvider.getTargetFormats(AudioFormat.Encoding, AudioFormat):");
/* 102 */       TDebug.out("checking if conversion possible");
/* 103 */       TDebug.out("from: " + sourceFormat);
/* 104 */       TDebug.out("to: " + targetEncoding);
/*     */     }
/* 106 */     if (isConversionSupported(targetEncoding, sourceFormat))
/*     */     {
/* 108 */       ArraySet<AudioFormat> result = new ArraySet();
/* 109 */       Iterator<AudioFormat> iterator = getCollectionTargetFormats().iterator();
/* 110 */       while (iterator.hasNext()) {
/* 111 */         AudioFormat targetFormat = (AudioFormat)iterator.next();
/* 112 */         targetFormat = replaceNotSpecified(sourceFormat, targetFormat);
/* 113 */         result.add(targetFormat);
/*     */       }
/* 115 */       if (TDebug.TraceAudioConverter) {
/* 116 */         TDebug.out("< returning " + result.size() + " elements.");
/*     */       }
/* 118 */       return (AudioFormat[])result.toArray(EMPTY_FORMAT_ARRAY);
/*     */     }
/* 120 */     if (TDebug.TraceAudioConverter) {
/* 121 */       TDebug.out("< returning empty array.");
/*     */     }
/* 123 */     return EMPTY_FORMAT_ARRAY;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TEncodingFormatConversionProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */