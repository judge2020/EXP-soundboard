/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TAudioInputStream
/*     */   extends AudioInputStream
/*     */ {
/*     */   private Map<String, Object> m_properties;
/*     */   private Map<String, Object> m_unmodifiableProperties;
/*     */   
/*     */   public TAudioInputStream(InputStream inputStream, AudioFormat audioFormat, long lLengthInFrames)
/*     */   {
/*  66 */     super(inputStream, audioFormat, lLengthInFrames);
/*  67 */     initMaps(new HashMap());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TAudioInputStream(InputStream inputStream, AudioFormat audioFormat, long lLengthInFrames, Map<String, Object> properties)
/*     */   {
/*  81 */     super(inputStream, audioFormat, lLengthInFrames);
/*  82 */     initMaps(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initMaps(Map<String, Object> properties)
/*     */   {
/*  91 */     this.m_properties = properties;
/*  92 */     this.m_unmodifiableProperties = Collections.unmodifiableMap(this.m_properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<String, Object> properties()
/*     */   {
/* 104 */     return this.m_unmodifiableProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setProperty(String key, Object value)
/*     */   {
/* 114 */     this.m_properties.put(key, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TAudioInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */