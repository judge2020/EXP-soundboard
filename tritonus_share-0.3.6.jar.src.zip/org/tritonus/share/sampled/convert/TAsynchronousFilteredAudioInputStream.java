/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.tritonus.share.TCircularBuffer;
/*     */ import org.tritonus.share.TCircularBuffer.Trigger;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TAsynchronousFilteredAudioInputStream
/*     */   extends TAudioInputStream
/*     */   implements TCircularBuffer.Trigger
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 327670;
/*     */   private static final int DEFAULT_MIN_AVAILABLE = 4096;
/*  61 */   private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */   private TCircularBuffer m_circularBuffer;
/*     */   
/*     */ 
/*     */ 
/*     */   private int m_nMinAvailable;
/*     */   
/*     */ 
/*     */ 
/*     */   private byte[] m_abSingleByte;
/*     */   
/*     */ 
/*     */ 
/*     */   public TAsynchronousFilteredAudioInputStream(AudioFormat outputFormat, long lLength)
/*     */   {
/*  79 */     this(outputFormat, lLength, 327670, 4096);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TAsynchronousFilteredAudioInputStream(AudioFormat outputFormat, long lLength, int nBufferSize, int nMinAvailable)
/*     */   {
/* 110 */     super(new ByteArrayInputStream(EMPTY_BYTE_ARRAY), outputFormat, lLength);
/*     */     
/*     */ 
/* 113 */     if (TDebug.TraceAudioConverter) TDebug.out("TAsynchronousFilteredAudioInputStream.<init>(): begin");
/* 114 */     this.m_circularBuffer = new TCircularBuffer(nBufferSize, false, true, this);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 119 */     this.m_nMinAvailable = nMinAvailable;
/* 120 */     if (TDebug.TraceAudioConverter) { TDebug.out("TAsynchronousFilteredAudioInputStream.<init>(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected TCircularBuffer getCircularBuffer()
/*     */   {
/* 128 */     return this.m_circularBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean writeMore()
/*     */   {
/* 146 */     return getCircularBuffer().availableWrite() > this.m_nMinAvailable;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 155 */     int nByte = -1;
/* 156 */     if (this.m_abSingleByte == null)
/*     */     {
/* 158 */       this.m_abSingleByte = new byte[1];
/*     */     }
/* 160 */     int nReturn = read(this.m_abSingleByte);
/* 161 */     if (nReturn == -1)
/*     */     {
/* 163 */       nByte = -1;
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 168 */       nByte = this.m_abSingleByte[0] & 0xFF;
/*     */     }
/*     */     
/* 171 */     return nByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(byte[] abData)
/*     */     throws IOException
/*     */   {
/* 179 */     if (TDebug.TraceAudioConverter) TDebug.out("TAsynchronousFilteredAudioInputStream.read(byte[]): begin");
/* 180 */     int nRead = read(abData, 0, abData.length);
/* 181 */     if (TDebug.TraceAudioConverter) TDebug.out("TAsynchronousFilteredAudioInputStream.read(byte[]): end");
/* 182 */     return nRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read(byte[] abData, int nOffset, int nLength)
/*     */     throws IOException
/*     */   {
/* 190 */     if (TDebug.TraceAudioConverter) { TDebug.out("TAsynchronousFilteredAudioInputStream.read(byte[], int, int): begin");
/*     */     }
/*     */     
/*     */ 
/* 194 */     int nRead = this.m_circularBuffer.read(abData, nOffset, nLength);
/* 195 */     if (TDebug.TraceAudioConverter) TDebug.out("TAsynchronousFilteredAudioInputStream.read(byte[], int, int): end");
/* 196 */     return nRead;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long skip(long lSkip)
/*     */     throws IOException
/*     */   {
/* 205 */     for (long lSkipped = 0L; lSkipped < lSkip; lSkipped += 1L)
/*     */     {
/* 207 */       int nReturn = read();
/* 208 */       if (nReturn == -1)
/*     */       {
/* 210 */         return lSkipped;
/*     */       }
/*     */     }
/* 213 */     return lSkip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 221 */     return this.m_circularBuffer.availableRead();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 229 */     this.m_circularBuffer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 236 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mark(int nReadLimit) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 250 */     throw new IOException("mark not supported");
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TAsynchronousFilteredAudioInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */