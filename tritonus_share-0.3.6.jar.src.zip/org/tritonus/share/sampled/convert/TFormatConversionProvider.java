/*     */ package org.tritonus.share.sampled.convert;
/*     */ 
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.spi.FormatConversionProvider;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.sampled.AudioFormats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TFormatConversionProvider
/*     */   extends FormatConversionProvider
/*     */ {
/*  50 */   protected static final AudioFormat.Encoding[] EMPTY_ENCODING_ARRAY = new AudioFormat.Encoding[0];
/*  51 */   protected static final AudioFormat[] EMPTY_FORMAT_ARRAY = new AudioFormat[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioInputStream getAudioInputStream(AudioFormat.Encoding targetEncoding, AudioInputStream audioInputStream)
/*     */   {
/*  58 */     AudioFormat sourceFormat = audioInputStream.getFormat();
/*  59 */     AudioFormat targetFormat = new AudioFormat(targetEncoding, -1.0F, -1, -1, -1, -1.0F, sourceFormat.isBigEndian());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     if (TDebug.TraceAudioConverter)
/*     */     {
/*  69 */       TDebug.out("TFormatConversionProvider.getAudioInputStream(AudioFormat.Encoding, AudioInputStream):");
/*  70 */       TDebug.out("trying to convert to " + targetFormat);
/*     */     }
/*  72 */     return getAudioInputStream(targetFormat, audioInputStream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConversionSupported(AudioFormat targetFormat, AudioFormat sourceFormat)
/*     */   {
/*  92 */     if (TDebug.TraceAudioConverter)
/*     */     {
/*  94 */       TDebug.out(">TFormatConversionProvider.isConversionSupported(AudioFormat, AudioFormat):");
/*  95 */       TDebug.out("class: " + getClass().getName());
/*  96 */       TDebug.out("checking if conversion possible");
/*  97 */       TDebug.out("from: " + sourceFormat);
/*  98 */       TDebug.out("to: " + targetFormat);
/*     */     }
/* 100 */     AudioFormat[] aTargetFormats = getTargetFormats(targetFormat.getEncoding(), sourceFormat);
/* 101 */     for (int i = 0; i < aTargetFormats.length; i++)
/*     */     {
/* 103 */       if (TDebug.TraceAudioConverter)
/*     */       {
/* 105 */         TDebug.out("checking against possible target format: " + aTargetFormats[i]);
/*     */       }
/* 107 */       if ((aTargetFormats[i] != null) && (AudioFormats.matches(aTargetFormats[i], targetFormat)))
/*     */       {
/*     */ 
/* 110 */         if (TDebug.TraceAudioConverter)
/*     */         {
/* 112 */           TDebug.out("<result=true");
/*     */         }
/* 114 */         return true;
/*     */       }
/*     */     }
/* 117 */     if (TDebug.TraceAudioConverter) {
/* 118 */       TDebug.out("<result=false");
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat getMatchingFormat(AudioFormat targetFormat, AudioFormat sourceFormat)
/*     */   {
/* 135 */     if (TDebug.TraceAudioConverter)
/*     */     {
/* 137 */       TDebug.out(">TFormatConversionProvider.isConversionSupported(AudioFormat, AudioFormat):");
/* 138 */       TDebug.out("class: " + getClass().getName());
/* 139 */       TDebug.out("checking if conversion possible");
/* 140 */       TDebug.out("from: " + sourceFormat);
/* 141 */       TDebug.out("to: " + targetFormat);
/*     */     }
/* 143 */     AudioFormat[] aTargetFormats = getTargetFormats(targetFormat.getEncoding(), sourceFormat);
/* 144 */     for (int i = 0; i < aTargetFormats.length; i++)
/*     */     {
/* 146 */       if (TDebug.TraceAudioConverter)
/*     */       {
/* 148 */         TDebug.out("checking against possible target format: " + aTargetFormats[i]);
/*     */       }
/* 150 */       if ((aTargetFormats[i] != null) && (AudioFormats.matches(aTargetFormats[i], targetFormat)))
/*     */       {
/*     */ 
/* 153 */         if (TDebug.TraceAudioConverter)
/*     */         {
/* 155 */           TDebug.out("<result=true");
/*     */         }
/* 157 */         return aTargetFormats[i];
/*     */       }
/*     */     }
/* 160 */     if (TDebug.TraceAudioConverter) {
/* 161 */       TDebug.out("<result=false");
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\convert\TFormatConversionProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */