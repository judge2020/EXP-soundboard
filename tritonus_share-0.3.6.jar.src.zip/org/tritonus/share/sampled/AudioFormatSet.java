/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.tritonus.share.ArraySet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioFormatSet
/*     */   extends ArraySet<AudioFormat>
/*     */ {
/*  67 */   protected static final AudioFormat[] EMPTY_FORMAT_ARRAY = new AudioFormat[0];
/*     */   
/*     */ 
/*     */   public AudioFormatSet() {}
/*     */   
/*     */   public AudioFormatSet(Collection<AudioFormat> c)
/*     */   {
/*  74 */     super(c);
/*     */   }
/*     */   
/*     */   public boolean add(AudioFormat elem) {
/*  78 */     if ((elem == null) || (!(elem instanceof AudioFormat))) {
/*  79 */       return false;
/*     */     }
/*  81 */     return super.add(elem);
/*     */   }
/*     */   
/*     */   public boolean contains(AudioFormat elem) {
/*  85 */     if ((elem == null) || (!(elem instanceof AudioFormat))) {
/*  86 */       return false;
/*     */     }
/*  88 */     AudioFormat comp = elem;
/*  89 */     Iterator it = iterator();
/*  90 */     while (it.hasNext()) {
/*  91 */       if (AudioFormats.equals(comp, (AudioFormat)it.next())) {
/*  92 */         return true;
/*     */       }
/*     */     }
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   public AudioFormat get(AudioFormat elem) {
/*  99 */     if ((elem == null) || (!(elem instanceof AudioFormat))) {
/* 100 */       return null;
/*     */     }
/* 102 */     AudioFormat comp = elem;
/* 103 */     Iterator it = iterator();
/* 104 */     while (it.hasNext()) {
/* 105 */       AudioFormat thisElem = (AudioFormat)it.next();
/* 106 */       if (AudioFormats.equals(comp, thisElem)) {
/* 107 */         return thisElem;
/*     */       }
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */   
/*     */   public AudioFormat getAudioFormat(AudioFormat elem) {
/* 114 */     return get(elem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat matches(AudioFormat elem)
/*     */   {
/* 126 */     if (elem == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     Iterator it = iterator();
/* 130 */     while (it.hasNext()) {
/* 131 */       AudioFormat thisElem = (AudioFormat)it.next();
/* 132 */       if (AudioFormats.matches(elem, thisElem)) {
/* 133 */         return thisElem;
/*     */       }
/*     */     }
/* 136 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public AudioFormat[] toAudioFormatArray()
/*     */   {
/* 142 */     return (AudioFormat[])toArray(EMPTY_FORMAT_ARRAY);
/*     */   }
/*     */   
/*     */   public void add(int index, AudioFormat element)
/*     */   {
/* 147 */     throw new UnsupportedOperationException("unsupported");
/*     */   }
/*     */   
/*     */   public AudioFormat set(int index, AudioFormat element) {
/* 151 */     throw new UnsupportedOperationException("unsupported");
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\AudioFormatSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */