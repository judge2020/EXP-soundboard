/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TAudioFormat
/*     */   extends AudioFormat
/*     */ {
/*     */   private Map<String, Object> m_properties;
/*     */   private Map<String, Object> m_unmodifiableProperties;
/*     */   
/*     */   public TAudioFormat(AudioFormat.Encoding encoding, float sampleRate, int sampleSizeInBits, int channels, int frameSize, float frameRate, boolean bigEndian, Map<String, Object> properties)
/*     */   {
/*  55 */     super(encoding, sampleRate, sampleSizeInBits, channels, frameSize, frameRate, bigEndian);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     initMaps(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TAudioFormat(float sampleRate, int sampleSizeInBits, int channels, boolean signed, boolean bigEndian, Map<String, Object> properties)
/*     */   {
/*  73 */     super(sampleRate, sampleSizeInBits, channels, signed, bigEndian);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  78 */     initMaps(properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void initMaps(Map<String, Object> properties)
/*     */   {
/*  88 */     this.m_properties = new HashMap();
/*  89 */     this.m_properties.putAll(properties);
/*  90 */     this.m_unmodifiableProperties = Collections.unmodifiableMap(this.m_properties);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Map<String, Object> properties()
/*     */   {
/*  97 */     return this.m_unmodifiableProperties;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setProperty(String key, Object value)
/*     */   {
/* 104 */     this.m_properties.put(key, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\TAudioFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */