/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import javax.sound.sampled.AudioFileFormat.Type;
/*     */ import org.tritonus.share.StringHashedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioFileTypes
/*     */   extends AudioFileFormat.Type
/*     */ {
/*  72 */   private static StringHashedSet types = new StringHashedSet();
/*     */   
/*     */   static
/*     */   {
/*  76 */     types.add(AudioFileFormat.Type.AIFF);
/*  77 */     types.add(AudioFileFormat.Type.AIFC);
/*  78 */     types.add(AudioFileFormat.Type.AU);
/*  79 */     types.add(AudioFileFormat.Type.SND);
/*  80 */     types.add(AudioFileFormat.Type.WAVE);
/*     */   }
/*     */   
/*     */   AudioFileTypes(String name, String ext) {
/*  84 */     super(name, ext);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AudioFileFormat.Type getType(String name)
/*     */   {
/* 102 */     return getType(name, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AudioFileFormat.Type getType(String name, String extension)
/*     */   {
/* 125 */     AudioFileFormat.Type res = (AudioFileFormat.Type)types.get(name);
/* 126 */     if (res == null)
/*     */     {
/* 128 */       if (extension == null) {
/* 129 */         return null;
/*     */       }
/*     */       
/* 132 */       res = new AudioFileTypes(name, extension);
/*     */       
/* 134 */       types.add(res);
/*     */     }
/* 136 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equals(AudioFileFormat.Type t1, AudioFileFormat.Type t2)
/*     */   {
/* 149 */     return t2.toString().equals(t1.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\AudioFileTypes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */