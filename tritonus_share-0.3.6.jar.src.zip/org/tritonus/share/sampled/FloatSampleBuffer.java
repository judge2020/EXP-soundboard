/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatSampleBuffer
/*     */ {
/*     */   private static final boolean LAZY_DEFAULT = true;
/* 194 */   private ArrayList<float[]> channels = new ArrayList();
/* 195 */   private int sampleCount = 0;
/* 196 */   private int channelCount = 0;
/* 197 */   private float sampleRate = 0.0F;
/* 198 */   private int originalFormatType = 0;
/*     */   
/*     */ 
/*     */   public static final int DITHER_MODE_AUTOMATIC = 0;
/*     */   
/*     */   public static final int DITHER_MODE_ON = 1;
/*     */   
/*     */   public static final int DITHER_MODE_OFF = 2;
/*     */   
/* 207 */   private float ditherBits = 0.7F;
/*     */   
/*     */ 
/* 210 */   private int ditherMode = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FloatSampleBuffer()
/*     */   {
/* 218 */     this(0, 0, 1.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FloatSampleBuffer(int channelCount, int sampleCount, float sampleRate)
/*     */   {
/* 226 */     init(channelCount, sampleCount, sampleRate, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FloatSampleBuffer(byte[] buffer, int offset, int byteCount, AudioFormat format)
/*     */   {
/* 235 */     this(format.getChannels(), byteCount / (format.getSampleSizeInBits() / 8 * format.getChannels()), format.getSampleRate());
/*     */     
/*     */ 
/* 238 */     initFromByteArray(buffer, offset, byteCount, format);
/*     */   }
/*     */   
/*     */   protected void init(int channelCount, int sampleCount, float sampleRate) {
/* 242 */     init(channelCount, sampleCount, sampleRate, true);
/*     */   }
/*     */   
/*     */   protected void init(int channelCount, int sampleCount, float sampleRate, boolean lazy) {
/* 246 */     if ((channelCount < 0) || (sampleCount < 0)) {
/* 247 */       throw new IllegalArgumentException("invalid parameters in initialization of FloatSampleBuffer.");
/*     */     }
/*     */     
/* 250 */     setSampleRate(sampleRate);
/* 251 */     if ((getSampleCount() != sampleCount) || (getChannelCount() != channelCount)) {
/* 252 */       createChannels(channelCount, sampleCount, lazy);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createChannels(int channelCount, int sampleCount, boolean lazy) {
/* 257 */     this.sampleCount = sampleCount;
/*     */     
/* 259 */     this.channelCount = 0;
/* 260 */     for (int ch = 0; ch < channelCount; ch++) {
/* 261 */       insertChannel(ch, false, lazy);
/*     */     }
/* 263 */     if (!lazy)
/*     */     {
/* 265 */       while (this.channels.size() > channelCount) {
/* 266 */         this.channels.remove(this.channels.size() - 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initFromByteArray(byte[] buffer, int offset, int byteCount, AudioFormat format)
/*     */   {
/* 282 */     initFromByteArray(buffer, offset, byteCount, format, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initFromByteArray(byte[] buffer, int offset, int byteCount, AudioFormat format, boolean lazy)
/*     */   {
/* 297 */     if (offset + byteCount > buffer.length) {
/* 298 */       throw new IllegalArgumentException("FloatSampleBuffer.initFromByteArray: buffer too small.");
/*     */     }
/*     */     
/*     */ 
/* 302 */     int thisSampleCount = byteCount / format.getFrameSize();
/* 303 */     init(format.getChannels(), thisSampleCount, format.getSampleRate(), lazy);
/*     */     
/*     */ 
/* 306 */     this.originalFormatType = FloatSampleTools.getFormatType(format);
/*     */     
/* 308 */     FloatSampleTools.byte2float(buffer, offset, this.channels, 0, this.sampleCount, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initFromFloatSampleBuffer(FloatSampleBuffer source)
/*     */   {
/* 316 */     init(source.getChannelCount(), source.getSampleCount(), source.getSampleRate());
/* 317 */     for (int ch = 0; ch < getChannelCount(); ch++) {
/* 318 */       System.arraycopy(source.getChannel(ch), 0, getChannel(ch), 0, this.sampleCount);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 327 */     init(0, 0, 1.0F, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset(int channels, int sampleCount, float sampleRate)
/*     */   {
/* 335 */     init(channels, sampleCount, sampleRate, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteArrayBufferSize(AudioFormat format)
/*     */   {
/* 345 */     return getByteArrayBufferSize(format, getSampleCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteArrayBufferSize(AudioFormat format, int lenInSamples)
/*     */   {
/* 355 */     FloatSampleTools.getFormatType(format);
/* 356 */     return format.getFrameSize() * lenInSamples;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int convertToByteArray(byte[] buffer, int offset, AudioFormat format)
/*     */   {
/* 368 */     return convertToByteArray(0, getSampleCount(), buffer, offset, format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int convertToByteArray(int readOffset, int lenInSamples, byte[] buffer, int writeOffset, AudioFormat format)
/*     */   {
/* 384 */     int byteCount = getByteArrayBufferSize(format, lenInSamples);
/* 385 */     if (writeOffset + byteCount > buffer.length) {
/* 386 */       throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: buffer too small.");
/*     */     }
/*     */     
/* 389 */     if (format.getSampleRate() != getSampleRate()) {
/* 390 */       throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: different samplerates.");
/*     */     }
/*     */     
/* 393 */     if (format.getChannels() != getChannelCount()) {
/* 394 */       throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: different channel count.");
/*     */     }
/*     */     
/* 397 */     FloatSampleTools.float2byte(this.channels, readOffset, buffer, writeOffset, lenInSamples, format, getConvertDitherBits(FloatSampleTools.getFormatType(format)));
/*     */     
/*     */ 
/* 400 */     return byteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] convertToByteArray(AudioFormat format)
/*     */   {
/* 412 */     byte[] res = new byte[getByteArrayBufferSize(format)];
/* 413 */     convertToByteArray(res, 0, format);
/* 414 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeSampleCount(int newSampleCount, boolean keepOldSamples)
/*     */   {
/* 427 */     int oldSampleCount = getSampleCount();
/* 428 */     if (oldSampleCount == newSampleCount) {
/* 429 */       return;
/*     */     }
/* 431 */     Object[] oldChannels = null;
/* 432 */     if (keepOldSamples) {
/* 433 */       oldChannels = getAllChannels();
/*     */     }
/* 435 */     init(getChannelCount(), newSampleCount, getSampleRate());
/* 436 */     if (keepOldSamples)
/*     */     {
/* 438 */       int copyCount = newSampleCount < oldSampleCount ? newSampleCount : oldSampleCount;
/*     */       
/* 440 */       for (int ch = 0; ch < getChannelCount(); ch++) {
/* 441 */         float[] oldSamples = (float[])oldChannels[ch];
/* 442 */         float[] newSamples = (float[])getChannel(ch);
/* 443 */         if (oldSamples != newSamples)
/*     */         {
/* 445 */           System.arraycopy(oldSamples, 0, newSamples, 0, copyCount);
/*     */         }
/* 447 */         if (oldSampleCount < newSampleCount)
/*     */         {
/* 449 */           for (int i = oldSampleCount; i < newSampleCount; i++) {
/* 450 */             newSamples[i] = 0.0F;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void makeSilence()
/*     */   {
/* 459 */     if (getChannelCount() > 0) {
/* 460 */       makeSilence(0);
/* 461 */       for (int ch = 1; ch < getChannelCount(); ch++) {
/* 462 */         copyChannel(0, ch);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void makeSilence(int channel) {
/* 468 */     float[] samples = getChannel(channel);
/* 469 */     for (int i = 0; i < getSampleCount(); i++) {
/* 470 */       samples[i] = 0.0F;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addChannel(boolean silent)
/*     */   {
/* 476 */     insertChannel(getChannelCount(), silent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertChannel(int index, boolean silent)
/*     */   {
/* 484 */     insertChannel(index, silent, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertChannel(int index, boolean silent, boolean lazy)
/*     */   {
/* 498 */     int physSize = this.channels.size();
/* 499 */     int virtSize = getChannelCount();
/* 500 */     float[] newChannel = null;
/* 501 */     if (physSize > virtSize)
/*     */     {
/* 503 */       for (int ch = virtSize; ch < physSize; ch++) {
/* 504 */         float[] thisChannel = (float[])this.channels.get(ch);
/* 505 */         if (((lazy) && (thisChannel.length >= getSampleCount())) || ((!lazy) && (thisChannel.length == getSampleCount())))
/*     */         {
/*     */ 
/* 508 */           newChannel = thisChannel;
/* 509 */           this.channels.remove(ch);
/* 510 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 514 */     if (newChannel == null) {
/* 515 */       newChannel = new float[getSampleCount()];
/*     */     }
/* 517 */     this.channels.add(index, newChannel);
/* 518 */     this.channelCount += 1;
/* 519 */     if (silent) {
/* 520 */       makeSilence(index);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeChannel(int channel)
/*     */   {
/* 526 */     removeChannel(channel, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChannel(int channel, boolean lazy)
/*     */   {
/* 537 */     if (!lazy) {
/* 538 */       this.channels.remove(channel);
/* 539 */     } else if (channel < getChannelCount() - 1)
/*     */     {
/* 541 */       this.channels.add(this.channels.remove(channel));
/*     */     }
/* 543 */     this.channelCount -= 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copyChannel(int sourceChannel, int targetChannel)
/*     */   {
/* 551 */     float[] source = getChannel(sourceChannel);
/* 552 */     float[] target = getChannel(targetChannel);
/* 553 */     System.arraycopy(source, 0, target, 0, getSampleCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copy(int sourceIndex, int destIndex, int length)
/*     */   {
/* 561 */     for (int i = 0; i < getChannelCount(); i++) {
/* 562 */       copy(i, sourceIndex, destIndex, length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void copy(int channel, int sourceIndex, int destIndex, int length)
/*     */   {
/* 571 */     float[] data = getChannel(channel);
/* 572 */     int bufferCount = getSampleCount();
/* 573 */     if ((sourceIndex + length > bufferCount) || (destIndex + length > bufferCount) || (sourceIndex < 0) || (destIndex < 0) || (length < 0))
/*     */     {
/* 575 */       throw new IndexOutOfBoundsException("parameters exceed buffer size");
/*     */     }
/* 577 */     System.arraycopy(data, sourceIndex, data, destIndex, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void expandChannel(int targetChannelCount)
/*     */   {
/* 591 */     if (getChannelCount() != 1) {
/* 592 */       throw new IllegalArgumentException("FloatSampleBuffer: can only expand channels for mono signals.");
/*     */     }
/*     */     
/* 595 */     for (int ch = 1; ch < targetChannelCount; ch++) {
/* 596 */       addChannel(false);
/* 597 */       copyChannel(0, ch);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void mixDownChannels()
/*     */   {
/* 609 */     float[] firstChannel = getChannel(0);
/* 610 */     int sampleCount = getSampleCount();
/* 611 */     int channelCount = getChannelCount();
/* 612 */     for (int ch = channelCount - 1; ch > 0; ch--) {
/* 613 */       float[] thisChannel = getChannel(ch);
/* 614 */       for (int i = 0; i < sampleCount; i++) {
/* 615 */         firstChannel[i] += thisChannel[i];
/*     */       }
/* 617 */       removeChannel(ch);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSamplesFromBytes(byte[] input, int inByteOffset, AudioFormat format, int floatOffset, int frameCount)
/*     */   {
/* 637 */     if ((floatOffset < 0) || (frameCount < 0) || (inByteOffset < 0)) {
/* 638 */       throw new IllegalArgumentException("FloatSampleBuffer.setSamplesFromBytes: negative inByteOffset, floatOffset, or frameCount");
/*     */     }
/*     */     
/* 641 */     if (inByteOffset + frameCount * format.getFrameSize() > input.length) {
/* 642 */       throw new IllegalArgumentException("FloatSampleBuffer.setSamplesFromBytes: input buffer too small.");
/*     */     }
/*     */     
/* 645 */     if (floatOffset + frameCount > getSampleCount()) {
/* 646 */       throw new IllegalArgumentException("FloatSampleBuffer.setSamplesFromBytes: frameCount too large");
/*     */     }
/*     */     
/*     */ 
/* 650 */     FloatSampleTools.byte2float(input, inByteOffset, this.channels, floatOffset, frameCount, format);
/*     */   }
/*     */   
/*     */ 
/*     */   public int getChannelCount()
/*     */   {
/* 656 */     return this.channelCount;
/*     */   }
/*     */   
/*     */   public int getSampleCount() {
/* 660 */     return this.sampleCount;
/*     */   }
/*     */   
/*     */   public float getSampleRate() {
/* 664 */     return this.sampleRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSampleRate(float sampleRate)
/*     */   {
/* 672 */     if (sampleRate <= 0.0F) {
/* 673 */       throw new IllegalArgumentException("Invalid samplerate for FloatSampleBuffer.");
/*     */     }
/*     */     
/* 676 */     this.sampleRate = sampleRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] getChannel(int channel)
/*     */   {
/* 684 */     if ((channel < 0) || (channel >= getChannelCount())) {
/* 685 */       throw new IllegalArgumentException("FloatSampleBuffer: invalid channel number.");
/*     */     }
/*     */     
/* 688 */     return (float[])this.channels.get(channel);
/*     */   }
/*     */   
/*     */   public Object[] getAllChannels() {
/* 692 */     Object[] res = new Object[getChannelCount()];
/* 693 */     for (int ch = 0; ch < getChannelCount(); ch++) {
/* 694 */       res[ch] = getChannel(ch);
/*     */     }
/* 696 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDitherBits(float ditherBits)
/*     */   {
/* 705 */     if (ditherBits <= 0.0F) {
/* 706 */       throw new IllegalArgumentException("DitherBits must be greater than 0");
/*     */     }
/* 708 */     this.ditherBits = ditherBits;
/*     */   }
/*     */   
/*     */   public float getDitherBits() {
/* 712 */     return this.ditherBits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDitherMode(int mode)
/*     */   {
/* 726 */     if ((mode != 0) && (mode != 1) && (mode != 2))
/*     */     {
/*     */ 
/* 729 */       throw new IllegalArgumentException("Illegal DitherMode");
/*     */     }
/* 731 */     this.ditherMode = mode;
/*     */   }
/*     */   
/*     */   public int getDitherMode() {
/* 735 */     return this.ditherMode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected float getConvertDitherBits(int newFormatType)
/*     */   {
/* 744 */     boolean doDither = false;
/* 745 */     switch (this.ditherMode) {
/*     */     case 0: 
/* 747 */       doDither = (this.originalFormatType & 0x7) > (newFormatType & 0x7);
/*     */       
/* 749 */       break;
/*     */     case 1: 
/* 751 */       doDither = true;
/* 752 */       break;
/*     */     case 2: 
/* 754 */       doDither = false;
/*     */     }
/*     */     
/* 757 */     return doDither ? this.ditherBits : 0.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\FloatSampleBuffer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */