/*    */ package org.tritonus.share.sampled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TVolumeUtils
/*    */ {
/* 35 */   private static final double FACTOR1 = 20.0D / Math.log(10.0D);
/*    */   
/*    */   private static final double FACTOR2 = 0.05D;
/*    */   
/*    */ 
/*    */   public static double lin2log(double dLinear)
/*    */   {
/* 42 */     return FACTOR1 * Math.log(dLinear);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static double log2lin(double dLogarithmic)
/*    */   {
/* 49 */     return Math.pow(10.0D, dLogarithmic * 0.05D);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\TVolumeUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */