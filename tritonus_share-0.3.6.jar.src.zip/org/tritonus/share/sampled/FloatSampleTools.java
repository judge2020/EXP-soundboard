/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatSampleTools
/*     */ {
/*     */   public static final float DEFAULT_DITHER_BITS = 0.7F;
/*  58 */   private static Random random = null;
/*     */   
/*     */   static final int F_8 = 1;
/*     */   
/*     */   static final int F_16 = 2;
/*     */   
/*     */   static final int F_24 = 3;
/*     */   
/*     */   static final int F_32 = 4;
/*     */   
/*     */   static final int F_SAMPLE_WIDTH_MASK = 7;
/*     */   
/*     */   static final int F_SIGNED = 8;
/*     */   
/*     */   static final int F_BIGENDIAN = 16;
/*     */   
/*     */   static final int CT_8S = 9;
/*     */   
/*     */   static final int CT_8U = 1;
/*     */   
/*     */   static final int CT_16SB = 26;
/*     */   static final int CT_16SL = 10;
/*     */   static final int CT_24SB = 27;
/*     */   static final int CT_24SL = 11;
/*     */   static final int CT_32SB = 28;
/*     */   static final int CT_32SL = 12;
/*     */   private static final float twoPower7 = 128.0F;
/*     */   private static final float twoPower15 = 32768.0F;
/*     */   private static final float twoPower23 = 8388608.0F;
/*     */   private static final float twoPower31 = 2.14748365E9F;
/*     */   private static final float invTwoPower7 = 0.0078125F;
/*     */   private static final float invTwoPower15 = 3.0517578E-5F;
/*     */   private static final float invTwoPower23 = 1.1920929E-7F;
/*     */   private static final float invTwoPower31 = 4.656613E-10F;
/*     */   
/*     */   static void checkSupportedSampleSize(int ssib, int channels, int frameSize)
/*     */   {
/*  95 */     if (ssib * channels != frameSize * 8) {
/*  96 */       throw new IllegalArgumentException("unsupported sample size: " + ssib + " stored in " + frameSize / channels + " bytes.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int getFormatType(AudioFormat format)
/*     */   {
/* 107 */     boolean signed = format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
/* 108 */     if ((!signed) && (!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED)))
/*     */     {
/* 110 */       throw new IllegalArgumentException("unsupported encoding: only PCM encoding supported.");
/*     */     }
/*     */     
/* 113 */     if ((!signed) && (format.getSampleSizeInBits() != 8)) {
/* 114 */       throw new IllegalArgumentException("unsupported encoding: only 8-bit can be unsigned");
/*     */     }
/*     */     
/* 117 */     checkSupportedSampleSize(format.getSampleSizeInBits(), format.getChannels(), format.getFrameSize());
/*     */     
/*     */ 
/*     */ 
/* 121 */     int formatType = getFormatType(format.getSampleSizeInBits(), signed, format.isBigEndian());
/*     */     
/* 123 */     return formatType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static int getFormatType(int ssib, boolean signed, boolean bigEndian)
/*     */   {
/* 130 */     int bytesPerSample = ssib / 8;
/* 131 */     int res = 0;
/* 132 */     if (ssib == 8) {
/* 133 */       res = 1;
/* 134 */     } else if (ssib == 16) {
/* 135 */       res = 2;
/* 136 */     } else if (ssib == 24) {
/* 137 */       res = 3;
/* 138 */     } else if (ssib == 32) {
/* 139 */       res = 4;
/*     */     }
/* 141 */     if (res == 0) {
/* 142 */       throw new IllegalArgumentException("FloatSampleBuffer: unsupported sample size of " + ssib + " bits per sample.");
/*     */     }
/*     */     
/*     */ 
/* 146 */     if ((!signed) && (bytesPerSample > 1)) {
/* 147 */       throw new IllegalArgumentException("FloatSampleBuffer: unsigned samples larger than 8 bit are not supported");
/*     */     }
/*     */     
/*     */ 
/* 151 */     if (signed) {
/* 152 */       res |= 0x8;
/*     */     }
/* 154 */     if ((bigEndian) && (ssib != 8)) {
/* 155 */       res |= 0x10;
/*     */     }
/* 157 */     return res;
/*     */   }
/*     */   
/*     */   static int getSampleSize(int formatType) {
/* 161 */     switch (formatType & 0x7) {
/* 162 */     case 1:  return 1;
/* 163 */     case 2:  return 2;
/* 164 */     case 3:  return 3;
/* 165 */     case 4:  return 4;
/*     */     }
/* 167 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static String formatType2Str(int formatType)
/*     */   {
/* 174 */     String res = "" + formatType + ": ";
/* 175 */     switch (formatType & 0x7) {
/*     */     case 1: 
/* 177 */       res = res + "8bit";
/* 178 */       break;
/*     */     case 2: 
/* 180 */       res = res + "16bit";
/* 181 */       break;
/*     */     case 3: 
/* 183 */       res = res + "24bit";
/* 184 */       break;
/*     */     case 4: 
/* 186 */       res = res + "32bit";
/*     */     }
/*     */     
/* 189 */     res = res + ((formatType & 0x8) == 8 ? " signed" : " unsigned");
/* 190 */     if ((formatType & 0x7) != 1) {
/* 191 */       res = res + ((formatType & 0x10) == 16 ? " big endian" : " little endian");
/*     */     }
/*     */     
/* 194 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void byte2float(byte[] input, int inByteOffset, List<float[]> output, int outOffset, int frameCount, AudioFormat format)
/*     */   {
/* 241 */     for (int channel = 0; channel < format.getChannels(); channel++) {
/*     */       float[] data;
/* 243 */       if (output.size() < channel) {
/* 244 */         float[] data = new float[frameCount + outOffset];
/* 245 */         output.add(data);
/*     */       } else {
/* 247 */         data = (float[])output.get(channel);
/* 248 */         if (data.length < frameCount + outOffset) {
/* 249 */           data = new float[frameCount + outOffset];
/* 250 */           output.set(channel, data);
/*     */         }
/*     */       }
/*     */       
/* 254 */       byte2floatGeneric(input, inByteOffset, format.getFrameSize(), data, outOffset, frameCount, format);
/*     */       
/*     */ 
/* 257 */       inByteOffset += format.getFrameSize() / format.getChannels();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void byte2floatInterleaved(byte[] input, int inByteOffset, float[] output, int outOffset, int frameCount, AudioFormat format)
/*     */   {
/* 290 */     byte2floatGeneric(input, inByteOffset, format.getFrameSize() / format.getChannels(), output, outOffset, frameCount * format.getChannels(), format);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void byte2floatGeneric(byte[] input, int inByteOffset, int inByteStep, float[] output, int outOffset, int sampleCount, AudioFormat format)
/*     */   {
/* 326 */     int formatType = getFormatType(format);
/*     */     
/* 328 */     byte2floatGeneric(input, inByteOffset, inByteStep, output, outOffset, sampleCount, formatType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void byte2floatGeneric(byte[] input, int inByteOffset, int inByteStep, float[] output, int outOffset, int sampleCount, int formatType)
/*     */   {
/* 356 */     int endCount = outOffset + sampleCount;
/* 357 */     int inIndex = inByteOffset;
/* 358 */     for (int outIndex = outOffset; outIndex < endCount; inIndex += inByteStep)
/*     */     {
/* 360 */       switch (formatType) {
/*     */       case 9: 
/* 362 */         output[outIndex] = (input[inIndex] * 0.0078125F);
/*     */         
/* 364 */         break;
/*     */       case 1: 
/* 366 */         output[outIndex] = (((input[inIndex] & 0xFF) - 128) * 0.0078125F);
/*     */         
/* 368 */         break;
/*     */       case 26: 
/* 370 */         output[outIndex] = ((input[inIndex] << 8 | input[(inIndex + 1)] & 0xFF) * 3.0517578E-5F);
/*     */         
/*     */ 
/* 373 */         break;
/*     */       case 10: 
/* 375 */         output[outIndex] = ((input[(inIndex + 1)] << 8 | input[inIndex] & 0xFF) * 3.0517578E-5F);
/*     */         
/*     */ 
/* 378 */         break;
/*     */       case 27: 
/* 380 */         output[outIndex] = ((input[inIndex] << 16 | (input[(inIndex + 1)] & 0xFF) << 8 | input[(inIndex + 2)] & 0xFF) * 1.1920929E-7F);
/*     */         
/*     */ 
/*     */ 
/* 384 */         break;
/*     */       case 11: 
/* 386 */         output[outIndex] = ((input[(inIndex + 2)] << 16 | (input[(inIndex + 1)] & 0xFF) << 8 | input[inIndex] & 0xFF) * 1.1920929E-7F);
/*     */         
/*     */ 
/*     */ 
/* 390 */         break;
/*     */       case 28: 
/* 392 */         output[outIndex] = ((input[inIndex] << 24 | (input[(inIndex + 1)] & 0xFF) << 16 | (input[(inIndex + 2)] & 0xFF) << 8 | input[(inIndex + 3)] & 0xFF) * 4.656613E-10F);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 397 */         break;
/*     */       case 12: 
/* 399 */         output[outIndex] = ((input[(inIndex + 3)] << 24 | (input[(inIndex + 2)] & 0xFF) << 16 | (input[(inIndex + 1)] & 0xFF) << 8 | input[inIndex] & 0xFF) * 4.656613E-10F);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 404 */         break;
/*     */       case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21: case 22: case 23: case 24: case 25: default: 
/* 406 */         throw new IllegalArgumentException("unsupported format=" + formatType2Str(formatType));
/*     */       }
/* 358 */       outIndex++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static byte quantize8(float sample, float ditherBits)
/*     */   {
/* 415 */     if (ditherBits != 0.0F) {
/* 416 */       sample += random.nextFloat() * ditherBits;
/*     */     }
/* 418 */     if (sample >= 127.0F)
/* 419 */       return Byte.MAX_VALUE;
/* 420 */     if (sample <= -128.0F) {
/* 421 */       return Byte.MIN_VALUE;
/*     */     }
/* 423 */     return (byte)(int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
/*     */   }
/*     */   
/*     */   private static int quantize16(float sample, float ditherBits)
/*     */   {
/* 428 */     if (ditherBits != 0.0F) {
/* 429 */       sample += random.nextFloat() * ditherBits;
/*     */     }
/* 431 */     if (sample >= 32767.0F)
/* 432 */       return 32767;
/* 433 */     if (sample <= -32768.0F) {
/* 434 */       return 32768;
/*     */     }
/* 436 */     return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
/*     */   }
/*     */   
/*     */   private static int quantize24(float sample, float ditherBits)
/*     */   {
/* 441 */     if (ditherBits != 0.0F) {
/* 442 */       sample += random.nextFloat() * ditherBits;
/*     */     }
/* 444 */     if (sample >= 8388607.0F)
/* 445 */       return 8388607;
/* 446 */     if (sample <= -8388608.0F) {
/* 447 */       return -8388608;
/*     */     }
/* 449 */     return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
/*     */   }
/*     */   
/*     */   private static int quantize32(float sample, float ditherBits)
/*     */   {
/* 454 */     if (ditherBits != 0.0F) {
/* 455 */       sample += random.nextFloat() * ditherBits;
/*     */     }
/* 457 */     if (sample >= 2.14748365E9F)
/* 458 */       return Integer.MAX_VALUE;
/* 459 */     if (sample <= -2.14748365E9F) {
/* 460 */       return Integer.MIN_VALUE;
/*     */     }
/* 462 */     return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void float2byte(List input, int inOffset, byte[] output, int outByteOffset, int frameCount, AudioFormat format, float ditherBits)
/*     */   {
/* 507 */     for (int channel = 0; channel < format.getChannels(); channel++) {
/* 508 */       float[] data = (float[])input.get(channel);
/* 509 */       float2byteGeneric(data, inOffset, output, outByteOffset, format.getFrameSize(), frameCount, format, ditherBits);
/*     */       
/*     */ 
/* 512 */       outByteOffset += format.getFrameSize() / format.getChannels();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void float2byteInterleaved(float[] input, int inOffset, byte[] output, int outByteOffset, int frameCount, AudioFormat format, float ditherBits)
/*     */   {
/* 552 */     float2byteGeneric(input, inOffset, output, outByteOffset, format.getFrameSize() / format.getChannels(), frameCount * format.getChannels(), format, ditherBits);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void float2byteGeneric(float[] input, int inOffset, byte[] output, int outByteOffset, int outByteStep, int sampleCount, AudioFormat format, float ditherBits)
/*     */   {
/* 588 */     int formatType = getFormatType(format);
/*     */     
/* 590 */     float2byteGeneric(input, inOffset, output, outByteOffset, outByteStep, sampleCount, formatType, ditherBits);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void float2byteGeneric(float[] input, int inOffset, byte[] output, int outByteOffset, int outByteStep, int sampleCount, int formatType, float ditherBits)
/*     */   {
/* 618 */     if ((inOffset < 0) || (inOffset + sampleCount > input.length) || (sampleCount < 0))
/*     */     {
/*     */ 
/* 621 */       throw new IllegalArgumentException("invalid input index: input.length=" + input.length + " inOffset=" + inOffset + " sampleCount=" + sampleCount);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 626 */     if ((outByteOffset < 0) || (outByteOffset + sampleCount * outByteStep >= output.length + outByteStep) || (outByteStep < getSampleSize(formatType)))
/*     */     {
/*     */ 
/* 629 */       throw new IllegalArgumentException("invalid output index: output.length=" + output.length + " outByteOffset=" + outByteOffset + " outByteStep=" + outByteStep + " sampleCount=" + sampleCount + " format=" + formatType2Str(formatType));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 637 */     if ((ditherBits != 0.0F) && (random == null))
/*     */     {
/* 639 */       random = new Random();
/*     */     }
/* 641 */     int endSample = inOffset + sampleCount;
/*     */     
/* 643 */     int outIndex = outByteOffset;
/* 644 */     int inIndex = inOffset;
/* 645 */     for (; inIndex < endSample; 
/* 646 */         outIndex += outByteStep) {
/*     */       int iSample;
/* 648 */       switch (formatType) {
/*     */       case 9: 
/* 650 */         output[outIndex] = quantize8(input[inIndex] * 128.0F, ditherBits);
/* 651 */         break;
/*     */       case 1: 
/* 653 */         output[outIndex] = ((byte)(quantize8(input[inIndex] * 128.0F, ditherBits) + 128));
/* 654 */         break;
/*     */       case 26: 
/* 656 */         iSample = quantize16(input[inIndex] * 32768.0F, ditherBits);
/* 657 */         output[outIndex] = ((byte)(iSample >> 8));
/* 658 */         output[(outIndex + 1)] = ((byte)(iSample & 0xFF));
/* 659 */         break;
/*     */       case 10: 
/* 661 */         iSample = quantize16(input[inIndex] * 32768.0F, ditherBits);
/* 662 */         output[(outIndex + 1)] = ((byte)(iSample >> 8));
/* 663 */         output[outIndex] = ((byte)(iSample & 0xFF));
/* 664 */         break;
/*     */       case 27: 
/* 666 */         iSample = quantize24(input[inIndex] * 8388608.0F, ditherBits);
/* 667 */         output[outIndex] = ((byte)(iSample >> 16));
/* 668 */         output[(outIndex + 1)] = ((byte)(iSample >>> 8 & 0xFF));
/* 669 */         output[(outIndex + 2)] = ((byte)(iSample & 0xFF));
/* 670 */         break;
/*     */       case 11: 
/* 672 */         iSample = quantize24(input[inIndex] * 8388608.0F, ditherBits);
/* 673 */         output[(outIndex + 2)] = ((byte)(iSample >> 16));
/* 674 */         output[(outIndex + 1)] = ((byte)(iSample >>> 8 & 0xFF));
/* 675 */         output[outIndex] = ((byte)(iSample & 0xFF));
/* 676 */         break;
/*     */       case 28: 
/* 678 */         iSample = quantize32(input[inIndex] * 2.14748365E9F, ditherBits);
/* 679 */         output[outIndex] = ((byte)(iSample >> 24));
/* 680 */         output[(outIndex + 1)] = ((byte)(iSample >>> 16 & 0xFF));
/* 681 */         output[(outIndex + 2)] = ((byte)(iSample >>> 8 & 0xFF));
/* 682 */         output[(outIndex + 3)] = ((byte)(iSample & 0xFF));
/* 683 */         break;
/*     */       case 12: 
/* 685 */         iSample = quantize32(input[inIndex] * 2.14748365E9F, ditherBits);
/* 686 */         output[(outIndex + 3)] = ((byte)(iSample >> 24));
/* 687 */         output[(outIndex + 2)] = ((byte)(iSample >>> 16 & 0xFF));
/* 688 */         output[(outIndex + 1)] = ((byte)(iSample >>> 8 & 0xFF));
/* 689 */         output[outIndex] = ((byte)(iSample & 0xFF));
/* 690 */         break;
/*     */       case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 13: case 14: case 15: case 16: case 17: case 18: case 19: case 20: case 21: case 22: case 23: case 24: case 25: default: 
/* 692 */         throw new IllegalArgumentException("unsupported format=" + formatType2Str(formatType));
/*     */       }
/* 646 */       inIndex++;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\FloatSampleTools.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */