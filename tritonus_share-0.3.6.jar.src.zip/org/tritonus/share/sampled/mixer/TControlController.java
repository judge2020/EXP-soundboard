/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import org.tritonus.share.TDebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TControlController
/*    */   implements TControllable
/*    */ {
/*    */   private TCompoundControl m_parentControl;
/*    */   
/*    */   public void setParentControl(TCompoundControl compoundControl)
/*    */   {
/* 73 */     this.m_parentControl = compoundControl;
/*    */   }
/*    */   
/*    */ 
/*    */   public TCompoundControl getParentControl()
/*    */   {
/* 79 */     return this.m_parentControl;
/*    */   }
/*    */   
/*    */ 
/*    */   public void commit()
/*    */   {
/* 85 */     if (TDebug.TraceControl)
/*    */     {
/* 87 */       TDebug.out("TControlController.commit(): called [" + getClass().getName() + "]");
/*    */     }
/* 89 */     if (getParentControl() != null)
/*    */     {
/* 91 */       getParentControl().commit();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TControlController.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */