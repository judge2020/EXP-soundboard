/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.Control;
/*     */ import javax.sound.sampled.DataLine;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineEvent.Type;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TDataLine
/*     */   extends TLine
/*     */   implements DataLine
/*     */ {
/*     */   private static final int DEFAULT_BUFFER_SIZE = 128000;
/*     */   private AudioFormat m_format;
/*     */   private int m_nBufferSize;
/*     */   private boolean m_bRunning;
/*     */   
/*     */   public TDataLine(TMixer mixer, DataLine.Info info)
/*     */   {
/*  69 */     super(mixer, info);
/*     */     
/*  71 */     init(info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TDataLine(TMixer mixer, DataLine.Info info, Collection<Control> controls)
/*     */   {
/*  80 */     super(mixer, info, controls);
/*     */     
/*     */ 
/*  83 */     init(info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(DataLine.Info info)
/*     */   {
/*  91 */     this.m_format = null;
/*  92 */     this.m_nBufferSize = -1;
/*  93 */     setRunning(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 107 */     if (TDebug.TraceSourceDataLine)
/*     */     {
/* 109 */       TDebug.out("TDataLine.start(): called");
/*     */     }
/* 111 */     setRunning(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 118 */     if (TDebug.TraceSourceDataLine)
/*     */     {
/* 120 */       TDebug.out("TDataLine.stop(): called");
/*     */     }
/* 122 */     setRunning(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 129 */     return this.m_bRunning;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRunning(boolean bRunning)
/*     */   {
/* 137 */     boolean bOldValue = isRunning();
/* 138 */     this.m_bRunning = bRunning;
/* 139 */     if (bOldValue != isRunning())
/*     */     {
/* 141 */       if (isRunning())
/*     */       {
/* 143 */         startImpl();
/* 144 */         notifyLineEvent(LineEvent.Type.START);
/*     */       }
/*     */       else
/*     */       {
/* 148 */         stopImpl();
/* 149 */         notifyLineEvent(LineEvent.Type.STOP);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void startImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void stopImpl() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 175 */     return isRunning();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AudioFormat getFormat()
/*     */   {
/* 202 */     return this.m_format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setFormat(AudioFormat format)
/*     */   {
/* 209 */     if (TDebug.TraceDataLine)
/*     */     {
/* 211 */       TDebug.out("TDataLine.setFormat(): setting: " + format);
/*     */     }
/* 213 */     this.m_format = format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getBufferSize()
/*     */   {
/* 220 */     return this.m_nBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setBufferSize(int nBufferSize)
/*     */   {
/* 227 */     if (TDebug.TraceDataLine)
/*     */     {
/* 229 */       TDebug.out("TDataLine.setBufferSize(): setting: " + nBufferSize);
/*     */     }
/* 231 */     this.m_nBufferSize = nBufferSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFramePosition()
/*     */   {
/* 244 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getLongFramePosition()
/*     */   {
/* 252 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public long getMicrosecondPosition()
/*     */   {
/* 259 */     return (getFramePosition() * getFormat().getFrameRate() * 1000000.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getLevel()
/*     */   {
/* 269 */     return -1.0F;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void checkOpen()
/*     */   {
/* 276 */     if (getFormat() == null)
/*     */     {
/* 278 */       throw new IllegalStateException("format must be specified");
/*     */     }
/* 280 */     if (getBufferSize() == -1)
/*     */     {
/* 282 */       setBufferSize(getDefaultBufferSize());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int getDefaultBufferSize()
/*     */   {
/* 290 */     return 128000;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void notifyLineEvent(LineEvent.Type type)
/*     */   {
/* 297 */     notifyLineEvent(new LineEvent(this, type, getFramePosition()));
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TDataLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */