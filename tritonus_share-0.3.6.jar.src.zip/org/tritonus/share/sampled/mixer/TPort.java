/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import javax.sound.sampled.Control;
/*    */ import javax.sound.sampled.Line.Info;
/*    */ import javax.sound.sampled.Port;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TPort
/*    */   extends TLine
/*    */   implements Port
/*    */ {
/*    */   public TPort(TMixer mixer, Line.Info info)
/*    */   {
/* 62 */     super(mixer, info);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TPort(TMixer mixer, Line.Info info, Collection<Control> controls)
/*    */   {
/* 71 */     super(mixer, info, controls);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TPort.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */