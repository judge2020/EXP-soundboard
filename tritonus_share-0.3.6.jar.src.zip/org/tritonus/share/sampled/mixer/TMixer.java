/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.Line;
/*     */ import javax.sound.sampled.Line.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import javax.sound.sampled.Mixer.Info;
/*     */ import javax.sound.sampled.Port;
/*     */ import javax.sound.sampled.Port.Info;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ import javax.sound.sampled.TargetDataLine;
/*     */ import org.tritonus.share.ArraySet;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.sampled.AudioFormats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TMixer
/*     */   extends TLine
/*     */   implements Mixer
/*     */ {
/*  59 */   private static Line.Info[] EMPTY_LINE_INFO_ARRAY = new Line.Info[0];
/*  60 */   private static Line[] EMPTY_LINE_ARRAY = new Line[0];
/*     */   
/*     */   private Mixer.Info m_mixerInfo;
/*     */   
/*     */   private Collection<AudioFormat> m_supportedSourceFormats;
/*     */   
/*     */   private Collection<AudioFormat> m_supportedTargetFormats;
/*     */   
/*     */   private Collection<Line.Info> m_supportedSourceLineInfos;
/*     */   
/*     */   private Collection<Line.Info> m_supportedTargetLineInfos;
/*     */   private Set<SourceDataLine> m_openSourceDataLines;
/*     */   private Set<TargetDataLine> m_openTargetDataLines;
/*     */   
/*     */   protected TMixer(Mixer.Info mixerInfo, Line.Info lineInfo)
/*     */   {
/*  76 */     this(mixerInfo, lineInfo, new ArrayList(), new ArrayList(), new ArrayList(), new ArrayList());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TMixer(Mixer.Info mixerInfo, Line.Info lineInfo, Collection<AudioFormat> supportedSourceFormats, Collection<AudioFormat> supportedTargetFormats, Collection<Line.Info> supportedSourceLineInfos, Collection<Line.Info> supportedTargetLineInfos)
/*     */   {
/*  95 */     super(null, lineInfo);
/*     */     
/*  97 */     if (TDebug.TraceMixer) TDebug.out("TMixer.<init>(): begin");
/*  98 */     this.m_mixerInfo = mixerInfo;
/*  99 */     setSupportInformation(supportedSourceFormats, supportedTargetFormats, supportedSourceLineInfos, supportedTargetLineInfos);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 104 */     this.m_openSourceDataLines = new ArraySet();
/* 105 */     this.m_openTargetDataLines = new ArraySet();
/* 106 */     if (TDebug.TraceMixer) { TDebug.out("TMixer.<init>(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSupportInformation(Collection<AudioFormat> supportedSourceFormats, Collection<AudioFormat> supportedTargetFormats, Collection<Line.Info> supportedSourceLineInfos, Collection<Line.Info> supportedTargetLineInfos)
/*     */   {
/* 117 */     if (TDebug.TraceMixer) TDebug.out("TMixer.setSupportInformation(): begin");
/* 118 */     this.m_supportedSourceFormats = supportedSourceFormats;
/* 119 */     this.m_supportedTargetFormats = supportedTargetFormats;
/* 120 */     this.m_supportedSourceLineInfos = supportedSourceLineInfos;
/* 121 */     this.m_supportedTargetLineInfos = supportedTargetLineInfos;
/* 122 */     if (TDebug.TraceMixer) { TDebug.out("TMixer.setSupportInformation(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Mixer.Info getMixerInfo()
/*     */   {
/* 129 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getMixerInfo(): begin");
/* 130 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getMixerInfo(): end");
/* 131 */     return this.m_mixerInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line.Info[] getSourceLineInfo()
/*     */   {
/* 138 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSourceLineInfo(): begin");
/* 139 */     Line.Info[] infos = (Line.Info[])this.m_supportedSourceLineInfos.toArray(EMPTY_LINE_INFO_ARRAY);
/* 140 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSourceLineInfo(): end");
/* 141 */     return infos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line.Info[] getTargetLineInfo()
/*     */   {
/* 148 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getTargetLineInfo(): begin");
/* 149 */     Line.Info[] infos = (Line.Info[])this.m_supportedTargetLineInfos.toArray(EMPTY_LINE_INFO_ARRAY);
/* 150 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getTargetLineInfo(): end");
/* 151 */     return infos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line.Info[] getSourceLineInfo(Line.Info info)
/*     */   {
/* 158 */     if (TDebug.TraceMixer) { TDebug.out("TMixer.getSourceLineInfo(Line.Info): info to test: " + info);
/*     */     }
/* 160 */     return EMPTY_LINE_INFO_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line.Info[] getTargetLineInfo(Line.Info info)
/*     */   {
/* 167 */     if (TDebug.TraceMixer) { TDebug.out("TMixer.getTargetLineInfo(Line.Info): info to test: " + info);
/*     */     }
/* 169 */     return EMPTY_LINE_INFO_ARRAY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isLineSupported(Line.Info info)
/*     */   {
/* 176 */     if (TDebug.TraceMixer) TDebug.out("TMixer.isLineSupported(): info to test: " + info);
/* 177 */     Class lineClass = info.getLineClass();
/* 178 */     if (lineClass.equals(SourceDataLine.class))
/*     */     {
/* 180 */       return isLineSupportedImpl(info, this.m_supportedSourceLineInfos);
/*     */     }
/* 182 */     if (lineClass.equals(TargetDataLine.class))
/*     */     {
/* 184 */       return isLineSupportedImpl(info, this.m_supportedTargetLineInfos);
/*     */     }
/* 186 */     if (lineClass.equals(Port.class))
/*     */     {
/* 188 */       return (isLineSupportedImpl(info, this.m_supportedSourceLineInfos)) || (isLineSupportedImpl(info, this.m_supportedTargetLineInfos));
/*     */     }
/*     */     
/*     */ 
/* 192 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean isLineSupportedImpl(Line.Info info, Collection supportedLineInfos)
/*     */   {
/* 200 */     Iterator iterator = supportedLineInfos.iterator();
/* 201 */     while (iterator.hasNext())
/*     */     {
/* 203 */       Line.Info info2 = (Line.Info)iterator.next();
/* 204 */       if (info2.matches(info))
/*     */       {
/* 206 */         return true;
/*     */       }
/*     */     }
/* 209 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line getLine(Line.Info info)
/*     */     throws LineUnavailableException
/*     */   {
/* 217 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): begin");
/* 218 */     Class lineClass = info.getLineClass();
/* 219 */     DataLine.Info dataLineInfo = null;
/* 220 */     Port.Info portInfo = null;
/* 221 */     AudioFormat[] aFormats = null;
/* 222 */     if ((info instanceof DataLine.Info))
/*     */     {
/* 224 */       dataLineInfo = (DataLine.Info)info;
/* 225 */       aFormats = dataLineInfo.getFormats();
/*     */     }
/* 227 */     else if ((info instanceof Port.Info))
/*     */     {
/* 229 */       portInfo = (Port.Info)info;
/*     */     }
/* 231 */     AudioFormat format = null;
/* 232 */     Line line = null;
/* 233 */     if (lineClass == SourceDataLine.class)
/*     */     {
/* 235 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): type: SourceDataLine");
/* 236 */       if (dataLineInfo == null)
/*     */       {
/* 238 */         throw new IllegalArgumentException("need DataLine.Info for SourceDataLine");
/*     */       }
/* 240 */       format = getSupportedSourceFormat(aFormats);
/* 241 */       line = getSourceDataLine(format, dataLineInfo.getMaxBufferSize());
/*     */     }
/* 243 */     else if (lineClass == Clip.class)
/*     */     {
/* 245 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): type: Clip");
/* 246 */       if (dataLineInfo == null)
/*     */       {
/* 248 */         throw new IllegalArgumentException("need DataLine.Info for Clip");
/*     */       }
/* 250 */       format = getSupportedSourceFormat(aFormats);
/* 251 */       line = getClip(format);
/*     */     }
/* 253 */     else if (lineClass == TargetDataLine.class)
/*     */     {
/* 255 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): type: TargetDataLine");
/* 256 */       if (dataLineInfo == null)
/*     */       {
/* 258 */         throw new IllegalArgumentException("need DataLine.Info for TargetDataLine");
/*     */       }
/* 260 */       format = getSupportedTargetFormat(aFormats);
/* 261 */       line = getTargetDataLine(format, dataLineInfo.getMaxBufferSize());
/*     */     }
/* 263 */     else if (lineClass == Port.class)
/*     */     {
/* 265 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): type: TargetDataLine");
/* 266 */       if (portInfo == null)
/*     */       {
/* 268 */         throw new IllegalArgumentException("need Port.Info for Port");
/*     */       }
/* 270 */       line = getPort(portInfo);
/*     */     }
/*     */     else
/*     */     {
/* 274 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): unknown line type, will throw exception");
/* 275 */       throw new LineUnavailableException("unknown line class: " + lineClass);
/*     */     }
/* 277 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getLine(): end");
/* 278 */     return line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected SourceDataLine getSourceDataLine(AudioFormat format, int nBufferSize)
/*     */     throws LineUnavailableException
/*     */   {
/* 286 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSourceDataLine(): begin");
/* 287 */     throw new IllegalArgumentException("this mixer does not support SourceDataLines");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Clip getClip(AudioFormat format)
/*     */     throws LineUnavailableException
/*     */   {
/* 295 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getClip(): begin");
/* 296 */     throw new IllegalArgumentException("this mixer does not support Clips");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected TargetDataLine getTargetDataLine(AudioFormat format, int nBufferSize)
/*     */     throws LineUnavailableException
/*     */   {
/* 304 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getTargetDataLine(): begin");
/* 305 */     throw new IllegalArgumentException("this mixer does not support TargetDataLines");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected Port getPort(Port.Info info)
/*     */     throws LineUnavailableException
/*     */   {
/* 313 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getTargetDataLine(): begin");
/* 314 */     throw new IllegalArgumentException("this mixer does not support Ports");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AudioFormat getSupportedSourceFormat(AudioFormat[] aFormats)
/*     */   {
/* 321 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedSourceFormat(): begin");
/* 322 */     AudioFormat format = null;
/* 323 */     for (int i = 0; i < aFormats.length; i++)
/*     */     {
/* 325 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedSourceFormat(): checking " + aFormats[i] + "...");
/* 326 */       if (isSourceFormatSupported(aFormats[i]))
/*     */       {
/* 328 */         if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedSourceFormat(): ...supported");
/* 329 */         format = aFormats[i];
/* 330 */         break;
/*     */       }
/*     */       
/*     */ 
/* 334 */       if (TDebug.TraceMixer)
/*     */       {
/* 336 */         TDebug.out("TMixer.getSupportedSourceFormat(): ...no luck");
/*     */       }
/*     */     }
/*     */     
/* 340 */     if (format == null)
/*     */     {
/* 342 */       throw new IllegalArgumentException("no line matchine one of the passed formats");
/*     */     }
/* 344 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedSourceFormat(): end");
/* 345 */     return format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private AudioFormat getSupportedTargetFormat(AudioFormat[] aFormats)
/*     */   {
/* 352 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedTargetFormat(): begin");
/* 353 */     AudioFormat format = null;
/* 354 */     for (int i = 0; i < aFormats.length; i++)
/*     */     {
/* 356 */       if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedTargetFormat(): checking " + aFormats[i] + " ...");
/* 357 */       if (isTargetFormatSupported(aFormats[i]))
/*     */       {
/* 359 */         if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedTargetFormat(): ...supported");
/* 360 */         format = aFormats[i];
/* 361 */         break;
/*     */       }
/*     */       
/*     */ 
/* 365 */       if (TDebug.TraceMixer)
/*     */       {
/* 367 */         TDebug.out("TMixer.getSupportedTargetFormat(): ...no luck");
/*     */       }
/*     */     }
/*     */     
/* 371 */     if (format == null)
/*     */     {
/* 373 */       throw new IllegalArgumentException("no line matchine one of the passed formats");
/*     */     }
/* 375 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSupportedTargetFormat(): end");
/* 376 */     return format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Line[] getSourceLines()
/*     */   {
/* 390 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getSourceLines(): called");
/* 391 */     return (Line[])this.m_openSourceDataLines.toArray(EMPTY_LINE_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Line[] getTargetLines()
/*     */   {
/* 398 */     if (TDebug.TraceMixer) TDebug.out("TMixer.getTargetLines(): called");
/* 399 */     return (Line[])this.m_openTargetDataLines.toArray(EMPTY_LINE_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void synchronize(Line[] aLines, boolean bMaintainSync)
/*     */   {
/* 407 */     throw new IllegalArgumentException("synchronization not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void unsynchronize(Line[] aLines)
/*     */   {
/* 414 */     throw new IllegalArgumentException("synchronization not supported");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSynchronizationSupported(Line[] aLines, boolean bMaintainSync)
/*     */   {
/* 422 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isSourceFormatSupported(AudioFormat format)
/*     */   {
/* 429 */     if (TDebug.TraceMixer) TDebug.out("TMixer.isSourceFormatSupported(): format to test: " + format);
/* 430 */     Iterator<AudioFormat> iterator = this.m_supportedSourceFormats.iterator();
/* 431 */     while (iterator.hasNext())
/*     */     {
/* 433 */       AudioFormat supportedFormat = (AudioFormat)iterator.next();
/* 434 */       if (AudioFormats.matches(supportedFormat, format))
/*     */       {
/* 436 */         return true;
/*     */       }
/*     */     }
/* 439 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean isTargetFormatSupported(AudioFormat format)
/*     */   {
/* 446 */     if (TDebug.TraceMixer) TDebug.out("TMixer.isTargetFormatSupported(): format to test: " + format);
/* 447 */     Iterator<AudioFormat> iterator = this.m_supportedTargetFormats.iterator();
/* 448 */     while (iterator.hasNext())
/*     */     {
/* 450 */       AudioFormat supportedFormat = (AudioFormat)iterator.next();
/* 451 */       if (AudioFormats.matches(supportedFormat, format))
/*     */       {
/* 453 */         return true;
/*     */       }
/*     */     }
/* 456 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void registerOpenLine(Line line)
/*     */   {
/* 463 */     if (TDebug.TraceMixer) { TDebug.out("TMixer.registerOpenLine(): line to register: " + line);
/*     */     }
/* 465 */     if ((line instanceof SourceDataLine))
/*     */     {
/* 467 */       synchronized (this.m_openSourceDataLines)
/*     */       {
/* 469 */         this.m_openSourceDataLines.add((SourceDataLine)line);
/*     */       }
/*     */       
/* 472 */     } else if ((line instanceof TargetDataLine))
/*     */     {
/* 474 */       synchronized (this.m_openSourceDataLines)
/*     */       {
/* 476 */         this.m_openTargetDataLines.add((TargetDataLine)line);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void unregisterOpenLine(Line line)
/*     */   {
/* 485 */     if (TDebug.TraceMixer) TDebug.out("TMixer.unregisterOpenLine(): line to unregister: " + line);
/* 486 */     if ((line instanceof SourceDataLine))
/*     */     {
/* 488 */       synchronized (this.m_openSourceDataLines)
/*     */       {
/* 490 */         this.m_openSourceDataLines.remove((SourceDataLine)line);
/*     */       }
/*     */       
/* 493 */     } else if ((line instanceof TargetDataLine))
/*     */     {
/* 495 */       synchronized (this.m_openTargetDataLines)
/*     */       {
/* 497 */         this.m_openTargetDataLines.remove((TargetDataLine)line);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TMixer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */