/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.Control;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TClip
/*     */   extends TDataLine
/*     */   implements Clip
/*     */ {
/*  55 */   private static final Class[] CONTROL_CLASSES = new Class[0];
/*     */   
/*     */   private static final int BUFFER_FRAMES = 16384;
/*     */   
/*     */   public TClip(DataLine.Info info)
/*     */   {
/*  61 */     super(null, info);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TClip(DataLine.Info info, Collection<Control> controls)
/*     */   {
/*  70 */     super(null, info, controls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(AudioFormat audioFormat, byte[] abData, int nOffset, int nLength)
/*     */     throws LineUnavailableException
/*     */   {
/*  86 */     ByteArrayInputStream bais = new ByteArrayInputStream(abData, nOffset, nLength);
/*  87 */     AudioInputStream audioInputStream = new AudioInputStream(bais, audioFormat, -1L);
/*     */     try
/*     */     {
/*  90 */       open(audioInputStream);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  94 */       if (TDebug.TraceAllExceptions)
/*     */       {
/*  96 */         TDebug.out(e);
/*     */       }
/*  98 */       throw new LineUnavailableException("IOException occured");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open(AudioInputStream audioInputStream)
/*     */     throws LineUnavailableException, IOException
/*     */   {
/* 107 */     AudioFormat audioFormat = audioInputStream.getFormat();
/*     */     
/* 109 */     DataLine.Info info = new DataLine.Info(Clip.class, audioFormat, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFrameLength()
/*     */   {
/* 168 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondLength()
/*     */   {
/* 176 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFramePosition(int nPosition) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMicrosecondPosition(long lPosition) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFramePosition()
/*     */   {
/* 198 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondPosition()
/*     */   {
/* 206 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoopPoints(int nStart, int nEnd) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loop(int nCount)
/*     */   {
/* 220 */     if (TDebug.TraceClip)
/*     */     {
/* 222 */       TDebug.out("TClip.loop(int): called; count = " + nCount);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */     if (nCount == 0)
/*     */     {
/* 243 */       if (TDebug.TraceClip)
/*     */       {
/* 245 */         TDebug.out("TClip.loop(int): starting sample (once)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 257 */     else if (TDebug.TraceClip)
/*     */     {
/* 259 */       TDebug.out("TClip.loop(int): starting sample (forever)");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drain() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 302 */     if (TDebug.TraceClip)
/*     */     {
/* 304 */       TDebug.out("TClip.start(): called");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 310 */     if (TDebug.TraceClip)
/*     */     {
/* 312 */       TDebug.out("TClip.start(): calling 'loop(0)' [hack]");
/*     */     }
/* 314 */     loop(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */   {
/* 333 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TClip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */