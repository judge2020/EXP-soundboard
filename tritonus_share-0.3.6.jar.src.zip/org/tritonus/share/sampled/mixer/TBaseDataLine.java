/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ import javax.sound.sampled.Control;
/*    */ import javax.sound.sampled.DataLine.Info;
/*    */ import javax.sound.sampled.LineUnavailableException;
/*    */ import org.tritonus.share.TDebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TBaseDataLine
/*    */   extends TDataLine
/*    */ {
/*    */   public TBaseDataLine(TMixer mixer, DataLine.Info info)
/*    */   {
/* 57 */     super(mixer, info);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TBaseDataLine(TMixer mixer, DataLine.Info info, Collection<Control> controls)
/*    */   {
/* 67 */     super(mixer, info, controls);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void open(AudioFormat format, int nBufferSize)
/*    */     throws LineUnavailableException
/*    */   {
/* 77 */     if (TDebug.TraceDataLine) TDebug.out("TBaseDataLine.open(AudioFormat, int): called with buffer size: " + nBufferSize);
/* 78 */     setBufferSize(nBufferSize);
/* 79 */     open(format);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void open(AudioFormat format)
/*    */     throws LineUnavailableException
/*    */   {
/* 87 */     if (TDebug.TraceDataLine) TDebug.out("TBaseDataLine.open(AudioFormat): called");
/* 88 */     setFormat(format);
/* 89 */     open();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void finalize()
/*    */   {
/* 97 */     if (isOpen())
/*    */     {
/* 99 */       close();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TBaseDataLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */