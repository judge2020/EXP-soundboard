/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import javax.sound.sampled.CompoundControl;
/*    */ import javax.sound.sampled.CompoundControl.Type;
/*    */ import javax.sound.sampled.Control;
/*    */ import org.tritonus.share.TDebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TCompoundControl
/*    */   extends CompoundControl
/*    */   implements TControllable
/*    */ {
/*    */   private TControlController m_controller;
/*    */   
/*    */   public TCompoundControl(CompoundControl.Type type, Control[] aMemberControls)
/*    */   {
/* 54 */     super(type, aMemberControls);
/* 55 */     if (TDebug.TraceControl)
/*    */     {
/* 57 */       TDebug.out("TCompoundControl.<init>: begin");
/*    */     }
/* 59 */     this.m_controller = new TControlController();
/* 60 */     if (TDebug.TraceControl)
/*    */     {
/* 62 */       TDebug.out("TCompoundControl.<init>: end");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setParentControl(TCompoundControl compoundControl)
/*    */   {
/* 70 */     this.m_controller.setParentControl(compoundControl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public TCompoundControl getParentControl()
/*    */   {
/* 77 */     return this.m_controller.getParentControl();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void commit()
/*    */   {
/* 84 */     this.m_controller.commit();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TCompoundControl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */