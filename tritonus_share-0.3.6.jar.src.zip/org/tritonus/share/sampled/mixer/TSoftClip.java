/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.DataLine.Info;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TSoftClip
/*     */   extends TClip
/*     */   implements Runnable
/*     */ {
/*  55 */   private static final Class[] CONTROL_CLASSES = new Class[0];
/*     */   
/*     */   private static final int BUFFER_SIZE = 16384;
/*     */   
/*     */   private Mixer m_mixer;
/*     */   
/*     */   private SourceDataLine m_line;
/*     */   
/*     */   private byte[] m_abClip;
/*     */   
/*     */   private int m_nRepeatCount;
/*     */   
/*     */   private Thread m_thread;
/*     */   
/*     */ 
/*     */   public TSoftClip(Mixer mixer, AudioFormat format)
/*     */     throws LineUnavailableException
/*     */   {
/*  73 */     super(null);
/*  74 */     this.m_mixer = mixer;
/*  75 */     DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
/*     */     
/*     */ 
/*     */ 
/*  79 */     this.m_line = ((SourceDataLine)AudioSystem.getLine(info));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open(AudioInputStream audioInputStream)
/*     */     throws LineUnavailableException, IOException
/*     */   {
/*  87 */     AudioFormat audioFormat = audioInputStream.getFormat();
/*  88 */     setFormat(audioFormat);
/*  89 */     int nFrameSize = audioFormat.getFrameSize();
/*  90 */     if (nFrameSize < 1)
/*     */     {
/*  92 */       throw new IllegalArgumentException("frame size must be positive");
/*     */     }
/*  94 */     if (TDebug.TraceClip)
/*     */     {
/*  96 */       TDebug.out("TSoftClip.open(): format: " + audioFormat);
/*     */     }
/*     */     
/*  99 */     byte[] abData = new byte['䀀'];
/* 100 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 101 */     int nBytesRead = 0;
/* 102 */     while (nBytesRead != -1)
/*     */     {
/*     */       try
/*     */       {
/* 106 */         nBytesRead = audioInputStream.read(abData, 0, abData.length);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 110 */         if ((TDebug.TraceClip) || (TDebug.TraceAllExceptions))
/*     */         {
/* 112 */           TDebug.out(e);
/*     */         }
/*     */       }
/* 115 */       if (nBytesRead >= 0)
/*     */       {
/* 117 */         if (TDebug.TraceClip)
/*     */         {
/* 119 */           TDebug.out("TSoftClip.open(): Trying to write: " + nBytesRead);
/*     */         }
/* 121 */         baos.write(abData, 0, nBytesRead);
/* 122 */         if (TDebug.TraceClip)
/*     */         {
/* 124 */           TDebug.out("TSoftClip.open(): Written: " + nBytesRead);
/*     */         }
/*     */       }
/*     */     }
/* 128 */     this.m_abClip = baos.toByteArray();
/* 129 */     setBufferSize(this.m_abClip.length);
/*     */     
/* 131 */     this.m_line.open(getFormat());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFrameLength()
/*     */   {
/* 140 */     if (isOpen())
/*     */     {
/* 142 */       return getBufferSize() / getFormat().getFrameSize();
/*     */     }
/*     */     
/*     */ 
/* 146 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondLength()
/*     */   {
/* 154 */     if (isOpen())
/*     */     {
/* 156 */       return (getFrameLength() * getFormat().getFrameRate() * 1000000.0F);
/*     */     }
/*     */     
/*     */ 
/* 160 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFramePosition(int nPosition) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMicrosecondPosition(long lPosition) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFramePosition()
/*     */   {
/* 183 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public long getMicrosecondPosition()
/*     */   {
/* 191 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLoopPoints(int nStart, int nEnd) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loop(int nCount)
/*     */   {
/* 205 */     if (TDebug.TraceClip)
/*     */     {
/* 207 */       TDebug.out("TSoftClip.loop(int): called; count = " + nCount);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 226 */     this.m_nRepeatCount = nCount;
/* 227 */     this.m_thread = new Thread(this);
/* 228 */     this.m_thread.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drain() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void start()
/*     */   {
/* 268 */     if (TDebug.TraceClip)
/*     */     {
/* 270 */       TDebug.out("TSoftClip.start(): called");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 276 */     if (TDebug.TraceClip)
/*     */     {
/* 278 */       TDebug.out("TSoftClip.start(): calling 'loop(0)' [hack]");
/*     */     }
/* 280 */     loop(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stop() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int available()
/*     */   {
/* 299 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/* 306 */     while (this.m_nRepeatCount >= 0)
/*     */     {
/* 308 */       this.m_line.write(this.m_abClip, 0, this.m_abClip.length);
/* 309 */       this.m_nRepeatCount -= 1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TSoftClip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */