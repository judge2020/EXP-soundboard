/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import javax.sound.sampled.EnumControl;
/*    */ import javax.sound.sampled.EnumControl.Type;
/*    */ import org.tritonus.share.TDebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TEnumControl
/*    */   extends EnumControl
/*    */   implements TControllable
/*    */ {
/*    */   private TControlController m_controller;
/*    */   
/*    */   public TEnumControl(EnumControl.Type type, Object[] aValues, Object value)
/*    */   {
/* 54 */     super(type, aValues, value);
/*    */     
/*    */ 
/* 57 */     if (TDebug.TraceControl)
/*    */     {
/* 59 */       TDebug.out("TEnumControl.<init>: begin");
/*    */     }
/* 61 */     this.m_controller = new TControlController();
/* 62 */     if (TDebug.TraceControl)
/*    */     {
/* 64 */       TDebug.out("TEnumControl.<init>: end");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setParentControl(TCompoundControl compoundControl)
/*    */   {
/* 72 */     this.m_controller.setParentControl(compoundControl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public TCompoundControl getParentControl()
/*    */   {
/* 79 */     return this.m_controller.getParentControl();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void commit()
/*    */   {
/* 86 */     this.m_controller.commit();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TEnumControl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */