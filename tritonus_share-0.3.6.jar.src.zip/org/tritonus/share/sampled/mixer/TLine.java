/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.sound.sampled.Control;
/*     */ import javax.sound.sampled.Control.Type;
/*     */ import javax.sound.sampled.Line;
/*     */ import javax.sound.sampled.Line.Info;
/*     */ import javax.sound.sampled.LineEvent;
/*     */ import javax.sound.sampled.LineEvent.Type;
/*     */ import javax.sound.sampled.LineListener;
/*     */ import javax.sound.sampled.LineUnavailableException;
/*     */ import org.tritonus.share.TDebug;
/*     */ import org.tritonus.share.TNotifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TLine
/*     */   implements Line
/*     */ {
/*  58 */   private static final Control[] EMPTY_CONTROL_ARRAY = new Control[0];
/*     */   
/*     */   private Line.Info m_info;
/*     */   
/*     */   private boolean m_bOpen;
/*     */   
/*     */   private List<Control> m_controls;
/*     */   
/*     */   private Set<LineListener> m_lineListeners;
/*     */   private TMixer m_mixer;
/*     */   
/*     */   protected TLine(TMixer mixer, Line.Info info)
/*     */   {
/*  71 */     setLineInfo(info);
/*  72 */     setOpen(false);
/*  73 */     this.m_controls = new ArrayList();
/*  74 */     this.m_lineListeners = new HashSet();
/*  75 */     this.m_mixer = mixer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected TLine(TMixer mixer, Line.Info info, Collection<Control> controls)
/*     */   {
/*  84 */     this(mixer, info);
/*  85 */     this.m_controls.addAll(controls);
/*     */   }
/*     */   
/*     */ 
/*     */   protected TMixer getMixer()
/*     */   {
/*  91 */     return this.m_mixer;
/*     */   }
/*     */   
/*     */ 
/*     */   public Line.Info getLineInfo()
/*     */   {
/*  97 */     return this.m_info;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void setLineInfo(Line.Info info)
/*     */   {
/* 104 */     if (TDebug.TraceLine)
/*     */     {
/* 106 */       TDebug.out("TLine.setLineInfo(): setting: " + info);
/*     */     }
/* 108 */     synchronized (this)
/*     */     {
/* 110 */       this.m_info = info;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws LineUnavailableException
/*     */   {
/* 119 */     if (TDebug.TraceLine)
/*     */     {
/* 121 */       TDebug.out("TLine.open(): called");
/*     */     }
/* 123 */     if (!isOpen())
/*     */     {
/* 125 */       if (TDebug.TraceLine)
/*     */       {
/* 127 */         TDebug.out("TLine.open(): opening");
/*     */       }
/* 129 */       openImpl();
/* 130 */       if (getMixer() != null)
/*     */       {
/* 132 */         getMixer().registerOpenLine(this);
/*     */       }
/* 134 */       setOpen(true);
/*     */ 
/*     */ 
/*     */     }
/* 138 */     else if (TDebug.TraceLine)
/*     */     {
/* 140 */       TDebug.out("TLine.open(): already open");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void openImpl()
/*     */     throws LineUnavailableException
/*     */   {
/* 153 */     if (TDebug.TraceLine)
/*     */     {
/* 155 */       TDebug.out("TLine.openImpl(): called");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 163 */     if (TDebug.TraceLine)
/*     */     {
/* 165 */       TDebug.out("TLine.close(): called");
/*     */     }
/* 167 */     if (isOpen())
/*     */     {
/* 169 */       if (TDebug.TraceLine)
/*     */       {
/* 171 */         TDebug.out("TLine.close(): closing");
/*     */       }
/* 173 */       if (getMixer() != null)
/*     */       {
/* 175 */         getMixer().unregisterOpenLine(this);
/*     */       }
/* 177 */       closeImpl();
/* 178 */       setOpen(false);
/*     */ 
/*     */ 
/*     */     }
/* 182 */     else if (TDebug.TraceLine)
/*     */     {
/* 184 */       TDebug.out("TLine.close(): not open");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void closeImpl()
/*     */   {
/* 196 */     if (TDebug.TraceLine)
/*     */     {
/* 198 */       TDebug.out("TLine.closeImpl(): called");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/* 208 */     return this.m_bOpen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setOpen(boolean bOpen)
/*     */   {
/* 216 */     if (TDebug.TraceLine)
/*     */     {
/* 218 */       TDebug.out("TLine.setOpen(): called, value: " + bOpen);
/*     */     }
/* 220 */     boolean bOldValue = isOpen();
/* 221 */     this.m_bOpen = bOpen;
/* 222 */     if (bOldValue != isOpen())
/*     */     {
/* 224 */       if (isOpen())
/*     */       {
/* 226 */         if (TDebug.TraceLine)
/*     */         {
/* 228 */           TDebug.out("TLine.setOpen(): opened");
/*     */         }
/* 230 */         notifyLineEvent(LineEvent.Type.OPEN);
/*     */       }
/*     */       else
/*     */       {
/* 234 */         if (TDebug.TraceLine)
/*     */         {
/* 236 */           TDebug.out("TLine.setOpen(): closed");
/*     */         }
/* 238 */         notifyLineEvent(LineEvent.Type.CLOSE);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addControl(Control control)
/*     */   {
/* 247 */     synchronized (this.m_controls)
/*     */     {
/* 249 */       this.m_controls.add(control);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void removeControl(Control control)
/*     */   {
/* 257 */     synchronized (this.m_controls)
/*     */     {
/* 259 */       this.m_controls.remove(control);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public Control[] getControls()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 6	org/tritonus/share/sampled/mixer/TLine:m_controls	Ljava/util/List;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 6	org/tritonus/share/sampled/mixer/TLine:m_controls	Ljava/util/List;
/*     */     //   11: getstatic 46	org/tritonus/share/sampled/mixer/TLine:EMPTY_CONTROL_ARRAY	[Ljavax/sound/sampled/Control;
/*     */     //   14: invokeinterface 47 2 0
/*     */     //   19: checkcast 48	[Ljavax/sound/sampled/Control;
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: areturn
/*     */     //   25: astore_2
/*     */     //   26: aload_1
/*     */     //   27: monitorexit
/*     */     //   28: aload_2
/*     */     //   29: athrow
/*     */     // Line number table:
/*     */     //   Java source line #267	-> byte code offset #0
/*     */     //   Java source line #269	-> byte code offset #7
/*     */     //   Java source line #270	-> byte code offset #25
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	30	0	this	TLine
/*     */     //   5	22	1	Ljava/lang/Object;	Object
/*     */     //   25	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	24	25	finally
/*     */     //   25	28	25	finally
/*     */   }
/*     */   
/*     */   public Control getControl(Control.Type controlType)
/*     */   {
/* 277 */     synchronized (this.m_controls)
/*     */     {
/* 279 */       Iterator<Control> it = this.m_controls.iterator();
/* 280 */       while (it.hasNext())
/*     */       {
/* 282 */         Control control = (Control)it.next();
/* 283 */         if (control.getType().equals(controlType))
/*     */         {
/* 285 */           return control;
/*     */         }
/*     */       }
/* 288 */       throw new IllegalArgumentException("no control of type " + controlType);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isControlSupported(Control.Type controlType)
/*     */   {
/*     */     try
/*     */     {
/* 299 */       return getControl(controlType) != null;
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 303 */       if (TDebug.TraceAllExceptions)
/*     */       {
/* 305 */         TDebug.out(e);
/*     */       }
/*     */     }
/* 308 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLineListener(LineListener listener)
/*     */   {
/* 317 */     synchronized (this.m_lineListeners)
/*     */     {
/* 319 */       this.m_lineListeners.add(listener);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void removeLineListener(LineListener listener)
/*     */   {
/* 327 */     synchronized (this.m_lineListeners)
/*     */     {
/* 329 */       this.m_lineListeners.remove(listener);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private Set<LineListener> getLineListeners()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 9	org/tritonus/share/sampled/mixer/TLine:m_lineListeners	Ljava/util/Set;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: new 7	java/util/HashSet
/*     */     //   10: dup
/*     */     //   11: aload_0
/*     */     //   12: getfield 9	org/tritonus/share/sampled/mixer/TLine:m_lineListeners	Ljava/util/Set;
/*     */     //   15: invokespecial 63	java/util/HashSet:<init>	(Ljava/util/Collection;)V
/*     */     //   18: aload_1
/*     */     //   19: monitorexit
/*     */     //   20: areturn
/*     */     //   21: astore_2
/*     */     //   22: aload_1
/*     */     //   23: monitorexit
/*     */     //   24: aload_2
/*     */     //   25: athrow
/*     */     // Line number table:
/*     */     //   Java source line #337	-> byte code offset #0
/*     */     //   Java source line #339	-> byte code offset #7
/*     */     //   Java source line #340	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	26	0	this	TLine
/*     */     //   5	18	1	Ljava/lang/Object;	Object
/*     */     //   21	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	24	21	finally
/*     */   }
/*     */   
/*     */   protected void notifyLineEvent(LineEvent.Type type)
/*     */   {
/* 347 */     notifyLineEvent(new LineEvent(this, type, -1L));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void notifyLineEvent(LineEvent event)
/*     */   {
/* 356 */     TNotifier.notifier.addEntry(event, getLineListeners());
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TLine.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */