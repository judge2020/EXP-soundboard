/*     */ package org.tritonus.share.sampled.mixer;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import javax.sound.sampled.Mixer.Info;
/*     */ import javax.sound.sampled.spi.MixerProvider;
/*     */ import org.tritonus.share.TDebug;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TMixerProvider
/*     */   extends MixerProvider
/*     */ {
/*  49 */   private static final Mixer.Info[] EMPTY_MIXER_INFO_ARRAY = new Mixer.Info[0];
/*     */   
/*  51 */   private static Map<Class, MixerProviderStruct> sm_mixerProviderStructs = new HashMap();
/*     */   
/*  53 */   private boolean m_bDisabled = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TMixerProvider()
/*     */   {
/*  60 */     if (TDebug.TraceMixerProvider) { TDebug.out("TMixerProvider.<init>(): begin");
/*     */     }
/*  62 */     if (TDebug.TraceMixerProvider) { TDebug.out("TMixerProvider.<init>(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void staticInit() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private MixerProviderStruct getMixerProviderStruct()
/*     */   {
/*  78 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixerProviderStruct(): begin");
/*  79 */     Class cls = getClass();
/*  80 */     if (TDebug.TraceMixerProvider) { TDebug.out("TMixerProvider.getMixerProviderStruct(): called from " + cls);
/*     */     }
/*  82 */     synchronized (TMixerProvider.class)
/*     */     {
/*  84 */       MixerProviderStruct struct = (MixerProviderStruct)sm_mixerProviderStructs.get(cls);
/*  85 */       if (struct == null)
/*     */       {
/*  87 */         if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixerProviderStruct(): creating new MixerProviderStruct for " + cls);
/*  88 */         struct = new MixerProviderStruct();
/*  89 */         sm_mixerProviderStructs.put(cls, struct);
/*     */       }
/*  91 */       if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixerProviderStruct(): end");
/*  92 */       return struct;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void disable()
/*     */   {
/* 100 */     if (TDebug.TraceMixerProvider) TDebug.out("disabling " + getClass().getName());
/* 101 */     this.m_bDisabled = true;
/*     */   }
/*     */   
/*     */ 
/*     */   protected boolean isDisabled()
/*     */   {
/* 107 */     return this.m_bDisabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addMixer(Mixer mixer)
/*     */   {
/* 114 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.addMixer(): begin");
/* 115 */     MixerProviderStruct struct = getMixerProviderStruct();
/* 116 */     synchronized (struct)
/*     */     {
/* 118 */       struct.m_mixers.add(mixer);
/* 119 */       if (struct.m_defaultMixer == null)
/*     */       {
/* 121 */         struct.m_defaultMixer = mixer;
/*     */       }
/*     */     }
/* 124 */     if (TDebug.TraceMixerProvider) { TDebug.out("TMixerProvider.addMixer(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void removeMixer(Mixer mixer)
/*     */   {
/* 131 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.removeMixer(): begin");
/* 132 */     MixerProviderStruct struct = getMixerProviderStruct();
/* 133 */     synchronized (struct)
/*     */     {
/* 135 */       struct.m_mixers.remove(mixer);
/*     */       
/* 137 */       if (struct.m_defaultMixer == mixer)
/*     */       {
/* 139 */         struct.m_defaultMixer = null;
/*     */       }
/*     */     }
/* 142 */     if (TDebug.TraceMixerProvider) { TDebug.out("TMixerProvider.removeMixer(): end");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isMixerSupported(Mixer.Info info)
/*     */   {
/* 149 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.isMixerSupported(): begin");
/* 150 */     boolean bIsSupported = false;
/* 151 */     Mixer.Info[] infos = getMixerInfo();
/* 152 */     for (int i = 0; i < infos.length; i++)
/*     */     {
/* 154 */       if (infos[i].equals(info))
/*     */       {
/* 156 */         bIsSupported = true;
/* 157 */         break;
/*     */       }
/*     */     }
/* 160 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.isMixerSupported(): end");
/* 161 */     return bIsSupported;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Mixer getMixer(Mixer.Info info)
/*     */   {
/* 170 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixer(): begin");
/* 171 */     MixerProviderStruct struct = getMixerProviderStruct();
/* 172 */     Mixer mixerResult = null;
/* 173 */     synchronized (struct)
/*     */     {
/* 175 */       if (info == null)
/*     */       {
/* 177 */         mixerResult = struct.m_defaultMixer;
/*     */       }
/*     */       else
/*     */       {
/* 181 */         Iterator mixers = struct.m_mixers.iterator();
/* 182 */         while (mixers.hasNext())
/*     */         {
/* 184 */           Mixer mixer = (Mixer)mixers.next();
/* 185 */           if (mixer.getMixerInfo().equals(info))
/*     */           {
/* 187 */             mixerResult = mixer;
/* 188 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 193 */     if (mixerResult == null)
/*     */     {
/* 195 */       throw new IllegalArgumentException("no mixer available for " + info);
/*     */     }
/* 197 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixer(): end");
/* 198 */     return mixerResult;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Mixer.Info[] getMixerInfo()
/*     */   {
/* 205 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixerInfo(): begin");
/* 206 */     Set<Mixer.Info> mixerInfos = new HashSet();
/* 207 */     MixerProviderStruct struct = getMixerProviderStruct();
/* 208 */     synchronized (struct)
/*     */     {
/* 210 */       Iterator<Mixer> mixers = struct.m_mixers.iterator();
/* 211 */       while (mixers.hasNext())
/*     */       {
/* 213 */         Mixer mixer = (Mixer)mixers.next();
/* 214 */         mixerInfos.add(mixer.getMixerInfo());
/*     */       }
/*     */     }
/* 217 */     if (TDebug.TraceMixerProvider) TDebug.out("TMixerProvider.getMixerInfo(): end");
/* 218 */     return (Mixer.Info[])mixerInfos.toArray(EMPTY_MIXER_INFO_ARRAY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class MixerProviderStruct
/*     */   {
/*     */     public List<Mixer> m_mixers;
/*     */     
/*     */     public Mixer m_defaultMixer;
/*     */     
/*     */ 
/*     */     public MixerProviderStruct()
/*     */     {
/* 232 */       this.m_mixers = new ArrayList();
/* 233 */       this.m_defaultMixer = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TMixerProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */