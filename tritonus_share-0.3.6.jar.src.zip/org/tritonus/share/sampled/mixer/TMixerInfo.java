/*    */ package org.tritonus.share.sampled.mixer;
/*    */ 
/*    */ import javax.sound.sampled.Mixer.Info;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TMixerInfo
/*    */   extends Mixer.Info
/*    */ {
/*    */   public TMixerInfo(String a, String b, String c, String d)
/*    */   {
/* 49 */     super(a, b, c, d);
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\mixer\TMixerInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */