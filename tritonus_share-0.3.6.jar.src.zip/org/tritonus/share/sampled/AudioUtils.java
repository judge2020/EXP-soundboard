/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AudioUtils
/*     */ {
/*     */   public static long getLengthInBytes(AudioInputStream audioInputStream)
/*     */   {
/*  55 */     return getLengthInBytes(audioInputStream.getFormat(), audioInputStream.getFrameLength());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long getLengthInBytes(AudioFormat audioFormat, long lLengthInFrames)
/*     */   {
/*  82 */     int nFrameSize = audioFormat.getFrameSize();
/*  83 */     if ((lLengthInFrames >= 0L) && (nFrameSize >= 1))
/*     */     {
/*  85 */       return lLengthInFrames * nFrameSize;
/*     */     }
/*     */     
/*     */ 
/*  89 */     return -1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean containsFormat(AudioFormat sourceFormat, Iterator possibleFormats)
/*     */   {
/*  98 */     while (possibleFormats.hasNext())
/*     */     {
/* 100 */       AudioFormat format = (AudioFormat)possibleFormats.next();
/* 101 */       if (AudioFormats.matches(format, sourceFormat))
/*     */       {
/* 103 */         return true;
/*     */       }
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static long millis2Bytes(long ms, AudioFormat format)
/*     */   {
/* 114 */     return millis2Bytes(ms, format.getFrameRate(), format.getFrameSize());
/*     */   }
/*     */   
/*     */   public static long millis2Bytes(long ms, float frameRate, int frameSize) {
/* 118 */     return ((float)ms * frameRate / 1000.0F * frameSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static long millis2BytesFrameAligned(long ms, AudioFormat format)
/*     */   {
/* 125 */     return millis2BytesFrameAligned(ms, format.getFrameRate(), format.getFrameSize());
/*     */   }
/*     */   
/*     */   public static long millis2BytesFrameAligned(long ms, float frameRate, int frameSize) {
/* 129 */     return ((float)ms * frameRate / 1000.0F) * frameSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static long millis2Frames(long ms, AudioFormat format)
/*     */   {
/* 136 */     return millis2Frames(ms, format.getFrameRate());
/*     */   }
/*     */   
/*     */   public static long millis2Frames(long ms, float frameRate) {
/* 140 */     return ((float)ms * frameRate / 1000.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static long bytes2Millis(long bytes, AudioFormat format)
/*     */   {
/* 147 */     return ((float)bytes / format.getFrameRate() * 1000.0F / format.getFrameSize());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static long frames2Millis(long frames, AudioFormat format)
/*     */   {
/* 154 */     return ((float)frames / format.getFrameRate() * 1000.0F);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String NS_or_number(int number)
/*     */   {
/* 160 */     return number == -1 ? "NOT_SPECIFIED" : String.valueOf(number);
/*     */   }
/*     */   
/* 163 */   public static String NS_or_number(float number) { return number == -1.0F ? "NOT_SPECIFIED" : String.valueOf(number); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String format2ShortStr(AudioFormat format)
/*     */   {
/* 170 */     return format.getEncoding() + "-" + NS_or_number(format.getChannels()) + "ch-" + NS_or_number(format.getSampleSizeInBits()) + "bit-" + NS_or_number((int)format.getSampleRate()) + "Hz-" + (format.isBigEndian() ? "be" : "le");
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\AudioUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */