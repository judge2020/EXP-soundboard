/*     */ package org.tritonus.share.sampled;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.sound.sampled.AudioFormat.Encoding;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import org.tritonus.share.StringHashedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Encodings
/*     */   extends AudioFormat.Encoding
/*     */ {
/*  71 */   private static StringHashedSet encodings = new StringHashedSet();
/*     */   
/*     */   static
/*     */   {
/*  75 */     encodings.add(AudioFormat.Encoding.PCM_SIGNED);
/*  76 */     encodings.add(AudioFormat.Encoding.PCM_UNSIGNED);
/*  77 */     encodings.add(AudioFormat.Encoding.ULAW);
/*  78 */     encodings.add(AudioFormat.Encoding.ALAW);
/*     */   }
/*     */   
/*     */   Encodings(String name) {
/*  82 */     super(name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AudioFormat.Encoding getEncoding(String name)
/*     */   {
/* 114 */     AudioFormat.Encoding res = (AudioFormat.Encoding)encodings.get(name);
/* 115 */     if (res == null)
/*     */     {
/* 117 */       res = new Encodings(name);
/*     */       
/* 119 */       encodings.add(res);
/*     */     }
/* 121 */     return res;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean equals(AudioFormat.Encoding e1, AudioFormat.Encoding e2)
/*     */   {
/* 134 */     return e2.toString().equals(e1.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AudioFormat.Encoding[] getEncodings()
/*     */   {
/* 152 */     StringHashedSet iteratedSources = new StringHashedSet();
/* 153 */     StringHashedSet retrievedTargets = new StringHashedSet();
/* 154 */     Iterator sourceFormats = encodings.iterator();
/* 155 */     while (sourceFormats.hasNext()) {
/* 156 */       AudioFormat.Encoding source = (AudioFormat.Encoding)sourceFormats.next();
/* 157 */       iterateEncodings(source, iteratedSources, retrievedTargets);
/*     */     }
/* 159 */     return (AudioFormat.Encoding[])retrievedTargets.toArray(new AudioFormat.Encoding[retrievedTargets.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void iterateEncodings(AudioFormat.Encoding source, StringHashedSet iteratedSources, StringHashedSet retrievedTargets)
/*     */   {
/* 167 */     if (!iteratedSources.contains(source)) {
/* 168 */       iteratedSources.add(source);
/* 169 */       AudioFormat.Encoding[] targets = AudioSystem.getTargetEncodings(source);
/* 170 */       for (int i = 0; i < targets.length; i++) {
/* 171 */         AudioFormat.Encoding target = targets[i];
/* 172 */         if (retrievedTargets.add(target.toString())) {
/* 173 */           iterateEncodings(target, iteratedSources, retrievedTargets);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\tritonus_share-0.3.6.jar!\org\tritonus\share\sampled\Encodings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */