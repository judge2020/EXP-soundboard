package com.google.common.xml;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
abstract interface package-info {}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\guava-18.0.jar!\com\google\common\xml\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */