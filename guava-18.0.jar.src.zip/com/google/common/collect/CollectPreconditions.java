/*    */ package com.google.common.collect;
/*    */ 
/*    */ import com.google.common.annotations.GwtCompatible;
/*    */ import com.google.common.base.Preconditions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @GwtCompatible
/*    */ final class CollectPreconditions
/*    */ {
/*    */   static void checkEntryNotNull(Object key, Object value)
/*    */   {
/*    */     String str;
/* 30 */     if (key == null) {
/* 31 */       str = String.valueOf(String.valueOf(value));throw new NullPointerException(24 + str.length() + "null key in entry: null=" + str); }
/* 32 */     if (value == null) {
/* 33 */       str = String.valueOf(String.valueOf(key));throw new NullPointerException(26 + str.length() + "null value in entry: " + str + "=null");
/*    */     }
/*    */   }
/*    */   
/*    */   static int checkNonnegative(int value, String name) {
/* 38 */     if (value < 0) {
/* 39 */       String str = String.valueOf(String.valueOf(name));int i = value;throw new IllegalArgumentException(40 + str.length() + str + " cannot be negative but was: " + i);
/*    */     }
/* 41 */     return value;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static void checkRemove(boolean canRemove)
/*    */   {
/* 49 */     Preconditions.checkState(canRemove, "no calls to next() since the last call to remove()");
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\guava-18.0.jar!\com\google\common\collect\CollectPreconditions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */