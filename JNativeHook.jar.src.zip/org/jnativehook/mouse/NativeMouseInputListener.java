package org.jnativehook.mouse;

public abstract interface NativeMouseInputListener
  extends NativeMouseListener, NativeMouseMotionListener
{}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\JNativeHook.jar!\org\jnativehook\mouse\NativeMouseInputListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */