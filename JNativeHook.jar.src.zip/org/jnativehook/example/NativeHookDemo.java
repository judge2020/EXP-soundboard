package org.jnativehook.example;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.ItemSelectable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.accessibility.AccessibleContext;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.NativeInputEvent;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;
import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.mouse.NativeMouseInputListener;
import org.jnativehook.mouse.NativeMouseWheelEvent;
import org.jnativehook.mouse.NativeMouseWheelListener;

public class NativeHookDemo
  extends JFrame
  implements ActionListener, ItemListener, NativeKeyListener, NativeMouseInputListener, NativeMouseWheelListener, WindowListener
{
  private static final long serialVersionUID = 1865350670081087993L;
  private JMenu menuSubListeners;
  private JMenuItem menuItemQuit;
  private JMenuItem menuItemClear;
  private JCheckBoxMenuItem menuItemEnable;
  private JCheckBoxMenuItem menuItemKeyboardEvents;
  private JCheckBoxMenuItem menuItemButtonEvents;
  private JCheckBoxMenuItem menuItemMotionEvents;
  private JCheckBoxMenuItem menuItemWheelEvents;
  private JTextArea txtEventInfo;
  
  public NativeHookDemo()
  {
    setTitle("JNativeHook Demo");
    setLayout(new BorderLayout());
    setDefaultCloseOperation(2);
    setSize(600, 300);
    addWindowListener(this);
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu1 = new JMenu("File");
    localJMenu1.setMnemonic(70);
    localJMenuBar.add(localJMenu1);
    this.menuItemQuit = new JMenuItem("Quit", 81);
    this.menuItemQuit.addActionListener(this);
    this.menuItemQuit.setAccelerator(KeyStroke.getKeyStroke(115, 8));
    this.menuItemQuit.getAccessibleContext().setAccessibleDescription("Exit the program");
    localJMenu1.add(this.menuItemQuit);
    JMenu localJMenu2 = new JMenu("View");
    localJMenu2.setMnemonic(86);
    localJMenuBar.add(localJMenu2);
    this.menuItemClear = new JMenuItem("Clear", 67);
    this.menuItemClear.addActionListener(this);
    this.menuItemClear.setAccelerator(KeyStroke.getKeyStroke(67, 3));
    this.menuItemClear.getAccessibleContext().setAccessibleDescription("Clear the screen");
    localJMenu2.add(this.menuItemClear);
    localJMenu2.addSeparator();
    this.menuItemEnable = new JCheckBoxMenuItem("Enable Native Hook");
    this.menuItemEnable.addItemListener(this);
    this.menuItemEnable.setMnemonic(72);
    this.menuItemEnable.setAccelerator(KeyStroke.getKeyStroke(72, 3));
    localJMenu2.add(this.menuItemEnable);
    this.menuSubListeners = new JMenu("Listeners");
    this.menuSubListeners.setMnemonic(76);
    localJMenu2.add(this.menuSubListeners);
    this.menuItemKeyboardEvents = new JCheckBoxMenuItem("Keyboard Events");
    this.menuItemKeyboardEvents.addItemListener(this);
    this.menuItemKeyboardEvents.setMnemonic(75);
    this.menuItemKeyboardEvents.setAccelerator(KeyStroke.getKeyStroke(75, 3));
    this.menuSubListeners.add(this.menuItemKeyboardEvents);
    this.menuItemButtonEvents = new JCheckBoxMenuItem("Button Events");
    this.menuItemButtonEvents.addItemListener(this);
    this.menuItemButtonEvents.setMnemonic(66);
    this.menuItemButtonEvents.setAccelerator(KeyStroke.getKeyStroke(66, 3));
    this.menuSubListeners.add(this.menuItemButtonEvents);
    this.menuItemMotionEvents = new JCheckBoxMenuItem("Motion Events");
    this.menuItemMotionEvents.addItemListener(this);
    this.menuItemMotionEvents.setMnemonic(77);
    this.menuItemMotionEvents.setAccelerator(KeyStroke.getKeyStroke(77, 3));
    this.menuSubListeners.add(this.menuItemMotionEvents);
    this.menuItemWheelEvents = new JCheckBoxMenuItem("Wheel Events");
    this.menuItemWheelEvents.addItemListener(this);
    this.menuItemWheelEvents.setMnemonic(87);
    this.menuItemWheelEvents.setAccelerator(KeyStroke.getKeyStroke(87, 3));
    this.menuSubListeners.add(this.menuItemWheelEvents);
    setJMenuBar(localJMenuBar);
    this.txtEventInfo = new JTextArea();
    this.txtEventInfo.setEditable(false);
    this.txtEventInfo.setBackground(new Color(255, 255, 255));
    this.txtEventInfo.setForeground(new Color(0, 0, 0));
    this.txtEventInfo.setText("");
    JScrollPane localJScrollPane = new JScrollPane(this.txtEventInfo);
    localJScrollPane.setPreferredSize(new Dimension(375, 125));
    add(localJScrollPane, "Center");
    setVisible(true);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.menuItemQuit) {
      dispose();
    } else if (paramActionEvent.getSource() == this.menuItemClear) {
      this.txtEventInfo.setText("");
    }
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    ItemSelectable localItemSelectable = paramItemEvent.getItemSelectable();
    if (localItemSelectable == this.menuItemEnable)
    {
      if (paramItemEvent.getStateChange() == 1) {
        try
        {
          GlobalScreen.registerNativeHook();
        }
        catch (NativeHookException localNativeHookException)
        {
          this.txtEventInfo.append("\nError: " + localNativeHookException.toString());
        }
      } else {
        GlobalScreen.unregisterNativeHook();
      }
      this.menuSubListeners.setEnabled(GlobalScreen.isNativeHookRegistered());
    }
    else if (localItemSelectable == this.menuItemKeyboardEvents)
    {
      if (paramItemEvent.getStateChange() == 1) {
        GlobalScreen.getInstance().addNativeKeyListener(this);
      } else {
        GlobalScreen.getInstance().removeNativeKeyListener(this);
      }
    }
    else if (localItemSelectable == this.menuItemButtonEvents)
    {
      if (paramItemEvent.getStateChange() == 1) {
        GlobalScreen.getInstance().addNativeMouseListener(this);
      } else {
        GlobalScreen.getInstance().removeNativeMouseListener(this);
      }
    }
    else if (localItemSelectable == this.menuItemMotionEvents)
    {
      if (paramItemEvent.getStateChange() == 1) {
        GlobalScreen.getInstance().addNativeMouseMotionListener(this);
      } else {
        GlobalScreen.getInstance().removeNativeMouseMotionListener(this);
      }
    }
    else if (localItemSelectable == this.menuItemWheelEvents)
    {
      if (paramItemEvent.getStateChange() == 1) {
        GlobalScreen.getInstance().addNativeMouseWheelListener(this);
      } else {
        GlobalScreen.getInstance().removeNativeMouseWheelListener(this);
      }
    }
  }
  
  public void nativeKeyPressed(NativeKeyEvent paramNativeKeyEvent)
  {
    displayEventInfo(paramNativeKeyEvent);
  }
  
  public void nativeKeyReleased(NativeKeyEvent paramNativeKeyEvent)
  {
    displayEventInfo(paramNativeKeyEvent);
  }
  
  public void nativeKeyTyped(NativeKeyEvent paramNativeKeyEvent)
  {
    displayEventInfo(paramNativeKeyEvent);
  }
  
  public void nativeMouseClicked(NativeMouseEvent paramNativeMouseEvent)
  {
    displayEventInfo(paramNativeMouseEvent);
  }
  
  public void nativeMousePressed(NativeMouseEvent paramNativeMouseEvent)
  {
    displayEventInfo(paramNativeMouseEvent);
  }
  
  public void nativeMouseReleased(NativeMouseEvent paramNativeMouseEvent)
  {
    displayEventInfo(paramNativeMouseEvent);
  }
  
  public void nativeMouseMoved(NativeMouseEvent paramNativeMouseEvent)
  {
    displayEventInfo(paramNativeMouseEvent);
  }
  
  public void nativeMouseDragged(NativeMouseEvent paramNativeMouseEvent)
  {
    displayEventInfo(paramNativeMouseEvent);
  }
  
  public void nativeMouseWheelMoved(NativeMouseWheelEvent paramNativeMouseWheelEvent)
  {
    displayEventInfo(paramNativeMouseWheelEvent);
  }
  
  private void displayEventInfo(final NativeInputEvent paramNativeInputEvent)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        NativeHookDemo.this.txtEventInfo.append("\n" + paramNativeInputEvent.paramString());
        try
        {
          if (NativeHookDemo.this.txtEventInfo.getLineCount() > 100) {
            NativeHookDemo.this.txtEventInfo.replaceRange("", 0, NativeHookDemo.this.txtEventInfo.getLineEndOffset(NativeHookDemo.this.txtEventInfo.getLineCount() - 1 - 100));
          }
          NativeHookDemo.this.txtEventInfo.setCaretPosition(NativeHookDemo.this.txtEventInfo.getLineStartOffset(NativeHookDemo.this.txtEventInfo.getLineCount() - 1));
        }
        catch (BadLocationException localBadLocationException)
        {
          NativeHookDemo.this.txtEventInfo.setCaretPosition(NativeHookDemo.this.txtEventInfo.getDocument().getLength());
        }
      }
    });
  }
  
  public void windowActivated(WindowEvent paramWindowEvent) {}
  
  public void windowClosing(WindowEvent paramWindowEvent) {}
  
  public void windowDeactivated(WindowEvent paramWindowEvent) {}
  
  public void windowDeiconified(WindowEvent paramWindowEvent) {}
  
  public void windowIconified(WindowEvent paramWindowEvent) {}
  
  public void windowOpened(WindowEvent paramWindowEvent)
  {
    requestFocusInWindow();
    this.menuItemEnable.setSelected(true);
    this.txtEventInfo.setText("Auto Repeat Rate: " + System.getProperty("jnativehook.autoRepeatRate"));
    this.txtEventInfo.append("\nAuto Repeat Delay: " + System.getProperty("jnativehook.autoRepeatDelay"));
    this.txtEventInfo.append("\nDouble Click Time: " + System.getProperty("jnativehook.multiClickInterval"));
    this.txtEventInfo.append("\nPointer Sensitivity: " + System.getProperty("jnativehook.pointerSensitivity"));
    this.txtEventInfo.append("\nPointer Acceleration Multiplier: " + System.getProperty("jnativehook.pointerAccelerationMultiplier"));
    this.txtEventInfo.append("\nPointer Acceleration Threshold: " + System.getProperty("jnativehook.pointerAccelerationThreshold"));
    try
    {
      this.txtEventInfo.setCaretPosition(this.txtEventInfo.getLineStartOffset(this.txtEventInfo.getLineCount() - 1));
    }
    catch (BadLocationException localBadLocationException)
    {
      this.txtEventInfo.setCaretPosition(this.txtEventInfo.getDocument().getLength());
    }
    this.menuItemKeyboardEvents.setSelected(true);
    this.menuItemButtonEvents.setSelected(true);
    this.menuItemMotionEvents.setSelected(true);
    this.menuItemWheelEvents.setSelected(true);
  }
  
  public void windowClosed(WindowEvent paramWindowEvent)
  {
    GlobalScreen.unregisterNativeHook();
    System.runFinalization();
    System.exit(0);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    SwingUtilities.invokeLater(new Runnable()
    {
      public void run()
      {
        new NativeHookDemo();
      }
    });
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\JNativeHook.jar!\org\jnativehook\example\NativeHookDemo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */