package org.jnativehook.keyboard;

import java.util.EventListener;

public abstract interface NativeKeyListener
  extends EventListener
{
  public abstract void nativeKeyPressed(NativeKeyEvent paramNativeKeyEvent);
  
  public abstract void nativeKeyReleased(NativeKeyEvent paramNativeKeyEvent);
  
  public abstract void nativeKeyTyped(NativeKeyEvent paramNativeKeyEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\JNativeHook.jar!\org\jnativehook\keyboard\NativeKeyListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */