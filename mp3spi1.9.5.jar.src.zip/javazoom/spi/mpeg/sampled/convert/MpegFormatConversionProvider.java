package javazoom.spi.mpeg.sampled.convert;

import java.util.Arrays;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioInputStream;
import javazoom.spi.mpeg.sampled.file.MpegEncoding;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.Encodings;
import org.tritonus.share.sampled.convert.TEncodingFormatConversionProvider;

public class MpegFormatConversionProvider
  extends TEncodingFormatConversionProvider
{
  private static final AudioFormat.Encoding MP3 = Encodings.getEncoding("MP3");
  private static final AudioFormat.Encoding PCM_SIGNED = Encodings.getEncoding("PCM_SIGNED");
  private static final AudioFormat[] INPUT_FORMATS = { new AudioFormat(MP3, -1.0F, -1, 1, -1, -1.0F, false), new AudioFormat(MP3, -1.0F, -1, 1, -1, -1.0F, true), new AudioFormat(MP3, -1.0F, -1, 2, -1, -1.0F, false), new AudioFormat(MP3, -1.0F, -1, 2, -1, -1.0F, true) };
  private static final AudioFormat[] OUTPUT_FORMATS = { new AudioFormat(PCM_SIGNED, -1.0F, 16, 1, 2, -1.0F, false), new AudioFormat(PCM_SIGNED, -1.0F, 16, 1, 2, -1.0F, true), new AudioFormat(PCM_SIGNED, -1.0F, 16, 2, 4, -1.0F, false), new AudioFormat(PCM_SIGNED, -1.0F, 16, 2, 4, -1.0F, true) };
  
  public MpegFormatConversionProvider()
  {
    super(Arrays.asList(INPUT_FORMATS), Arrays.asList(OUTPUT_FORMATS));
    if (TDebug.TraceAudioConverter) {
      TDebug.out(">MpegFormatConversionProvider()");
    }
  }
  
  public AudioInputStream getAudioInputStream(AudioFormat paramAudioFormat, AudioInputStream paramAudioInputStream)
  {
    if (TDebug.TraceAudioConverter) {
      TDebug.out(">MpegFormatConversionProvider.getAudioInputStream(AudioFormat targetFormat, AudioInputStream audioInputStream):");
    }
    return new DecodedMpegAudioInputStream(paramAudioFormat, paramAudioInputStream);
  }
  
  public boolean isConversionSupported(AudioFormat paramAudioFormat1, AudioFormat paramAudioFormat2)
  {
    if (TDebug.TraceAudioConverter)
    {
      TDebug.out(">MpegFormatConversionProvider.isConversionSupported(AudioFormat targetFormat, AudioFormat sourceFormat):");
      TDebug.out("checking if conversion possible");
      TDebug.out("from: " + paramAudioFormat2);
      TDebug.out("to: " + paramAudioFormat1);
    }
    boolean bool = super.isConversionSupported(paramAudioFormat1, paramAudioFormat2);
    if (!bool)
    {
      AudioFormat.Encoding localEncoding = paramAudioFormat2.getEncoding();
      if (((localEncoding instanceof MpegEncoding)) && ((paramAudioFormat2.getFrameRate() != -1.0F) || (paramAudioFormat2.getFrameSize() != -1))) {
        bool = true;
      }
    }
    return bool;
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\convert\MpegFormatConversionProvider.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */