package javazoom.spi.mpeg.sampled.convert;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.BitstreamException;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.DecoderException;
import javazoom.jl.decoder.Equalizer;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.Obuffer;
import javazoom.spi.PropertiesContainer;
import javazoom.spi.mpeg.sampled.file.IcyListener;
import javazoom.spi.mpeg.sampled.file.tag.TagParseEvent;
import javazoom.spi.mpeg.sampled.file.tag.TagParseListener;
import org.tritonus.share.TCircularBuffer;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.convert.TAsynchronousFilteredAudioInputStream;

public class DecodedMpegAudioInputStream
  extends TAsynchronousFilteredAudioInputStream
  implements PropertiesContainer, TagParseListener
{
  private InputStream m_encodedStream;
  private Bitstream m_bitstream;
  private Decoder m_decoder;
  private Equalizer m_equalizer;
  private float[] m_equalizer_values;
  private Header m_header;
  private DMAISObuffer m_oBuffer;
  private long byteslength = -1L;
  private long currentByte = 0L;
  private int frameslength = -1;
  private long currentFrame = 0L;
  private int currentFramesize = 0;
  private int currentBitrate = -1;
  private long currentMicrosecond = 0L;
  private IcyListener shoutlst = null;
  private HashMap properties = null;
  
  public DecodedMpegAudioInputStream(AudioFormat paramAudioFormat, AudioInputStream paramAudioInputStream)
  {
    super(paramAudioFormat, -1L);
    if (TDebug.TraceAudioConverter) {
      TDebug.out(">DecodedMpegAudioInputStream(AudioFormat outputFormat, AudioInputStream inputStream)");
    }
    try
    {
      this.byteslength = paramAudioInputStream.available();
    }
    catch (IOException localIOException)
    {
      TDebug.out("DecodedMpegAudioInputStream : Cannot run inputStream.available() : " + localIOException.getMessage());
      this.byteslength = -1L;
    }
    this.m_encodedStream = paramAudioInputStream;
    this.shoutlst = IcyListener.getInstance();
    this.shoutlst.reset();
    this.m_bitstream = new Bitstream(paramAudioInputStream);
    this.m_decoder = new Decoder(null);
    this.m_equalizer = new Equalizer();
    this.m_equalizer_values = new float[32];
    for (int i = 0; i < this.m_equalizer.getBandCount(); i++) {
      this.m_equalizer_values[i] = this.m_equalizer.getBand(i);
    }
    this.m_decoder.setEqualizer(this.m_equalizer);
    this.m_oBuffer = new DMAISObuffer(paramAudioFormat.getChannels());
    this.m_decoder.setOutputBuffer(this.m_oBuffer);
    try
    {
      this.m_header = this.m_bitstream.readFrame();
      if ((this.m_header != null) && (this.frameslength == -1) && (this.byteslength > 0L)) {
        this.frameslength = this.m_header.max_number_of_frames((int)this.byteslength);
      }
    }
    catch (BitstreamException localBitstreamException)
    {
      TDebug.out("DecodedMpegAudioInputStream : Cannot read first frame : " + localBitstreamException.getMessage());
      this.byteslength = -1L;
    }
    this.properties = new HashMap();
  }
  
  public Map properties()
  {
    this.properties.put("mp3.frame", new Long(this.currentFrame));
    this.properties.put("mp3.frame.bitrate", new Integer(this.currentBitrate));
    this.properties.put("mp3.frame.size.bytes", new Integer(this.currentFramesize));
    this.properties.put("mp3.position.byte", new Long(this.currentByte));
    this.properties.put("mp3.position.microseconds", new Long(this.currentMicrosecond));
    this.properties.put("mp3.equalizer", this.m_equalizer_values);
    if (this.shoutlst != null)
    {
      String str1 = this.shoutlst.getStreamUrl();
      String str2 = this.shoutlst.getStreamTitle();
      if ((str2 != null) && (str2.trim().length() > 0)) {
        this.properties.put("mp3.shoutcast.metadata.StreamTitle", str2);
      }
      if ((str1 != null) && (str1.trim().length() > 0)) {
        this.properties.put("mp3.shoutcast.metadata.StreamUrl", str1);
      }
    }
    return this.properties;
  }
  
  public void execute()
  {
    if (TDebug.TraceAudioConverter) {
      TDebug.out("execute() : begin");
    }
    try
    {
      Header localHeader = null;
      if (this.m_header == null) {
        localHeader = this.m_bitstream.readFrame();
      } else {
        localHeader = this.m_header;
      }
      if (TDebug.TraceAudioConverter) {
        TDebug.out("execute() : header = " + localHeader);
      }
      if (localHeader == null)
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out("header is null (end of mpeg stream)");
        }
        getCircularBuffer().close();
        return;
      }
      this.currentFrame += 1L;
      this.currentBitrate = localHeader.bitrate_instant();
      this.currentFramesize = localHeader.calculate_framesize();
      this.currentByte += this.currentFramesize;
      this.currentMicrosecond = (((float)this.currentFrame * localHeader.ms_per_frame() * 1000.0F));
      for (int i = 0; i < this.m_equalizer_values.length; i++) {
        this.m_equalizer.setBand(i, this.m_equalizer_values[i]);
      }
      this.m_decoder.setEqualizer(this.m_equalizer);
      Obuffer localObuffer = this.m_decoder.decodeFrame(localHeader, this.m_bitstream);
      this.m_bitstream.closeFrame();
      getCircularBuffer().write(this.m_oBuffer.getBuffer(), 0, this.m_oBuffer.getCurrentBufferSize());
      this.m_oBuffer.reset();
      if (this.m_header != null) {
        this.m_header = null;
      }
    }
    catch (BitstreamException localBitstreamException)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out(localBitstreamException);
      }
    }
    catch (DecoderException localDecoderException)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out(localDecoderException);
      }
    }
    if (TDebug.TraceAudioConverter) {
      TDebug.out("execute() : end");
    }
  }
  
  public long skip(long paramLong)
  {
    if ((this.byteslength > 0L) && (this.frameslength > 0))
    {
      float f = (float)paramLong * 1.0F / (float)this.byteslength * 1.0F;
      long l = skipFrames((f * this.frameslength));
      this.currentByte += l;
      this.m_header = null;
      return l;
    }
    return -1L;
  }
  
  public long skipFrames(long paramLong)
  {
    if (TDebug.TraceAudioConverter) {
      TDebug.out("skip(long frames) : begin");
    }
    int i = 0;
    int j = 0;
    try
    {
      for (int k = 0; k < paramLong; k++)
      {
        Header localHeader = this.m_bitstream.readFrame();
        if (localHeader != null)
        {
          int m = localHeader.calculate_framesize();
          j += m;
        }
        this.m_bitstream.closeFrame();
        i++;
      }
    }
    catch (BitstreamException localBitstreamException)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out(localBitstreamException);
      }
    }
    if (TDebug.TraceAudioConverter) {
      TDebug.out("skip(long frames) : end");
    }
    this.currentFrame += i;
    return j;
  }
  
  private boolean isBigEndian()
  {
    return getFormat().isBigEndian();
  }
  
  public void close()
    throws IOException
  {
    super.close();
    this.m_encodedStream.close();
  }
  
  public void tagParsed(TagParseEvent paramTagParseEvent)
  {
    System.out.println("TAG:" + paramTagParseEvent.getTag());
  }
  
  private class DMAISObuffer
    extends Obuffer
  {
    private int m_nChannels;
    private byte[] m_abBuffer;
    private int[] m_anBufferPointers;
    private boolean m_bIsBigEndian;
    
    public DMAISObuffer(int paramInt)
    {
      this.m_nChannels = paramInt;
      this.m_abBuffer = new byte[2304 * paramInt];
      this.m_anBufferPointers = new int[paramInt];
      reset();
      this.m_bIsBigEndian = DecodedMpegAudioInputStream.this.isBigEndian();
    }
    
    public void append(int paramInt, short paramShort)
    {
      int i;
      int j;
      if (this.m_bIsBigEndian)
      {
        i = (byte)(paramShort >>> 8 & 0xFF);
        j = (byte)(paramShort & 0xFF);
      }
      else
      {
        i = (byte)(paramShort & 0xFF);
        j = (byte)(paramShort >>> 8 & 0xFF);
      }
      this.m_abBuffer[this.m_anBufferPointers[paramInt]] = i;
      this.m_abBuffer[(this.m_anBufferPointers[paramInt] + 1)] = j;
      this.m_anBufferPointers[paramInt] += this.m_nChannels * 2;
    }
    
    public void set_stop_flag() {}
    
    public void close() {}
    
    public void write_buffer(int paramInt) {}
    
    public void clear_buffer() {}
    
    public byte[] getBuffer()
    {
      return this.m_abBuffer;
    }
    
    public int getCurrentBufferSize()
    {
      return this.m_anBufferPointers[0];
    }
    
    public void reset()
    {
      for (int i = 0; i < this.m_nChannels; i++) {
        this.m_anBufferPointers[i] = (i * 2);
      }
    }
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\convert\DecodedMpegAudioInputStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */