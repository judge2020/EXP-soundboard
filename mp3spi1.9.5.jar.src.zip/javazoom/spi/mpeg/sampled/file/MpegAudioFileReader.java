package javazoom.spi.mpeg.sampled.file;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.security.AccessControlException;
import java.util.HashMap;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.UnsupportedAudioFileException;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Header;
import javazoom.spi.mpeg.sampled.file.tag.IcyInputStream;
import javazoom.spi.mpeg.sampled.file.tag.MP3Tag;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.file.TAudioFileReader;

public class MpegAudioFileReader
  extends TAudioFileReader
{
  public static final String VERSION = "MP3SPI 1.9.5";
  private final int SYNC = -2097152;
  private String weak = null;
  private final AudioFormat.Encoding[][] sm_aEncodings = { { MpegEncoding.MPEG2L1, MpegEncoding.MPEG2L2, MpegEncoding.MPEG2L3 }, { MpegEncoding.MPEG1L1, MpegEncoding.MPEG1L2, MpegEncoding.MPEG1L3 }, { MpegEncoding.MPEG2DOT5L1, MpegEncoding.MPEG2DOT5L2, MpegEncoding.MPEG2DOT5L3 } };
  public static int INITAL_READ_LENGTH = 4096000;
  private static int MARK_LIMIT = INITAL_READ_LENGTH + 1;
  private static final String[] id3v1genres = { "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Brass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A Capela", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", "Terror", "Indie", "BritPop", "Negerpunk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover", "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "JPop", "SynthPop" };
  
  public MpegAudioFileReader()
  {
    super(MARK_LIMIT, true);
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MP3SPI 1.9.5");
    }
    try
    {
      this.weak = System.getProperty("mp3spi.weak");
    }
    catch (AccessControlException localAccessControlException) {}
  }
  
  public AudioFileFormat getAudioFileFormat(File paramFile)
    throws UnsupportedAudioFileException, IOException
  {
    return super.getAudioFileFormat(paramFile);
  }
  
  public AudioFileFormat getAudioFileFormat(URL paramURL)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MpegAudioFileReader.getAudioFileFormat(URL): begin");
    }
    long l = -1L;
    URLConnection localURLConnection = paramURL.openConnection();
    localURLConnection.setRequestProperty("Icy-Metadata", "1");
    InputStream localInputStream = localURLConnection.getInputStream();
    AudioFileFormat localAudioFileFormat = null;
    try
    {
      localAudioFileFormat = getAudioFileFormat(localInputStream, l);
    }
    finally
    {
      localInputStream.close();
    }
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MpegAudioFileReader.getAudioFileFormat(URL): end");
    }
    return localAudioFileFormat;
  }
  
  public AudioFileFormat getAudioFileFormat(InputStream paramInputStream, long paramLong)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out(">MpegAudioFileReader.getAudioFileFormat(InputStream inputStream, long mediaLength): begin");
    }
    HashMap localHashMap1 = new HashMap();
    HashMap localHashMap2 = new HashMap();
    int i = (int)paramLong;
    int j = paramInputStream.available();
    PushbackInputStream localPushbackInputStream = new PushbackInputStream(paramInputStream, MARK_LIMIT);
    byte[] arrayOfByte1 = new byte[22];
    localPushbackInputStream.read(arrayOfByte1);
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("InputStream : " + paramInputStream + " =>" + new String(arrayOfByte1));
    }
    if ((arrayOfByte1[0] == 82) && (arrayOfByte1[1] == 73) && (arrayOfByte1[2] == 70) && (arrayOfByte1[3] == 70) && (arrayOfByte1[8] == 87) && (arrayOfByte1[9] == 65) && (arrayOfByte1[10] == 86) && (arrayOfByte1[11] == 69))
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("RIFF/WAV stream found");
      }
      k = arrayOfByte1[21] << 8 & 0xFF00 | arrayOfByte1[20] & 0xFF;
      if ((this.weak == null) && (k == 1)) {
        throw new UnsupportedAudioFileException("WAV PCM stream found");
      }
    }
    else if ((arrayOfByte1[0] == 46) && (arrayOfByte1[1] == 115) && (arrayOfByte1[2] == 110) && (arrayOfByte1[3] == 100))
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("AU stream found");
      }
      if (this.weak == null) {
        throw new UnsupportedAudioFileException("AU stream found");
      }
    }
    else if ((arrayOfByte1[0] == 70) && (arrayOfByte1[1] == 79) && (arrayOfByte1[2] == 82) && (arrayOfByte1[3] == 77) && (arrayOfByte1[8] == 65) && (arrayOfByte1[9] == 73) && (arrayOfByte1[10] == 70) && (arrayOfByte1[11] == 70))
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("AIFF stream found");
      }
      if (this.weak == null) {
        throw new UnsupportedAudioFileException("AIFF stream found");
      }
    }
    else
    {
      if (((arrayOfByte1[0] == 77 ? 1 : 0) | (arrayOfByte1[0] == 109 ? 1 : 0)) != 0) {
        if (((arrayOfByte1[1] == 65 ? 1 : 0) | (arrayOfByte1[1] == 97 ? 1 : 0)) != 0) {
          if (((arrayOfByte1[2] == 67 ? 1 : 0) | (arrayOfByte1[2] == 99 ? 1 : 0)) != 0)
          {
            if (TDebug.TraceAudioFileReader) {
              TDebug.out("APE stream found");
            }
            if (this.weak != null) {
              break label937;
            }
            throw new UnsupportedAudioFileException("APE stream found");
          }
        }
      }
      if (((arrayOfByte1[0] == 70 ? 1 : 0) | (arrayOfByte1[0] == 102 ? 1 : 0)) != 0) {
        if (((arrayOfByte1[1] == 76 ? 1 : 0) | (arrayOfByte1[1] == 108 ? 1 : 0)) != 0) {
          if (((arrayOfByte1[2] == 65 ? 1 : 0) | (arrayOfByte1[2] == 97 ? 1 : 0)) != 0) {
            if (((arrayOfByte1[3] == 67 ? 1 : 0) | (arrayOfByte1[3] == 99 ? 1 : 0)) != 0)
            {
              if (TDebug.TraceAudioFileReader) {
                TDebug.out("FLAC stream found");
              }
              if (this.weak != null) {
                break label937;
              }
              throw new UnsupportedAudioFileException("FLAC stream found");
            }
          }
        }
      }
      if (((arrayOfByte1[0] == 73 ? 1 : 0) | (arrayOfByte1[0] == 105 ? 1 : 0)) != 0) {
        if (((arrayOfByte1[1] == 67 ? 1 : 0) | (arrayOfByte1[1] == 99 ? 1 : 0)) != 0) {
          if (((arrayOfByte1[2] == 89 ? 1 : 0) | (arrayOfByte1[2] == 121 ? 1 : 0)) != 0)
          {
            localPushbackInputStream.unread(arrayOfByte1);
            loadShoutcastInfo(localPushbackInputStream, localHashMap1);
            break label937;
          }
        }
      }
      if (((arrayOfByte1[0] == 79 ? 1 : 0) | (arrayOfByte1[0] == 111 ? 1 : 0)) != 0) {
        if (((arrayOfByte1[1] == 71 ? 1 : 0) | (arrayOfByte1[1] == 103 ? 1 : 0)) != 0) {
          if (((arrayOfByte1[2] == 71 ? 1 : 0) | (arrayOfByte1[2] == 103 ? 1 : 0)) != 0)
          {
            if (TDebug.TraceAudioFileReader) {
              TDebug.out("Ogg stream found");
            }
            if (this.weak != null) {
              break label937;
            }
            throw new UnsupportedAudioFileException("Ogg stream found");
          }
        }
      }
      localPushbackInputStream.unread(arrayOfByte1);
    }
    label937:
    int k = -1;
    int m = -1;
    int n = -1;
    int i1 = -1;
    int i2 = -1;
    int i3 = -1;
    int i4 = -1;
    int i5 = -1;
    float f = -1.0F;
    int i6 = -1;
    int i7 = -1;
    int i8 = -1;
    int i9 = -1;
    boolean bool = false;
    AudioFormat.Encoding localEncoding = null;
    try
    {
      Bitstream localBitstream = new Bitstream(localPushbackInputStream);
      i11 = localBitstream.header_pos();
      localHashMap1.put("mp3.header.pos", new Integer(i11));
      localObject = localBitstream.readFrame();
      k = ((Header)localObject).version();
      if (k == 2) {
        localHashMap1.put("mp3.version.mpeg", Float.toString(2.5F));
      } else {
        localHashMap1.put("mp3.version.mpeg", Integer.toString(2 - k));
      }
      m = ((Header)localObject).layer();
      localHashMap1.put("mp3.version.layer", Integer.toString(m));
      n = ((Header)localObject).sample_frequency();
      i1 = ((Header)localObject).mode();
      localHashMap1.put("mp3.mode", new Integer(i1));
      i7 = i1 == 3 ? 1 : 2;
      localHashMap1.put("mp3.channels", new Integer(i7));
      bool = ((Header)localObject).vbr();
      localHashMap2.put("vbr", new Boolean(bool));
      localHashMap1.put("mp3.vbr", new Boolean(bool));
      localHashMap1.put("mp3.vbr.scale", new Integer(((Header)localObject).vbr_scale()));
      i2 = ((Header)localObject).calculate_framesize();
      localHashMap1.put("mp3.framesize.bytes", new Integer(i2));
      if (i2 < 0) {
        throw new UnsupportedAudioFileException("Invalid FrameSize : " + i2);
      }
      i4 = ((Header)localObject).frequency();
      localHashMap1.put("mp3.frequency.hz", new Integer(i4));
      f = (float)(1.0D / ((Header)localObject).ms_per_frame() * 1000.0D);
      localHashMap1.put("mp3.framerate.fps", new Float(f));
      if (f < 0.0F) {
        throw new UnsupportedAudioFileException("Invalid FrameRate : " + f);
      }
      int i12 = i;
      if ((i11 > 0) && (i != -1) && (i11 < i)) {
        i12 -= i11;
      }
      if (i != -1)
      {
        localHashMap1.put("mp3.length.bytes", new Integer(i));
        i5 = ((Header)localObject).max_number_of_frames(i12);
        localHashMap1.put("mp3.length.frames", new Integer(i5));
      }
      i6 = ((Header)localObject).bitrate();
      localHashMap2.put("bitrate", new Integer(i6));
      localHashMap1.put("mp3.bitrate.nominal.bps", new Integer(i6));
      i8 = ((Header)localObject).getSyncHeader();
      localEncoding = this.sm_aEncodings[k][(m - 1)];
      localHashMap1.put("mp3.version.encoding", localEncoding.toString());
      if (i != -1)
      {
        i9 = Math.round(((Header)localObject).total_ms(i12));
        localHashMap1.put("duration", new Long(i9 * 1000L));
      }
      localHashMap1.put("mp3.copyright", new Boolean(((Header)localObject).copyright()));
      localHashMap1.put("mp3.original", new Boolean(((Header)localObject).original()));
      localHashMap1.put("mp3.crc", new Boolean(((Header)localObject).checksums()));
      localHashMap1.put("mp3.padding", new Boolean(((Header)localObject).padding()));
      InputStream localInputStream = localBitstream.getRawID3v2();
      if (localInputStream != null)
      {
        localHashMap1.put("mp3.id3tag.v2", localInputStream);
        parseID3v2Frames(localInputStream, localHashMap1);
      }
      if (TDebug.TraceAudioFileReader) {
        TDebug.out(((Header)localObject).toString());
      }
    }
    catch (Exception localException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("not a MPEG stream:" + localException.getMessage());
      }
      throw new UnsupportedAudioFileException("not a MPEG stream:" + localException.getMessage());
    }
    int i10 = i8 >> 19 & 0x3;
    if (i10 == 1)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("not a MPEG stream: wrong version");
      }
      throw new UnsupportedAudioFileException("not a MPEG stream: wrong version");
    }
    int i11 = i8 >> 10 & 0x3;
    if (i11 == 3)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("not a MPEG stream: wrong sampling rate");
      }
      throw new UnsupportedAudioFileException("not a MPEG stream: wrong sampling rate");
    }
    if ((j == paramLong) && (paramLong != -1L))
    {
      localObject = (FileInputStream)paramInputStream;
      byte[] arrayOfByte2 = new byte[''];
      long l = ((FileInputStream)localObject).skip(paramInputStream.available() - arrayOfByte2.length);
      int i13 = ((FileInputStream)localObject).read(arrayOfByte2, 0, arrayOfByte2.length);
      if ((arrayOfByte2[0] == 84) && (arrayOfByte2[1] == 65) && (arrayOfByte2[2] == 71)) {
        parseID3v1Frames(arrayOfByte2, localHashMap1);
      }
    }
    Object localObject = new MpegAudioFormat(localEncoding, i4, -1, i7, -1, f, true, localHashMap2);
    return new MpegAudioFileFormat(MpegFileFormatType.MP3, (AudioFormat)localObject, i5, i, localHashMap1);
  }
  
  public AudioInputStream getAudioInputStream(File paramFile)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioInputStream(File file)");
    }
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    try
    {
      return getAudioInputStream(localFileInputStream);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      if (localFileInputStream != null) {
        localFileInputStream.close();
      }
      throw localUnsupportedAudioFileException;
    }
    catch (IOException localIOException)
    {
      if (localFileInputStream != null) {
        localFileInputStream.close();
      }
      throw localIOException;
    }
  }
  
  public AudioInputStream getAudioInputStream(URL paramURL)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MpegAudioFileReader.getAudioInputStream(URL): begin");
    }
    long l = -1L;
    URLConnection localURLConnection = paramURL.openConnection();
    int i = 0;
    int j = 4;
    byte[] arrayOfByte = new byte[j];
    localURLConnection.setRequestProperty("Icy-Metadata", "1");
    BufferedInputStream localBufferedInputStream = new BufferedInputStream(localURLConnection.getInputStream());
    localBufferedInputStream.mark(j);
    int k = localBufferedInputStream.read(arrayOfByte, 0, j);
    if (k > 2) {
      if (((arrayOfByte[0] == 73 ? 1 : 0) | (arrayOfByte[0] == 105 ? 1 : 0)) != 0) {
        if (((arrayOfByte[1] == 67 ? 1 : 0) | (arrayOfByte[1] == 99 ? 1 : 0)) != 0) {
          if (((arrayOfByte[2] == 89 ? 1 : 0) | (arrayOfByte[2] == 121 ? 1 : 0)) != 0) {
            i = 1;
          }
        }
      }
    }
    localBufferedInputStream.reset();
    Object localObject1 = null;
    if (i == 1)
    {
      localObject2 = new IcyInputStream(localBufferedInputStream);
      ((IcyInputStream)localObject2).addTagParseListener(IcyListener.getInstance());
      localObject1 = localObject2;
    }
    else
    {
      localObject2 = localURLConnection.getHeaderField("icy-metaint");
      if (localObject2 != null)
      {
        IcyInputStream localIcyInputStream = new IcyInputStream(localBufferedInputStream, (String)localObject2);
        localIcyInputStream.addTagParseListener(IcyListener.getInstance());
        localObject1 = localIcyInputStream;
      }
      else
      {
        localObject1 = localBufferedInputStream;
      }
    }
    Object localObject2 = null;
    try
    {
      localObject2 = getAudioInputStream((InputStream)localObject1, l);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      ((InputStream)localObject1).close();
      throw localUnsupportedAudioFileException;
    }
    catch (IOException localIOException)
    {
      ((InputStream)localObject1).close();
      throw localIOException;
    }
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MpegAudioFileReader.getAudioInputStream(URL): end");
    }
    return (AudioInputStream)localObject2;
  }
  
  public AudioInputStream getAudioInputStream(InputStream paramInputStream)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("MpegAudioFileReader.getAudioInputStream(InputStream inputStream)");
    }
    if (!paramInputStream.markSupported()) {
      paramInputStream = new BufferedInputStream(paramInputStream);
    }
    return super.getAudioInputStream(paramInputStream);
  }
  
  protected void parseID3v1Frames(byte[] paramArrayOfByte, HashMap paramHashMap)
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("Parsing ID3v1");
    }
    String str1 = null;
    try
    {
      str1 = new String(paramArrayOfByte, 0, paramArrayOfByte.length, "ISO-8859-1");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      str1 = new String(paramArrayOfByte, 0, paramArrayOfByte.length);
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("Cannot use ISO-8859-1");
      }
    }
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("ID3v1 frame dump='" + str1 + "'");
    }
    int i = 3;
    String str2 = chopSubstring(str1, , i);
    String str3 = (String)paramHashMap.get("title");
    if (((str3 == null) || (str3.length() == 0)) && (str2 != null)) {
      paramHashMap.put("title", str2);
    }
    String str4 = chopSubstring(str1, , i);
    String str5 = (String)paramHashMap.get("author");
    if (((str5 == null) || (str5.length() == 0)) && (str4 != null)) {
      paramHashMap.put("author", str4);
    }
    String str6 = chopSubstring(str1, , i);
    String str7 = (String)paramHashMap.get("album");
    if (((str7 == null) || (str7.length() == 0)) && (str6 != null)) {
      paramHashMap.put("album", str6);
    }
    String str8 = chopSubstring(str1, , i);
    String str9 = (String)paramHashMap.get("year");
    if (((str9 == null) || (str9.length() == 0)) && (str8 != null)) {
      paramHashMap.put("date", str8);
    }
    String str10 = chopSubstring(str1, , i);
    String str11 = (String)paramHashMap.get("comment");
    if (((str11 == null) || (str11.length() == 0)) && (str10 != null)) {
      paramHashMap.put("comment", str10);
    }
    String str12 = "" + (paramArrayOfByte[126] & 0xFF);
    String str13 = (String)paramHashMap.get("mp3.id3tag.track");
    if (((str13 == null) || (str13.length() == 0)) && (str12 != null)) {
      paramHashMap.put("mp3.id3tag.track", str12);
    }
    int j = paramArrayOfByte[127] & 0xFF;
    if ((j >= 0) && (j < id3v1genres.length))
    {
      String str14 = (String)paramHashMap.get("mp3.id3tag.genre");
      if ((str14 == null) || (str14.length() == 0)) {
        paramHashMap.put("mp3.id3tag.genre", id3v1genres[j]);
      }
    }
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("ID3v1 parsed");
    }
  }
  
  private String chopSubstring(String paramString, int paramInt1, int paramInt2)
  {
    String str = null;
    try
    {
      str = paramString.substring(paramInt1, paramInt2);
      int i = str.indexOf(0);
      if (i != -1) {
        str = str.substring(0, i);
      }
    }
    catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("Cannot chopSubString " + localStringIndexOutOfBoundsException.getMessage());
      }
    }
    return str;
  }
  
  protected void parseID3v2Frames(InputStream paramInputStream, HashMap paramHashMap)
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("Parsing ID3v2");
    }
    byte[] arrayOfByte = null;
    int i = -1;
    try
    {
      i = paramInputStream.available();
      arrayOfByte = new byte[i];
      paramInputStream.mark(i);
      paramInputStream.read(arrayOfByte);
      paramInputStream.reset();
    }
    catch (IOException localIOException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("Cannot parse ID3v2 :" + localIOException.getMessage());
      }
    }
    if (!"ID3".equals(new String(arrayOfByte, 0, 3)))
    {
      TDebug.out("No ID3v2 header found!");
      return;
    }
    int j = arrayOfByte[3] & 0xFF;
    paramHashMap.put("mp3.id3tag.v2.version", String.valueOf(j));
    if ((j < 2) || (j > 4))
    {
      TDebug.out("Unsupported ID3v2 version " + j + "!");
      return;
    }
    try
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("ID3v2 frame dump='" + new String(arrayOfByte, 0, arrayOfByte.length) + "'");
      }
      String str1 = null;
      int k = 10;
      while ((k < arrayOfByte.length) && (arrayOfByte[k] > 0))
      {
        String str2;
        if ((j == 3) || (j == 4))
        {
          str2 = new String(arrayOfByte, k, 4);
          i = arrayOfByte[(k + 4)] << 24 & 0xFF000000 | arrayOfByte[(k + 5)] << 16 & 0xFF0000 | arrayOfByte[(k + 6)] << 8 & 0xFF00 | arrayOfByte[(k + 7)] & 0xFF;
          k += 10;
          if ((str2.equals("TALB")) || (str2.equals("TIT2")) || (str2.equals("TYER")) || (str2.equals("TPE1")) || (str2.equals("TCOP")) || (str2.equals("COMM")) || (str2.equals("TCON")) || (str2.equals("TRCK")) || (str2.equals("TPOS")) || (str2.equals("TDRC")) || (str2.equals("TCOM")) || (str2.equals("TIT1")) || (str2.equals("TENC")) || (str2.equals("TPUB")) || (str2.equals("TPE2")) || (str2.equals("TLEN")))
          {
            if (str2.equals("COMM")) {
              str1 = parseText(arrayOfByte, k, i, 5);
            } else {
              str1 = parseText(arrayOfByte, k, i, 1);
            }
            if ((str1 != null) && (str1.length() > 0)) {
              if (str2.equals("TALB")) {
                paramHashMap.put("album", str1);
              } else if (str2.equals("TIT2")) {
                paramHashMap.put("title", str1);
              } else if (str2.equals("TYER")) {
                paramHashMap.put("date", str1);
              } else if (str2.equals("TDRC")) {
                paramHashMap.put("date", str1);
              } else if (str2.equals("TPE1")) {
                paramHashMap.put("author", str1);
              } else if (str2.equals("TCOP")) {
                paramHashMap.put("copyright", str1);
              } else if (str2.equals("COMM")) {
                paramHashMap.put("comment", str1);
              } else if (str2.equals("TCON")) {
                paramHashMap.put("mp3.id3tag.genre", str1);
              } else if (str2.equals("TRCK")) {
                paramHashMap.put("mp3.id3tag.track", str1);
              } else if (str2.equals("TPOS")) {
                paramHashMap.put("mp3.id3tag.disc", str1);
              } else if (str2.equals("TCOM")) {
                paramHashMap.put("mp3.id3tag.composer", str1);
              } else if (str2.equals("TIT1")) {
                paramHashMap.put("mp3.id3tag.grouping", str1);
              } else if (str2.equals("TENC")) {
                paramHashMap.put("mp3.id3tag.encoded", str1);
              } else if (str2.equals("TPUB")) {
                paramHashMap.put("mp3.id3tag.publisher", str1);
              } else if (str2.equals("TPE2")) {
                paramHashMap.put("mp3.id3tag.orchestra", str1);
              } else if (str2.equals("TLEN")) {
                paramHashMap.put("mp3.id3tag.length", str1);
              }
            }
          }
        }
        else
        {
          str2 = new String(arrayOfByte, k, 3);
          i = 0 + (arrayOfByte[(k + 3)] << 16) + (arrayOfByte[(k + 4)] << 8) + arrayOfByte[(k + 5)];
          k += 6;
          if ((str2.equals("TAL")) || (str2.equals("TT2")) || (str2.equals("TP1")) || (str2.equals("TYE")) || (str2.equals("TRK")) || (str2.equals("TPA")) || (str2.equals("TCR")) || (str2.equals("TCO")) || (str2.equals("TCM")) || (str2.equals("COM")) || (str2.equals("TT1")) || (str2.equals("TEN")) || (str2.equals("TPB")) || (str2.equals("TP2")) || (str2.equals("TLE")))
          {
            if (str2.equals("COM")) {
              str1 = parseText(arrayOfByte, k, i, 5);
            } else {
              str1 = parseText(arrayOfByte, k, i, 1);
            }
            if ((str1 != null) && (str1.length() > 0)) {
              if (str2.equals("TAL")) {
                paramHashMap.put("album", str1);
              } else if (str2.equals("TT2")) {
                paramHashMap.put("title", str1);
              } else if (str2.equals("TYE")) {
                paramHashMap.put("date", str1);
              } else if (str2.equals("TP1")) {
                paramHashMap.put("author", str1);
              } else if (str2.equals("TCR")) {
                paramHashMap.put("copyright", str1);
              } else if (str2.equals("COM")) {
                paramHashMap.put("comment", str1);
              } else if (str2.equals("TCO")) {
                paramHashMap.put("mp3.id3tag.genre", str1);
              } else if (str2.equals("TRK")) {
                paramHashMap.put("mp3.id3tag.track", str1);
              } else if (str2.equals("TPA")) {
                paramHashMap.put("mp3.id3tag.disc", str1);
              } else if (str2.equals("TCM")) {
                paramHashMap.put("mp3.id3tag.composer", str1);
              } else if (str2.equals("TT1")) {
                paramHashMap.put("mp3.id3tag.grouping", str1);
              } else if (str2.equals("TEN")) {
                paramHashMap.put("mp3.id3tag.encoded", str1);
              } else if (str2.equals("TPB")) {
                paramHashMap.put("mp3.id3tag.publisher", str1);
              } else if (str2.equals("TP2")) {
                paramHashMap.put("mp3.id3tag.orchestra", str1);
              } else if (str2.equals("TLE")) {
                paramHashMap.put("mp3.id3tag.length", str1);
              }
            }
          }
        }
        k += i;
      }
    }
    catch (RuntimeException localRuntimeException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("Cannot parse ID3v2 :" + localRuntimeException.getMessage());
      }
    }
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("ID3v2 parsed");
    }
  }
  
  protected String parseText(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    String str = null;
    try
    {
      String[] arrayOfString = { "ISO-8859-1", "UTF16", "UTF-16BE", "UTF-8" };
      str = new String(paramArrayOfByte, paramInt1 + paramInt3, paramInt2 - paramInt3, arrayOfString[paramArrayOfByte[paramInt1]]);
      str = chopSubstring(str, 0, str.length());
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("ID3v2 Encoding error :" + localUnsupportedEncodingException.getMessage());
      }
    }
    return str;
  }
  
  protected void loadShoutcastInfo(InputStream paramInputStream, HashMap paramHashMap)
    throws IOException
  {
    IcyInputStream localIcyInputStream = new IcyInputStream(new BufferedInputStream(paramInputStream));
    HashMap localHashMap = localIcyInputStream.getTagHash();
    MP3Tag localMP3Tag = localIcyInputStream.getTag("icy-name");
    if (localMP3Tag != null) {
      paramHashMap.put("title", ((String)localMP3Tag.getValue()).trim());
    }
    MP3Tag[] arrayOfMP3Tag = localIcyInputStream.getTags();
    if (arrayOfMP3Tag != null)
    {
      StringBuffer localStringBuffer = new StringBuffer();
      for (int i = 0; i < arrayOfMP3Tag.length; i++)
      {
        String str1 = arrayOfMP3Tag[i].getName();
        String str2 = ((String)localIcyInputStream.getTag(str1).getValue()).trim();
        paramHashMap.put("mp3.shoutcast.metadata." + str1, str2);
      }
    }
  }
  
  static
  {
    String str = System.getProperty("marklimit");
    if (str != null) {
      try
      {
        INITAL_READ_LENGTH = Integer.parseInt(str);
        MARK_LIMIT = INITAL_READ_LENGTH + 1;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        localNumberFormatException.printStackTrace();
      }
    }
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\MpegAudioFileReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */