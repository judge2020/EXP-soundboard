package javazoom.spi.mpeg.sampled.file.tag;

public class IcyTag
  extends MP3Tag
  implements StringableTag
{
  public IcyTag(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
  
  public String getValueAsString()
  {
    return (String)getValue();
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\IcyTag.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */