package javazoom.spi.mpeg.sampled.file.tag;

import java.util.EventObject;

public class TagParseEvent
  extends EventObject
{
  protected MP3Tag tag;
  
  public TagParseEvent(Object paramObject, MP3Tag paramMP3Tag)
  {
    super(paramObject);
    this.tag = paramMP3Tag;
  }
  
  public MP3Tag getTag()
  {
    return this.tag;
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\TagParseEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */