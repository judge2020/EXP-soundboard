package javazoom.spi.mpeg.sampled.file.tag;

import java.util.EventListener;

public abstract interface TagParseListener
  extends EventListener
{
  public abstract void tagParsed(TagParseEvent paramTagParseEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\TagParseListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */