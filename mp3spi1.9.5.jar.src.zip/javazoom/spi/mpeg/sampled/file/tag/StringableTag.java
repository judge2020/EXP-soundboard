package javazoom.spi.mpeg.sampled.file.tag;

public abstract interface StringableTag
{
  public abstract String getValueAsString();
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\StringableTag.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */