package javazoom.spi.mpeg.sampled.file.tag;

public abstract interface MP3MetadataParser
{
  public abstract void addTagParseListener(TagParseListener paramTagParseListener);
  
  public abstract void removeTagParseListener(TagParseListener paramTagParseListener);
  
  public abstract MP3Tag[] getTags();
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\MP3MetadataParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */