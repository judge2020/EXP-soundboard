package javazoom.spi.mpeg.sampled.file.tag;

public abstract class MP3Tag
{
  protected String name;
  protected Object value;
  
  public MP3Tag(String paramString, Object paramObject)
  {
    this.name = paramString;
    this.value = paramObject;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public Object getValue()
  {
    return this.value;
  }
  
  public String toString()
  {
    return getClass().getName() + " -- " + getName() + ":" + getValue().toString();
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\MP3Tag.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */