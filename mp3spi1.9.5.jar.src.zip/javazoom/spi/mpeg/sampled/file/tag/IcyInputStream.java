package javazoom.spi.mpeg.sampled.file.tag;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collection;
import java.util.HashMap;
import java.util.StringTokenizer;

public class IcyInputStream
  extends BufferedInputStream
  implements MP3MetadataParser
{
  public static boolean DEBUG = false;
  MP3TagParseSupport tagParseSupport = new MP3TagParseSupport();
  protected static final String INLINE_TAG_SEPARATORS = ";\000";
  HashMap tags = new HashMap();
  protected byte[] crlfBuffer = new byte['Ѐ'];
  protected int metaint = -1;
  protected int bytesUntilNextMetadata = -1;
  
  public IcyInputStream(InputStream paramInputStream)
    throws IOException
  {
    super(paramInputStream);
    readInitialHeaders();
    IcyTag localIcyTag = (IcyTag)getTag("icy-metaint");
    if (DEBUG) {
      System.out.println("METATAG:" + localIcyTag);
    }
    if (localIcyTag != null)
    {
      String str = localIcyTag.getValueAsString();
      try
      {
        this.metaint = Integer.parseInt(str.trim());
        if (DEBUG) {
          System.out.println("METAINT:" + this.metaint);
        }
        this.bytesUntilNextMetadata = this.metaint;
      }
      catch (NumberFormatException localNumberFormatException) {}
    }
  }
  
  public IcyInputStream(InputStream paramInputStream, String paramString)
    throws IOException
  {
    super(paramInputStream);
    try
    {
      this.metaint = Integer.parseInt(paramString.trim());
      if (DEBUG) {
        System.out.println("METAINT:" + this.metaint);
      }
      this.bytesUntilNextMetadata = this.metaint;
    }
    catch (NumberFormatException localNumberFormatException) {}
  }
  
  protected void readInitialHeaders()
    throws IOException
  {
    String str = null;
    while (!(str = readCRLFLine()).equals(""))
    {
      int i = str.indexOf(':');
      if (i != -1)
      {
        IcyTag localIcyTag = new IcyTag(str.substring(0, i), str.substring(i + 1));
        addTag(localIcyTag);
      }
    }
  }
  
  protected String readCRLFLine()
    throws IOException
  {
    for (int i = 0; i < this.crlfBuffer.length; i++)
    {
      int j = (byte)read();
      if (j == 13)
      {
        int k = (byte)read();
        i++;
        if (k == 10) {
          break;
        }
        this.crlfBuffer[(i - 1)] = j;
        this.crlfBuffer[i] = k;
      }
      else
      {
        this.crlfBuffer[i] = j;
      }
    }
    return new String(this.crlfBuffer, 0, i - 1);
  }
  
  public int read()
    throws IOException
  {
    if (this.bytesUntilNextMetadata > 0)
    {
      this.bytesUntilNextMetadata -= 1;
      return super.read();
    }
    if (this.bytesUntilNextMetadata == 0)
    {
      readMetadata();
      this.bytesUntilNextMetadata = (this.metaint - 1);
      return super.read();
    }
    return super.read();
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    int j;
    if (this.bytesUntilNextMetadata > 0)
    {
      i = Math.min(paramInt2, this.bytesUntilNextMetadata);
      j = super.read(paramArrayOfByte, paramInt1, i);
      this.bytesUntilNextMetadata -= j;
      return j;
    }
    if (this.bytesUntilNextMetadata == 0)
    {
      readMetadata();
      this.bytesUntilNextMetadata = this.metaint;
      i = Math.min(paramInt2, this.bytesUntilNextMetadata);
      j = super.read(paramArrayOfByte, paramInt1, i);
      this.bytesUntilNextMetadata -= j;
      return j;
    }
    return super.read(paramArrayOfByte, paramInt1, paramInt2);
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  protected void readMetadata()
    throws IOException
  {
    int i = super.read();
    if (DEBUG) {
      System.out.println("BLOCKCOUNT:" + i);
    }
    int j = i * 16;
    if (j < 0) {
      return;
    }
    byte[] arrayOfByte = new byte[j];
    int k = 0;
    while (j > 0)
    {
      int m = super.read(arrayOfByte, k, j);
      k += m;
      j -= m;
    }
    if (i > 0) {
      parseInlineIcyTags(arrayOfByte);
    }
  }
  
  protected void parseInlineIcyTags(byte[] paramArrayOfByte)
  {
    String str1 = null;
    try
    {
      str1 = new String(paramArrayOfByte, "ISO-8859-1");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      str1 = new String(paramArrayOfByte);
    }
    if (DEBUG) {
      System.out.println("BLOCKSTR:" + str1);
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(str1, ";\000");
    int i = 0;
    while (localStringTokenizer.hasMoreTokens())
    {
      String str2 = localStringTokenizer.nextToken();
      int j = str2.indexOf('=');
      if (j != -1)
      {
        int k = str2.charAt(j + 1) == '\'' ? j + 2 : j + 1;
        int m = str2.charAt(str2.length() - 1) == '\'' ? str2.length() - 1 : str2.length();
        String str3 = str2.substring(0, j);
        String str4 = str2.substring(k, m);
        IcyTag localIcyTag = new IcyTag(str3, str4);
        addTag(localIcyTag);
      }
    }
  }
  
  protected void addTag(IcyTag paramIcyTag)
  {
    this.tags.put(paramIcyTag.getName(), paramIcyTag);
    this.tagParseSupport.fireTagParsed(this, paramIcyTag);
  }
  
  public MP3Tag getTag(String paramString)
  {
    return (MP3Tag)this.tags.get(paramString);
  }
  
  public MP3Tag[] getTags()
  {
    return (MP3Tag[])this.tags.values().toArray(new MP3Tag[0]);
  }
  
  public HashMap getTagHash()
  {
    return this.tags;
  }
  
  public void addTagParseListener(TagParseListener paramTagParseListener)
  {
    this.tagParseSupport.addTagParseListener(paramTagParseListener);
  }
  
  public void removeTagParseListener(TagParseListener paramTagParseListener)
  {
    this.tagParseSupport.removeTagParseListener(paramTagParseListener);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    byte[] arrayOfByte = new byte['È'];
    if (paramArrayOfString.length != 1) {
      return;
    }
    try
    {
      URL localURL = new URL(paramArrayOfString[0]);
      URLConnection localURLConnection = localURL.openConnection();
      localURLConnection.setRequestProperty("Icy-Metadata", "1");
      IcyInputStream localIcyInputStream = new IcyInputStream(new BufferedInputStream(localURLConnection.getInputStream()));
      while (localIcyInputStream.available() > -1) {
        localIcyInputStream.read(arrayOfByte, 0, arrayOfByte.length);
      }
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\tag\IcyInputStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */