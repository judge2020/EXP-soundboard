package javazoom.spi.mpeg.sampled.file;

import javazoom.spi.mpeg.sampled.file.tag.MP3Tag;
import javazoom.spi.mpeg.sampled.file.tag.TagParseEvent;
import javazoom.spi.mpeg.sampled.file.tag.TagParseListener;

public class IcyListener
  implements TagParseListener
{
  private static IcyListener instance = null;
  private MP3Tag lastTag = null;
  private String streamTitle = null;
  private String streamUrl = null;
  
  public static synchronized IcyListener getInstance()
  {
    if (instance == null) {
      instance = new IcyListener();
    }
    return instance;
  }
  
  public void tagParsed(TagParseEvent paramTagParseEvent)
  {
    this.lastTag = paramTagParseEvent.getTag();
    String str = this.lastTag.getName();
    if ((str != null) && (str.equalsIgnoreCase("streamtitle"))) {
      this.streamTitle = ((String)this.lastTag.getValue());
    } else if ((str != null) && (str.equalsIgnoreCase("streamurl"))) {
      this.streamUrl = ((String)this.lastTag.getValue());
    }
  }
  
  public MP3Tag getLastTag()
  {
    return this.lastTag;
  }
  
  public void setLastTag(MP3Tag paramMP3Tag)
  {
    this.lastTag = paramMP3Tag;
  }
  
  public String getStreamTitle()
  {
    return this.streamTitle;
  }
  
  public String getStreamUrl()
  {
    return this.streamUrl;
  }
  
  public void setStreamTitle(String paramString)
  {
    this.streamTitle = paramString;
  }
  
  public void setStreamUrl(String paramString)
  {
    this.streamUrl = paramString;
  }
  
  public void reset()
  {
    this.lastTag = null;
    this.streamTitle = null;
    this.streamUrl = null;
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\IcyListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */