package javazoom.spi.mpeg.sampled.file;

import java.util.Map;
import javax.sound.sampled.AudioFormat.Encoding;
import org.tritonus.share.sampled.TAudioFormat;

public class MpegAudioFormat
  extends TAudioFormat
{
  public MpegAudioFormat(AudioFormat.Encoding paramEncoding, float paramFloat1, int paramInt1, int paramInt2, int paramInt3, float paramFloat2, boolean paramBoolean, Map paramMap)
  {
    super(paramEncoding, paramFloat1, paramInt1, paramInt2, paramInt3, paramFloat2, paramBoolean, paramMap);
  }
  
  public Map properties()
  {
    return super.properties();
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\MpegAudioFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */