package javazoom.spi.mpeg.sampled.file;

import javax.sound.sampled.AudioFileFormat.Type;

public class MpegFileFormatType
  extends AudioFileFormat.Type
{
  public static final AudioFileFormat.Type MPEG = new MpegFileFormatType("MPEG", "mpeg");
  public static final AudioFileFormat.Type MP3 = new MpegFileFormatType("MP3", "mp3");
  
  public MpegFileFormatType(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\mpeg\sampled\file\MpegFileFormatType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */