package javazoom.spi;

import java.util.Map;

public abstract interface PropertiesContainer
{
  public abstract Map properties();
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\mp3spi1.9.5.jar!\javazoom\spi\PropertiesContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */