package com.google.gson.stream;

public enum JsonToken
{
  BEGIN_ARRAY,  END_ARRAY,  BEGIN_OBJECT,  END_OBJECT,  NAME,  STRING,  NUMBER,  BOOLEAN,  NULL,  END_DOCUMENT;
  
  private JsonToken() {}
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\gson-2.2.4.jar!\com\google\gson\stream\JsonToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */