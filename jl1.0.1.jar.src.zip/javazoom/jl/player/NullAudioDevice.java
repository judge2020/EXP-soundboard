package javazoom.jl.player;

public class NullAudioDevice
  extends AudioDeviceBase
{
  public int getPosition()
  {
    return 0;
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\player\NullAudioDevice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */