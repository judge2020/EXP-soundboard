package javazoom.jl.player.advanced;

public abstract class PlaybackListener
{
  public void playbackStarted(PlaybackEvent paramPlaybackEvent) {}
  
  public void playbackFinished(PlaybackEvent paramPlaybackEvent) {}
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\player\advanced\PlaybackListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */