package javazoom.jl.decoder;

public abstract interface JavaLayerErrors
{
  public static final int BITSTREAM_ERROR = 256;
  public static final int DECODER_ERROR = 512;
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\decoder\JavaLayerErrors.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */