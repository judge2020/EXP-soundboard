package javazoom.jl.decoder;

public class BitstreamException
  extends JavaLayerException
  implements BitstreamErrors
{
  private int errorcode = 256;
  
  public BitstreamException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public BitstreamException(int paramInt, Throwable paramThrowable)
  {
    this(getErrorString(paramInt), paramThrowable);
  }
  
  public int getErrorCode()
  {
    return this.errorcode;
  }
  
  public static String getErrorString(int paramInt)
  {
    return "Bitstream errorcode " + Integer.toHexString(paramInt);
  }
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\decoder\BitstreamException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */