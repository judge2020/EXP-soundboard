package javazoom.jl.decoder;

import java.io.InputStream;

public abstract interface JavaLayerHook
{
  public abstract InputStream getResourceAsStream(String paramString);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\decoder\JavaLayerHook.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */