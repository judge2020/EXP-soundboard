package javazoom.jl.decoder;

public class JavaLayerError
  extends Error
{}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\jl1.0.1.jar!\javazoom\jl\decoder\JavaLayerError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */