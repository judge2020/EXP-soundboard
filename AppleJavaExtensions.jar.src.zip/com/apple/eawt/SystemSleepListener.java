package com.apple.eawt;

public abstract interface SystemSleepListener
  extends AppEventListener
{
  public abstract void systemAboutToSleep(AppEvent.SystemSleepEvent paramSystemSleepEvent);
  
  public abstract void systemAwoke(AppEvent.SystemSleepEvent paramSystemSleepEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\SystemSleepListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */