package com.apple.eawt;

public abstract interface AppHiddenListener
  extends AppEventListener
{
  public abstract void appHidden(AppEvent.AppHiddenEvent paramAppHiddenEvent);
  
  public abstract void appUnhidden(AppEvent.AppHiddenEvent paramAppHiddenEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\AppHiddenListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */