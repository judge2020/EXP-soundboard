package com.apple.eawt.event;

public abstract interface SwipeListener
  extends GestureListener
{
  public abstract void swipedUp(SwipeEvent paramSwipeEvent);
  
  public abstract void swipedDown(SwipeEvent paramSwipeEvent);
  
  public abstract void swipedLeft(SwipeEvent paramSwipeEvent);
  
  public abstract void swipedRight(SwipeEvent paramSwipeEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\SwipeListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */