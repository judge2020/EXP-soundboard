/*   */ package com.apple.eawt.event;
/*   */ 
/*   */ public class GesturePhaseEvent extends GestureEvent
/*   */ {
/*   */   GesturePhaseEvent() {
/* 6 */     GestureUtilities.unimplemented();
/*   */   }
/*   */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\GesturePhaseEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */