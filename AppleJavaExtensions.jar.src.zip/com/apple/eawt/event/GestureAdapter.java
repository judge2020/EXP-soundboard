/*    */ package com.apple.eawt.event;
/*    */ 
/*    */ public abstract class GestureAdapter implements GesturePhaseListener, MagnificationListener, RotationListener, SwipeListener {
/*  4 */   public void gestureBegan(GesturePhaseEvent paramGesturePhaseEvent) { GestureUtilities.unimplemented(); }
/*  5 */   public void gestureEnded(GesturePhaseEvent paramGesturePhaseEvent) { GestureUtilities.unimplemented(); }
/*  6 */   public void magnify(MagnificationEvent paramMagnificationEvent) { GestureUtilities.unimplemented(); }
/*  7 */   public void rotate(RotationEvent paramRotationEvent) { GestureUtilities.unimplemented(); }
/*  8 */   public void swipedDown(SwipeEvent paramSwipeEvent) { GestureUtilities.unimplemented(); }
/*  9 */   public void swipedLeft(SwipeEvent paramSwipeEvent) { GestureUtilities.unimplemented(); }
/* 10 */   public void swipedRight(SwipeEvent paramSwipeEvent) { GestureUtilities.unimplemented(); }
/* 11 */   public void swipedUp(SwipeEvent paramSwipeEvent) { GestureUtilities.unimplemented(); }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\GestureAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */