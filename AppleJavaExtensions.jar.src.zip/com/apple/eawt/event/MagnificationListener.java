package com.apple.eawt.event;

public abstract interface MagnificationListener
  extends GestureListener
{
  public abstract void magnify(MagnificationEvent paramMagnificationEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\MagnificationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */