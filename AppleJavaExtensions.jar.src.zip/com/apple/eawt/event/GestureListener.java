package com.apple.eawt.event;

import java.util.EventListener;

public abstract interface GestureListener
  extends EventListener
{}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\GestureListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */