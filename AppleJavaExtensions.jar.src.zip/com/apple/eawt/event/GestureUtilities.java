/*    */ package com.apple.eawt.event;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ 
/*    */ public final class GestureUtilities {
/*    */   static RuntimeException unimplemented() {
/*  7 */     return new RuntimeException("Unimplemented");
/*    */   }
/*    */   
/*    */   GestureUtilities() {
/* 11 */     unimplemented();
/*    */   }
/*    */   
/*    */   public static void addGestureListenerTo(JComponent paramJComponent, GestureListener paramGestureListener) {
/* 15 */     unimplemented();
/*    */   }
/*    */   
/*    */   public static void removeGestureListenerFrom(JComponent paramJComponent, GestureListener paramGestureListener) {
/* 19 */     unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\GestureUtilities.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */