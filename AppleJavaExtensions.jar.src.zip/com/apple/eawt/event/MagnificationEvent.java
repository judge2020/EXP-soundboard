/*    */ package com.apple.eawt.event;
/*    */ 
/*    */ public class MagnificationEvent extends GestureEvent
/*    */ {
/*    */   MagnificationEvent(double paramDouble) {
/*  6 */     GestureUtilities.unimplemented();
/*    */   }
/*    */   
/*    */   public double getMagnification() {
/* 10 */     GestureUtilities.unimplemented();
/* 11 */     return 0.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\MagnificationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */