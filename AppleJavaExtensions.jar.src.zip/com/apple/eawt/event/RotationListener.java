package com.apple.eawt.event;

public abstract interface RotationListener
  extends GestureListener
{
  public abstract void rotate(RotationEvent paramRotationEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\RotationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */