/*   */ package com.apple.eawt.event;
/*   */ 
/*   */ public class SwipeEvent extends GestureEvent
/*   */ {
/*   */   SwipeEvent() {
/* 6 */     GestureUtilities.unimplemented();
/*   */   }
/*   */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\event\SwipeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */