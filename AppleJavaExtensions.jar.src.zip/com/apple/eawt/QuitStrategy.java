package com.apple.eawt;

public enum QuitStrategy
{
  SYSTEM_EXIT_0,  CLOSE_ALL_WINDOWS;
  
  private QuitStrategy() {}
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\QuitStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */