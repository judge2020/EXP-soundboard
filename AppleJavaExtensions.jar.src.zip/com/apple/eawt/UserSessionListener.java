package com.apple.eawt;

public abstract interface UserSessionListener
  extends AppEventListener
{
  public abstract void userSessionDeactivated(AppEvent.UserSessionEvent paramUserSessionEvent);
  
  public abstract void userSessionActivated(AppEvent.UserSessionEvent paramUserSessionEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\UserSessionListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */