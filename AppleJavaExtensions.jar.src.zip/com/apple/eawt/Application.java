/*     */ package com.apple.eawt;
/*     */ 
/*     */ import java.awt.Image;
/*     */ 
/*     */ public class Application
/*     */ {
/*     */   static RuntimeException unimplemented()
/*     */   {
/*   9 */     return new RuntimeException("Unimplemented");
/*     */   }
/*     */   
/*     */   public static Application getApplication() {
/*  13 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Application() {
/*  18 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void addAppEventListener(AppEventListener paramAppEventListener) {
/*  22 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void removeAppEventListener(AppEventListener paramAppEventListener) {
/*  26 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setAboutHandler(AboutHandler paramAboutHandler) {
/*  30 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setPreferencesHandler(PreferencesHandler paramPreferencesHandler) {
/*  34 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setOpenFileHandler(OpenFilesHandler paramOpenFilesHandler) {
/*  38 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setPrintFileHandler(PrintFilesHandler paramPrintFilesHandler) {
/*  42 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setOpenURIHandler(OpenURIHandler paramOpenURIHandler) {
/*  46 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setQuitHandler(QuitHandler paramQuitHandler) {
/*  50 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setQuitStrategy(QuitStrategy paramQuitStrategy) {
/*  54 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void enableSuddenTermination() {
/*  58 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void disableSuddenTermination() {
/*  62 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void requestForeground(boolean paramBoolean) {
/*  66 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void requestUserAttention(boolean paramBoolean) {
/*  70 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void openHelpViewer() {
/*  74 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockMenu(java.awt.PopupMenu paramPopupMenu) {
/*  78 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public java.awt.PopupMenu getDockMenu() {
/*  82 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockIconImage(Image paramImage) {
/*  86 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public Image getDockIconImage() {
/*  90 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDockIconBadge(String paramString) {
/*  94 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void setDefaultMenuBar(javax.swing.JMenuBar paramJMenuBar) {
/*  98 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   public void requestToggleFullScreen(java.awt.Window paramWindow) {
/* 102 */     throw unimplemented();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void addApplicationListener(ApplicationListener paramApplicationListener)
/*     */   {
/* 110 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void removeApplicationListener(ApplicationListener paramApplicationListener) {
/* 115 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setEnabledPreferencesMenu(boolean paramBoolean) {
/* 120 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setEnabledAboutMenu(boolean paramBoolean) {
/* 125 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public boolean getEnabledPreferencesMenu() {
/* 130 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public boolean getEnabledAboutMenu() {
/* 135 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public boolean isAboutMenuItemPresent() {
/* 140 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void addAboutMenuItem() {
/* 145 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void removeAboutMenuItem() {
/* 150 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public boolean isPreferencesMenuItemPresent() {
/* 155 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void addPreferencesMenuItem() {
/* 160 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void removePreferencesMenuItem() {
/* 165 */     throw unimplemented();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public static java.awt.Point getMouseLocationOnScreen() {
/* 170 */     throw unimplemented();
/*     */   }
/*     */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\Application.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */