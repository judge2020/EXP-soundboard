/*    */ package com.apple.eawt;
/*    */ 
/*    */ import java.awt.Window;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FullScreenUtilities
/*    */ {
/*    */   FullScreenUtilities()
/*    */   {
/* 12 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public static void setWindowCanFullScreen(Window paramWindow, boolean paramBoolean) {
/* 16 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public static void addFullScreenListenerTo(Window paramWindow, FullScreenListener paramFullScreenListener) {
/* 20 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public static void removeFullScreenListenerFrom(Window paramWindow, FullScreenListener paramFullScreenListener) {
/* 24 */     throw Application.unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\FullScreenUtilities.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */