package com.apple.eawt;

public abstract interface PreferencesHandler
{
  public abstract void handlePreferences(AppEvent.PreferencesEvent paramPreferencesEvent);
}


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\PreferencesHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */