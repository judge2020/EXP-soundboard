/*    */ package com.apple.eawt;
/*    */ 
/*    */ public class QuitResponse {
/*    */   QuitResponse() {
/*  5 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void performQuit() {
/*  9 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void cancelQuit() {
/* 13 */     throw Application.unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\QuitResponse.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */