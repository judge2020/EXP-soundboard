/*    */ package com.apple.eawt;
/*    */ 
/*    */ @Deprecated
/*    */ public class ApplicationAdapter implements ApplicationListener {
/*    */   public ApplicationAdapter() {
/*  6 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   @Deprecated
/* 10 */   public void handleAbout(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 13 */   public void handleOpenApplication(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 16 */   public void handleOpenFile(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 19 */   public void handlePreferences(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 22 */   public void handlePrintFile(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 25 */   public void handleQuit(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */   
/*    */   @Deprecated
/* 28 */   public void handleReOpenApplication(ApplicationEvent paramApplicationEvent) { throw Application.unimplemented(); }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\ApplicationAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */