/*    */ package com.apple.eawt;
/*    */ 
/*    */ import java.awt.Window;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public abstract class AppEvent extends EventObject
/*    */ {
/*    */   AppEvent()
/*    */   {
/* 10 */     super(Application.getApplication());
/*    */   }
/*    */   
/*    */   public static abstract class FilesEvent extends AppEvent {
/*    */     public java.util.List<java.io.File> getFiles() {
/* 15 */       throw Application.unimplemented();
/*    */     }
/*    */   }
/*    */   
/*    */   public static class OpenFilesEvent extends AppEvent.FilesEvent {
/*    */     public String getSearchTerm() {
/* 21 */       throw Application.unimplemented();
/*    */     }
/*    */   }
/*    */   
/*    */   public static class PrintFilesEvent extends AppEvent.FilesEvent
/*    */   {}
/*    */   
/*    */   public static class OpenURIEvent extends AppEvent {
/* 29 */     public java.net.URI getURI() { throw Application.unimplemented(); } }
/*    */   
/*    */   public static class AboutEvent extends AppEvent
/*    */   {}
/*    */   
/*    */   public static class PreferencesEvent extends AppEvent
/*    */   {}
/*    */   
/*    */   public static class QuitEvent extends AppEvent
/*    */   {}
/*    */   
/*    */   public static class AppReOpenedEvent extends AppEvent
/*    */   {}
/*    */   
/*    */   public static class AppForegroundEvent extends AppEvent
/*    */   {}
/*    */   
/*    */   public static class AppHiddenEvent extends AppEvent
/*    */   {}
/*    */   public static class UserSessionEvent extends AppEvent
/*    */   {}
/*    */   public static class ScreenSleepEvent extends AppEvent
/*    */   {}
/*    */   public static class SystemSleepEvent extends AppEvent
/*    */   {}
/*    */   public static class FullScreenEvent extends AppEvent { FullScreenEvent(Window paramWindow) {}
/* 55 */     public Window getWindow() { throw Application.unimplemented(); }
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\AppEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */