/*   */ package com.apple.eawt;
/*   */ 
/*   */ import java.awt.Toolkit;
/*   */ 
/*   */ public class ApplicationBeanInfo extends java.beans.SimpleBeanInfo
/*   */ {
/*   */   public java.awt.Image getIcon(int paramInt) {
/* 8 */     return Toolkit.getDefaultToolkit().getImage("NSImage://NSGenericApplication");
/*   */   }
/*   */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\ApplicationBeanInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */