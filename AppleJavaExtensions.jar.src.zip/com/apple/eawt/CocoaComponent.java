/*    */ package com.apple.eawt;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ public abstract class CocoaComponent extends java.awt.Canvas {
/*    */   public abstract int createNSView();
/*    */   
/*    */   public void update(Graphics paramGraphics) {
/*  9 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public void paint(Graphics paramGraphics) {
/* 13 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public long createNSViewLong() {
/* 17 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public final void sendMessage(int paramInt, Object paramObject) {
/* 21 */     throw Application.unimplemented();
/*    */   }
/*    */   
/*    */   public abstract java.awt.Dimension getMaximumSize();
/*    */   
/*    */   public abstract java.awt.Dimension getMinimumSize();
/*    */   
/*    */   public abstract java.awt.Dimension getPreferredSize();
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\eawt\CocoaComponent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */