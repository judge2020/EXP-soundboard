/*    */ package com.apple.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ 
/*    */ public final class Dispatch {
/*    */   public static enum Priority {
/*  7 */     LOW(-2),  NORMAL(0),  HIGH(2);
/*    */     
/*    */     private Priority(int paramInt) {}
/*    */   }
/*    */   
/*    */   static RuntimeException unimplemented() {
/* 13 */     return new RuntimeException("Unimplemented");
/*    */   }
/*    */   
/*    */   public static Dispatch getInstance() {
/* 17 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getAsyncExecutor(Priority paramPriority) {
/* 21 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public java.util.concurrent.ExecutorService createSerialExecutor(String paramString) {
/* 25 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getNonBlockingMainQueueExecutor() {
/* 29 */     throw unimplemented();
/*    */   }
/*    */   
/*    */   public Executor getBlockingMainQueueExecutor() {
/* 33 */     throw unimplemented();
/*    */   }
/*    */ }


/* Location:              C:\Users\hunte\Downloads\EXP Soundboard_05.jar!\AppleJavaExtensions.jar!\com\apple\concurrent\Dispatch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */